package de.deinname.securebrowse.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.deinname.securebrowse.jarvis.JarvisController
import de.deinname.securebrowse.jarvis.JarvisEvent
import de.deinname.securebrowse.jarvis.JarvisMessage
import de.deinname.securebrowse.jarvis.voice.JarvisVoiceIO
import kotlinx.coroutines.launch

/** Natural, restrained voice-call surface. Recognition is user-triggered, not always-on. */
@Composable
fun JarvisCallScreen(controller: JarvisController, onClose: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val engine = controller.engine
    val state by engine.state.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val voice = remember { JarvisVoiceIO(context) }
    var voiceReady by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var thinking by remember { mutableStateOf(false) }
    var transcript by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("Ich bin hier. Lass uns sprechen.") }
    var error by remember { mutableStateOf("") }
    var recognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    var conversation by remember { mutableStateOf(listOf<JarvisMessage>()) }

    DisposableEffect(Unit) {
        voice.initialize { voiceReady = it }
        onDispose { recognizer?.destroy(); voice.close(); engine.cancel() }
    }

    fun answer(text: String) {
        if (text.isBlank() || thinking || state !is de.deinname.securebrowse.jarvis.JarvisEngineState.Ready) return
        val history = conversation + JarvisMessage("user", text)
        conversation = history
        transcript = text
        thinking = true
        error = ""
        scope.launch {
            val output = StringBuilder()
            try {
                engine.stream(history).collect { event ->
                    if (event is JarvisEvent.Token) output.append(event.text)
                }
                reply = output.toString().ifBlank { "Ich konnte gerade keine Antwort erzeugen." }
                conversation = history + JarvisMessage("assistant", reply)
                if (voiceReady) voice.speak(reply)
            } catch (e: Exception) {
                error = e.message ?: "Antwort fehlgeschlagen."
            } finally { thinking = false }
        }
    }

    fun startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { error = "Auf diesem Gerät ist keine Spracherkennung verfügbar."; return }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        listening = true
        error = ""
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true }
            override fun onBeginningOfSpeech() { listening = true }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(code: Int) {
                listening = false
                if (code != SpeechRecognizer.ERROR_NO_MATCH && code != SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                    error = "Spracherkennung fehlgeschlagen (Fehler $code)."
            }
            override fun onResults(results: android.os.Bundle?) {
                listening = false
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (heard.isNotBlank()) answer(heard) else error = "Ich habe nichts verstanden. Versuch es noch einmal."
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        r.startListening(Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault().toLanguageTag())
            putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        })
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecognition()
        else error = "Mikrofonzugriff wurde nicht erlaubt."
    }

    Scaffold(containerColor = Color(0xFFF5F2ED)) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=24.dp, vertical=18.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("JARVIS", style = MaterialTheme.typography.headlineSmall, color = Color(0xFF393630))
                Text("Sprachgespräch", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF827A70))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Box(Modifier.size(220.dp).background(Color(0xFFE6DED3), CircleShape), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(if (listening) 184.dp else 168.dp).background(Color(0xFFB9A895), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(138.dp).background(Color(0xFF8F7766), CircleShape), contentAlignment = Alignment.Center) {
                            Text("J", style = MaterialTheme.typography.displayMedium, color = Color(0xFFFFF9F1))
                        }
                    }
                }
                Text(when {
                    listening -> "Ich höre zu…"
                    thinking -> "Ich denke nach…"
                    else -> "Bereit zum Gespräch"
                }, style = MaterialTheme.typography.titleMedium, color = Color(0xFF393630))
                Text(reply, textAlign = TextAlign.Center, color = Color(0xFF615A52))
                if (transcript.isNotBlank()) Text("Du: $transcript", textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall, color = Color(0xFF827A70))
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledIconButton(onClick = {
                    if (listening) { recognizer?.stopListening(); listening = false }
                    else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecognition()
                    else permission.launch(Manifest.permission.RECORD_AUDIO)
                }, modifier = Modifier.size(76.dp), shape = CircleShape, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF786657))) {
                    Icon(if (listening) Icons.Filled.MicOff else Icons.Filled.Mic, contentDescription = if (listening) "Zuhören stoppen" else "Sprechen", tint = Color.White)
                }
                IconButton(onClick = { if (voiceReady) voice.speak(reply) }, enabled = voiceReady, modifier = Modifier.size(54.dp)) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = "Antwort erneut abspielen", tint = Color(0xFF786657))
                }
                FilledIconButton(onClick = { recognizer?.stopListening(); engine.cancel(); onClose() },
                    modifier = Modifier.size(64.dp), shape = CircleShape, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFFB85C50))) {
                    Icon(Icons.Filled.CallEnd, contentDescription = "Gespräch beenden", tint = Color.White)
                }
            }
            Text("Mikrofon nur bei Tastendruck · Spracherkennung abhängig vom Android-Dienst",
                textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall, color = Color(0xFF827A70))
        }
    }
}
