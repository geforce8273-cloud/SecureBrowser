# SecureBrowse – Sicherheitskonzept

## Schutzprinzipien

1. **Fail closed:** Wenn ein Sicherheitsbackend nicht verfügbar ist, darf die App keine Schutzwirkung vortäuschen.
2. **Keine TLS-Ausnahmen speichern:** Zertifikatsfehler standardmäßig abbrechen; einmaliges Fortfahren bleibt eine bewusste Ausnahme.
3. **Keine JavaScript-Bridge:** Webseiten erhalten keinen direkten Zugriff auf Android-APIs.
4. **Minimale Rechte:** Standort bleibt deaktiviert; Kamera/Mikrofon erst nach In-App- und Android-Zustimmung.
5. **Lokale Daten schützen:** Schlüssel in Android Keystore; sensible Profile verschlüsselt; keine unnötigen Cloud-Dienste.
6. **Transparenz:** VPN/Tor/Adblock/JARVIS-Status nur als aktiv anzeigen, wenn der jeweilige Backend-Zustand tatsächlich bestätigt wurde.

## Sicherheitsgrenzen

- WebView ist ein Browser-Renderer, kein vollständiger Chromium-Browser mit eigenem Netzwerkstack.
- Ein Request-Interceptor ist kein zuverlässiger Ersatz für einen DNS-Filter oder vollständige Filterlisten-Engine.
- Android Safe Browsing benötigt unterstützte WebView-Komponenten und kann nicht jeden Angriff erkennen.
- Ein VPN schützt nur den Verkehr, der tatsächlich durch den Tunnel geroutet wird. DNS, IPv6, UDP, Captive Portals und Verbindungsabbrüche müssen auf echten Geräten geprüft werden.
- Tor ist erst dann aktiv, wenn ein Tor-Client verbunden ist und WebView-/DNS-Verkehr nachweislich durch ihn läuft.
- Ein lokales Sprachmodell ist nicht automatisch vertrauenswürdig. Webseiteninhalte sind nicht vertrauenswürdige Eingaben und dürfen keine Tool-Aktionen auslösen.

## Veröffentlichungs-Gate

Keine Release- oder Anonymitätsversprechen ohne reproduzierbare Tests, dokumentierte Build-Logs, Dependency-/Lizenzprüfung, Leak-Tests und reale Gerätetests.
