# JNI: native code (jarvis_jni.cpp) finds these by name. R8 must not rename or remove them.
-keep class de.deinname.securebrowse.jarvis.LlamaBridge { *; }
-keep interface de.deinname.securebrowse.jarvis.TokenCallback { *; }
# OpenVPN-Engine wird per Reflection geladen (OpenVpnController).
-keep class de.deinname.securebrowse.vpn.OpenVpnEngineImpl { *; }
-keep interface de.deinname.securebrowse.vpn.OpenVpnEngine { *; }
