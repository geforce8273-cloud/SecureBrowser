package de.deinname.securebrowse.shield

/** Minimal, bounds-checked IPv6/UDP DNS codec for the local VPN interface.
 * It deliberately accepts only packets with a plain IPv6 header followed by UDP (no extension
 * headers or fragments). Unsupported packets are ignored rather than misparsed.
 */
internal object Ipv6DnsPacketCodec {
    data class Query(val packet: ByteArray, val sourcePort: Int, val dns: ByteArray)

    fun readQuery(packet: ByteArray, length: Int): Query? {
        if (length < 48 || length > packet.size) return null
        if ((packet[0].toInt() ushr 4 and 0x0f) != 6) return null
        if ((packet[6].toInt() and 0xff) != 17) return null // UDP; extension headers are unsupported
        val payloadLength = u16(packet, 4)
        if (payloadLength < 8 + 17 || 40 + payloadLength > length) return null
        val sourcePort = u16(packet, 40)
        val destinationPort = u16(packet, 42)
        val udpLength = u16(packet, 44)
        if (sourcePort == 0 || destinationPort != 53 || udpLength != payloadLength || udpLength < 25) return null
        val dns = packet.copyOfRange(48, 40 + udpLength)
        if (LocalDnsPolicy.readQuestionName(dns) == null) return null
        return Query(packet.copyOfRange(0, 40 + payloadLength), sourcePort, dns)
    }

    fun makeResponse(query: Query, dnsResponse: ByteArray): ByteArray? {
        if (!LocalDnsPolicy.isMatchingResponse(query.dns, dnsResponse)) return null
        val udpLength = 8 + dnsResponse.size
        if (udpLength > 0xffff) return null
        val result = ByteArray(40 + udpLength)
        result[0] = 0x60
        put16(result, 4, udpLength)
        result[6] = 17 // UDP
        result[7] = 64 // hop limit
        // Reply source is the DNS address queried by the client; destination is the client.
        query.packet.copyOfRange(24, 40).copyInto(result, 8)
        query.packet.copyOfRange(8, 24).copyInto(result, 24)
        put16(result, 40, 53)
        put16(result, 42, query.sourcePort)
        put16(result, 44, udpLength)
        dnsResponse.copyInto(result, 48)
        val checksum = udpChecksum(result, udpLength)
        put16(result, 46, if (checksum == 0) 0xffff else checksum)
        return result
    }

    private fun udpChecksum(packet: ByteArray, udpLength: Int): Int {
        var sum = 0L
        fun add(offset: Int, length: Int) {
            var i = offset
            while (i + 1 < offset + length) {
                sum += ((packet[i].toInt() and 0xff) shl 8) or (packet[i + 1].toInt() and 0xff)
                i += 2
            }
            if (i < offset + length) sum += (packet[i].toInt() and 0xff) shl 8
        }
        add(8, 32) // IPv6 source + destination addresses
        sum += (udpLength ushr 16).toLong()
        sum += (udpLength and 0xffff).toLong()
        sum += 17L // next header: UDP
        add(40, udpLength)
        while (sum ushr 16 != 0L) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xff) shl 8) or (data[offset + 1].toInt() and 0xff)

    private fun put16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = (value ushr 8).toByte()
        data[offset + 1] = value.toByte()
    }
}
