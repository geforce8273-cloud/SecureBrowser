package de.deinname.securebrowse.ui

import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** Markenfarben: Weiß -> Lila. */
object Brand {
    val Violet = Color(0xFF7C3AED)
    val VioletDeep = Color(0xFF5B21B6)
    val Orchid = Color(0xFFC084FC)
    val Sky = Color(0xFF818CF8)
    val Pink = Color(0xFFE879F9)

    /** Horizontaler Akzentverlauf (Fortschritt, Marker, Überschrift). */
    val accent: Brush = Brush.horizontalGradient(listOf(Violet, Orchid, Sky))

    /** Ganzer Bildschirm: oben fast weiß, nach unten immer lilaner. */
    fun screenBrush(dark: Boolean): Brush = Brush.verticalGradient(
        if (dark) listOf(Color(0xFF120A24), Color(0xFF241047), Color(0xFF3B1A78))
        else listOf(Color(0xFFFFFFFF), Color(0xFFF6F1FF), Color(0xFFE2D2FF), Color(0xFFC9ADFF))
    )
}

/** Respektiert die Android-Einstellung "Animationen entfernen". */
@Composable
fun rememberReducedMotion(): Boolean {
    val context = LocalContext.current
    return remember {
        try {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        } catch (_: Exception) {
            false
        }
    }
}

/** Weiß-zu-Lila-Verlauf mit drei langsam wandernden, weichen Leuchtflecken. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val reduced = rememberReducedMotion()
    val transition = rememberInfiniteTransition(label = "aurora")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(18_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "auroraPhase"
    )
    val blobs = listOf(Brand.Violet, Brand.Pink, Brand.Sky)
    Canvas(modifier) {
        val p = if (reduced) 0.5f else phase // Lesen im Draw-Block: keine Recomposition pro Frame
        drawRect(Brand.screenBrush(dark))
        val angle = p * 6.2831855f
        for (i in blobs.indices) {
            val a = angle + i * 2.1f
            val center = Offset(
                x = size.width * (0.5f + 0.38f * cos(a)),
                y = size.height * (0.5f + 0.38f * sin(a * 0.8f + i))
            )
            val radius = size.minDimension * 0.7f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(blobs[i].copy(alpha = if (dark) 0.34f else 0.22f), Color.Transparent),
                    center = center, radius = radius
                ),
                radius = radius,
                center = center
            )
        }
    }
}

/** Hauchdünner Ladebalken (2 dp) mit Verlauf und wanderndem Glanz. */
@Composable
fun GradientProgress(progress: Float, modifier: Modifier = Modifier) {
    val smooth by animateFloatAsState(progress.coerceIn(0f, 1f), tween(250), label = "progress")
    val transition = rememberInfiniteTransition(label = "progressShine")
    val shine by transition.animateFloat(
        initialValue = -0.3f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "shine"
    )
    Canvas(modifier.fillMaxWidth().height(2.dp)) {
        val w = size.width * smooth
        drawRect(Brand.accent, size = Size(w, size.height))
        val sx = w * shine
        drawRect(
            Brush.horizontalGradient(
                listOf(Color.Transparent, Color.White.copy(alpha = 0.85f), Color.Transparent),
                startX = sx - 60.dp.toPx(), endX = sx + 60.dp.toPx()
            ),
            size = Size(w, size.height)
        )
    }
}

/** Pulsierender Schild mit rotierendem Farbring für die Startseite. */
@Composable
fun BrandOrb(modifier: Modifier = Modifier) {
    val reduced = rememberReducedMotion()
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.9f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "orbPulse"
    )
    val spin by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart), label = "orbSpin"
    )
    Box(modifier.size(112.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(112.dp)) {
            val s = if (reduced) 1f else pulse
            val r = size.minDimension / 2f
            drawCircle(
                Brush.radialGradient(listOf(Brand.Violet.copy(alpha = 0.45f), Color.Transparent), radius = r * 1.1f * s),
                radius = r * 1.1f * s
            )
            rotate(if (reduced) 0f else spin) {
                drawCircle(
                    brush = Brush.sweepGradient(listOf(Brand.Violet, Brand.Orchid, Brand.Sky, Color.Transparent, Brand.Violet)),
                    radius = r * 0.62f,
                    style = Stroke(width = 3.dp.toPx())
                )
            }
            drawCircle(Color.White.copy(alpha = 0.55f), radius = r * 0.52f)
        }
        Icon(Icons.Filled.Shield, contentDescription = null, tint = Brand.Violet, modifier = Modifier.size(34.dp))
    }
}
