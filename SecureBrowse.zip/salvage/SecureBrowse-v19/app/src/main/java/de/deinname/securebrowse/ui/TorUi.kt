package de.deinname.securebrowse.ui

import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalMinimumInteractiveComponentSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import de.deinname.securebrowse.R
import de.deinname.securebrowse.tor.TorState
import kotlin.math.cos
import kotlin.math.sin

private val TorDeep = Color(0xFF1A0B2E)
private val TorMid = Color(0xFF4B1D8F)
private val TorBar = Color(0xFF3B1F6B)
private val TorGlow = Color(0x66B388FF)

/** Lila, langsam wandernder Verlauf mit drei weichen Leuchtflecken. Bei "Animationen entfernen" (Android) bleibt er statisch. */
@Composable
fun TorAnimatedBackground(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val reduced = remember {
        try {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        } catch (_: Exception) {
            false
        }
    }
    val transition = rememberInfiniteTransition(label = "tor-bg")
    val animated by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 12_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "tor-bg-phase"
    )
    val p = if (reduced) 0.5f else animated
    Canvas(modifier) {
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(TorDeep, TorMid, Color(0xFF2A0F55)),
                start = Offset(size.width * p, 0f),
                end = Offset(size.width * (1f - p), size.height)
            )
        )
        val angle = p * 6.2831855f
        for (i in 0 until 3) {
            val a = angle + i * 2.1f
            val center = Offset(
                x = size.width * (0.5f + 0.35f * cos(a)),
                y = size.height * (0.5f + 0.35f * sin(a * 0.8f + i))
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(TorGlow, Color.Transparent), center = center, radius = size.minDimension * 0.55f),
                radius = size.minDimension * 0.55f,
                center = center
            )
        }
    }
}

/** Schalter "Tor-Modus". Zeigt ehrlich den Zustand, nie ein Anonymitaets-Versprechen. Schlanke Variante (~36 dp). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TorToggleBar(torOn: Boolean, torState: TorState, onToggle: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val bg by animateColorAsState(if (torOn) TorBar else Color.Transparent, tween(350), label = "torBarBg")
    Surface(color = bg, modifier = modifier.fillMaxWidth()) {
        Row(
            Modifier.heightIn(min = 34.dp).padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(14.dp),
                tint = if (torOn) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                stringResource(R.string.tor_toggle_label),
                color = if (torOn) Color.White else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                stringResource(
                    when {
                        !torOn -> R.string.tor_status_off
                        torState == TorState.CONNECTED -> R.string.tor_status_connected
                        torState == TorState.STARTING -> R.string.tor_status_starting
                        else -> R.string.tor_status_no_engine
                    }
                ),
                color = if (torOn) Color(0xFFE1D5FF) else MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            CompositionLocalProvider(LocalMinimumInteractiveComponentSize provides 0.dp) {
                Switch(checked = torOn, onCheckedChange = onToggle, modifier = Modifier.scale(0.72f))
            }
        }
    }
}

/** Fail-closed: statt der Seite wird nur dieser Hinweis gezeigt, solange Tor nicht verbunden ist. */
@Composable
fun TorBlockedNotice(modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(R.string.tor_blocked_title), color = Color.White, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(
            stringResource(R.string.tor_blocked_body),
            color = Color(0xFFE1D5FF),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 12.dp)
        )
    }
}
