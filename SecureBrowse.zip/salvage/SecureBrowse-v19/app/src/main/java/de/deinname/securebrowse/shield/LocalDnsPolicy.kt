package de.deinname.securebrowse.shield

import java.util.Locale

/** Pure DNS policy helpers so domain decisions can be unit-tested without Android. */
object LocalDnsPolicy {
    private val blockedDomains = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com",
        "outbrain.com", "scorecardresearch.com", "quantserve.com",
        "hotjar.com", "mixpanel.com", "segment.io", "branch.io",
        "app-measurement.com", "analytics.google.com", "facebook.net",
        "connect.facebook.net", "pixel.facebook.com", "amazon-adsystem.com"
    )

    fun isBlocked(domain: String): Boolean {
        val normalized = domain.trimEnd('.').lowercase(Locale.ROOT)
        return normalized.isNotEmpty() && blockedDomains.any {
            normalized == it || normalized.endsWith(".$it")
        }
    }

    /** Reads the first uncompressed DNS question name. Compressed/malformed names fail closed. */
    fun readQuestionName(dns: ByteArray): String? {
        if (dns.size < 17) return null
        val flags = ((dns[2].toInt() and 0xff) shl 8) or (dns[3].toInt() and 0xff)
        // Accept standard queries only: QR=0, opcode=QUERY, exactly one question.
        if ((flags and 0x8000) != 0 || (flags and 0x7800) != 0) return null
        val questionCount = ((dns[4].toInt() and 0xff) shl 8) or (dns[5].toInt() and 0xff)
        if (questionCount != 1) return null

        val labels = ArrayList<String>()
        var index = 12
        var wireNameLength = 1 // terminating root label
        var terminated = false
        while (index < dns.size) {
            val size = dns[index++].toInt() and 0xff
            if (size == 0) {
                terminated = true
                break
            }
            // Reject compression pointers and reserved label encodings in questions.
            if ((size and 0xc0) != 0 || size > 63 || index + size > dns.size) return null
            wireNameLength += size + 1
            if (wireNameLength > 255) return null
            val label = dns.copyOfRange(index, index + size).toString(Charsets.US_ASCII)
            if (!label.matches(LABEL_PATTERN)) return null
            labels += label.lowercase(Locale.ROOT)
            index += size
        }
        if (!terminated || labels.isEmpty() || index + 4 > dns.size) return null
        return labels.joinToString(".")
    }

    /** Accept only an upstream response for the exact question that was sent. */
    fun isMatchingResponse(query: ByteArray, response: ByteArray): Boolean {
        if (query.size < 12 || response.size < 12) return false
        if (query[0] != response[0] || query[1] != response[1]) return false
        val responseFlags = ((response[2].toInt() and 0xff) shl 8) or (response[3].toInt() and 0xff)
        if ((responseFlags and 0x8000) == 0 || (responseFlags and 0x7800) != 0) return false
        val responseQuestions = ((response[4].toInt() and 0xff) shl 8) or (response[5].toInt() and 0xff)
        if (responseQuestions != 1 || readQuestionName(query) == null) return false
        val queryEnd = findQuestionEnd(query) ?: return false
        val responseEnd = findQuestionEnd(response) ?: return false
        if (queryEnd - 12 != responseEnd - 12) return false
        return query.copyOfRange(12, queryEnd).contentEquals(response.copyOfRange(12, responseEnd))
    }

    /** Builds a local NXDOMAIN response while retaining the original DNS question. */
    fun makeNxDomain(query: ByteArray): ByteArray? {
        if (readQuestionName(query) == null) return null
        val questionEnd = findQuestionEnd(query) ?: return null
        val question = query.copyOfRange(12, questionEnd)
        val response = ByteArray(12 + question.size)
        response[0] = query[0]
        response[1] = query[1]
        // QR + RA, preserve the client's recursion-desired bit, set NXDOMAIN.
        response[2] = ((query[2].toInt() and 0x01) or 0x80).toByte()
        response[3] = 0x83.toByte()
        response[5] = 1 // QDCOUNT = 1
        question.copyInto(response, 12)
        return response
    }

    private val LABEL_PATTERN = Regex("[A-Za-z0-9_-]{1,63}")

    private fun findQuestionEnd(query: ByteArray): Int? {
        var index = 12
        while (index < query.size) {
            val size = query[index++].toInt() and 0xff
            if (size == 0) return if (index + 4 <= query.size) index + 4 else null
            if (size > 63 || index + size > query.size) return null
            index += size
        }
        return null
    }
}
