package de.deinname.securebrowse.jarvis

/**
 * Decides BEFORE loading whether a model may be loaded at all and how much RAM the KV cache may use.
 * Pure function (no Android types) so it can be unit-tested on the JVM.
 *
 * Model weights are memory-mapped, so a model that does not fit into free RAM does not crash
 * immediately: it thrashes the page cache and gets killed by the low-memory killer later. That is
 * exactly what this guard prevents.
 */
object MemoryGuard {
    const val MAX_CONTEXT = 4096
    private const val MB = 1024L * 1024L
    private const val MAX_MODEL_SHARE_OF_TOTAL_RAM = 0.6
    private const val RUNTIME_OVERHEAD_BYTES = 256 * MB   // compute buffers, tokenizer, JNI, Android
    private const val MIN_KV_BYTES = 64 * MB
    private const val MAX_KV_BYTES = 768 * MB

    sealed interface Plan {
        data class Allowed(val kvBudgetBytes: Long, val maxContext: Int = MAX_CONTEXT) : Plan
        data class Refused(val reason: String) : Plan
    }

    fun plan(
        modelBytes: Long,
        totalRamBytes: Long,
        availableRamBytes: Long,
        lowMemoryThresholdBytes: Long
    ): Plan {
        if (totalRamBytes > 0 && modelBytes > totalRamBytes * MAX_MODEL_SHARE_OF_TOTAL_RAM) {
            return Plan.Refused(
                "Das Modell (${mb(modelBytes)}) ist zu groß für dieses Gerät (${mb(totalRamBytes)} RAM). " +
                    "Maximal etwa 60 % des Arbeitsspeichers sind erlaubt. Bitte ein kleineres oder stärker quantisiertes Modell wählen."
            )
        }
        val headroom = availableRamBytes - lowMemoryThresholdBytes
        val required = modelBytes + RUNTIME_OVERHEAD_BYTES + MIN_KV_BYTES
        if (headroom < required) {
            return Plan.Refused(
                "Zu wenig freier Arbeitsspeicher: verfügbar ca. ${mb(maxOf(headroom, 0))}, benötigt ca. ${mb(required)}. " +
                    "Bitte andere Apps schließen oder ein kleineres Modell wählen."
            )
        }
        val kv = (headroom - modelBytes - RUNTIME_OVERHEAD_BYTES).coerceIn(MIN_KV_BYTES, MAX_KV_BYTES)
        return Plan.Allowed(kvBudgetBytes = kv)
    }

    private fun mb(bytes: Long) = "${bytes / MB} MB"
}
