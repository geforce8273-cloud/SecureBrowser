package de.deinname.securebrowse.core

/** Reiner Text-Baukasten fuer "Diagnose kopieren" (C3). Enthaelt bewusst keine URLs, Profilinhalte oder Prompts. */
object DiagnosticReport {
    fun build(
        appVersion: String,
        androidRelease: String,
        sdkInt: Int,
        abi: String,
        totalRamMb: Long,
        freeRamMb: Long,
        vpnState: String,
        jarvisState: String,
        lastErrorCodes: List<String> = emptyList()
    ): String = buildString {
        appendLine("SecureBrowse Diagnose (ohne persoenliche Daten)")
        appendLine("App: $appVersion")
        appendLine("Android: $androidRelease (SDK $sdkInt), ABI: $abi")
        appendLine("RAM: $freeRamMb MB frei von $totalRamMb MB")
        appendLine("VPN: $vpnState")
        appendLine("JARVIS: $jarvisState")
        appendLine("Letzte Fehlercodes: " + if (lastErrorCodes.isEmpty()) "keine" else lastErrorCodes.take(10).joinToString(", "))
    }
}
