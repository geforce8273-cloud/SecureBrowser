package de.deinname.securebrowse.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Eigene Palette: Weiß -> Lila. Surface-Rollen sind explizit gesetzt.
private val LightColors: ColorScheme = lightColorScheme(
    primary = Color(0xFF7C3AED), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE9DDFF), onPrimaryContainer = Color(0xFF2A0A66),
    secondary = Color(0xFF6B5B95), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFEADFFF), onSecondaryContainer = Color(0xFF241A45),
    background = Color(0xFFFCFAFF), onBackground = Color(0xFF1C1530),
    surface = Color(0xFFFCFAFF), onSurface = Color(0xFF1C1530),
    surfaceVariant = Color(0xFFE8E0F5), onSurfaceVariant = Color(0xFF4A3F6B),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF7F2FF),
    surfaceContainer = Color(0xFFF0E8FF), surfaceContainerHigh = Color(0xFFEBE1FF),
    surfaceContainerHighest = Color(0xFFE4D8FA),
    outline = Color(0xFF7D7299), error = Color(0xFFBA1A1A), onError = Color(0xFFFFFFFF)
)

private val DarkColors: ColorScheme = darkColorScheme(
    primary = Color(0xFFC4A8FF), onPrimary = Color(0xFF2E0F6B),
    primaryContainer = Color(0xFF4C2A99), onPrimaryContainer = Color(0xFFE9DDFF),
    secondary = Color(0xFFCDBFF0), onSecondary = Color(0xFF352A57),
    secondaryContainer = Color(0xFF4B3F73), onSecondaryContainer = Color(0xFFEADFFF),
    background = Color(0xFF120A24), onBackground = Color(0xFFEDE6FA),
    surface = Color(0xFF120A24), onSurface = Color(0xFFEDE6FA),
    surfaceVariant = Color(0xFF4A3F6B), onSurfaceVariant = Color(0xFFCFC4E8),
    surfaceContainerLowest = Color(0xFF0C0618), surfaceContainerLow = Color(0xFF1A1030),
    surfaceContainer = Color(0xFF211640), surfaceContainerHigh = Color(0xFF2C1F4F),
    surfaceContainerHighest = Color(0xFF38295E),
    outline = Color(0xFF9A8DB8), error = Color(0xFFFFB4AB), onError = Color(0xFF690005)
)

@Composable
fun SecureBrowseTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // optional, becomes a user setting in phase 4
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(
        colorScheme = colorScheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp), large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(32.dp)
        ),
        content = content
    )
}
