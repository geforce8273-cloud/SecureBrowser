package de.deinname.securebrowse.vpn

import android.content.Context

/** Wird von der eingebetteten OpenVPN-Engine (Quellordner src/openvpn) implementiert. */
interface OpenVpnEngine {
    fun connect(profileName: String, raw: String)
    fun disconnect()
    fun isConnected(): Boolean
}

/**
 * OpenVPN-Backend. Die Engine (ics-openvpn, siehe tools/add-openvpn.sh) ist fest in die App
 * eingebaut; es wird keine zweite App benötigt. Fehlt der Engine-Quellcode beim Build, baut die
 * App trotzdem, meldet aber beim Verbinden, dass OpenVPN in diesem Build nicht enthalten ist.
 */
class OpenVpnController(context: Context) : VpnBackend {
    private val engine: OpenVpnEngine? = runCatching {
        Class.forName(ENGINE_CLASS).getConstructor(Context::class.java)
            .newInstance(context.applicationContext) as OpenVpnEngine
    }.getOrNull()

    val available: Boolean get() = engine != null

    override fun validate(raw: String): Result<Unit> = OvpnConfigValidator.validate(raw)

    override fun connect(profileName: String, raw: String) {
        val e = engine ?: throw IllegalStateException("OpenVPN ist in diesem Build nicht enthalten (tools/add-openvpn.sh ausführen).")
        OvpnConfigValidator.validate(raw).getOrThrow()
        e.connect(profileName, raw)
    }

    override fun disconnect() { engine?.disconnect() }

    override fun isConnected(): Boolean = runCatching { engine?.isConnected() == true }.getOrDefault(false)

    private companion object {
        const val ENGINE_CLASS = "de.deinname.securebrowse.vpn.OpenVpnEngineImpl"
    }
}
