package de.deinname.securebrowse.tor

enum class TorState { OFF, STARTING, CONNECTED, FAILED }

/** Ziel des lokalen SOCKS-Proxys. Nur Loopback ist erlaubt, damit Webverkehr nie an einen fremden Proxy geht. */
data class ProxyEndpoint(val host: String, val port: Int) {
    /** Regel fuer WebView-Proxy-Override (PRUEFEN: Syntax auf developer.android.com/reference/androidx/webkit/ProxyConfig). */
    fun socksRule(): String = if (host.contains(':')) "socks5://[$host]:$port" else "socks5://$host:$port"

    companion object {
        fun loopbackOrNull(host: String, port: Int): ProxyEndpoint? {
            val h = host.trim().lowercase()
            val ok = h == "127.0.0.1" || h == "::1" || h == "localhost"
            return if (ok && port in 1..65535) ProxyEndpoint(if (h == "localhost") "127.0.0.1" else h, port) else null
        }
    }
}

/** Abstrakte Tor-Engine (z. B. spaeter tor-android oder Orbot). Ohne Engine ist [NoTorBackend] aktiv: Tor bleibt aus. */
interface TorBackend {
    val state: TorState
    fun start(onResult: (Result<ProxyEndpoint>) -> Unit)
    fun stop()
}

object NoTorBackend : TorBackend {
    override val state: TorState = TorState.OFF
    override fun start(onResult: (Result<ProxyEndpoint>) -> Unit) =
        onResult(Result.failure(IllegalStateException("Keine Tor-Engine eingebunden")))
    override fun stop() = Unit
}

/** Was im Tor-Modus strenger ist. Reine Daten, damit Browser-Code und Tests dieselbe Quelle nutzen. */
data class TorModePolicy(
    val persistentCookies: Boolean = false,
    val saveHistory: Boolean = false,
    val saveTabs: Boolean = false,
    val screenshotsBlocked: Boolean = true,
    val thirdPartyCookies: Boolean = false,
    val geolocation: Boolean = false,
    val cameraAndMic: Boolean = false,
    val unifiedUserAgent: Boolean = true,
    val httpsOnly: Boolean = true,
    val allowHttpFallback: Boolean = false,
    /** Fail-closed: ohne verbundenen Tor-Proxy wird keine Seite geladen. */
    val requireProxyBeforeLoad: Boolean = true
) {
    fun canLoad(state: TorState): Boolean = !requireProxyBeforeLoad || state == TorState.CONNECTED
}
