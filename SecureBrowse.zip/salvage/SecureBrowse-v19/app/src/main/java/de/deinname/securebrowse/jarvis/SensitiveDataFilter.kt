package de.deinname.securebrowse.jarvis

enum class SensitiveKind { CARD_NUMBER, IBAN, PASSWORD_HINT }

/** D13.9: JARVIS-Notizen duerfen keine Zahlungs- oder Zugangsdaten speichern. Reines Kotlin, offline. Kein Ersatz fuer Nutzerverstand. */
object SensitiveDataFilter {
    private val digitRun = Regex("(?:\\d[ -]?){13,19}")
    private val ibanLike = Regex("\\b[A-Za-z]{2}\\d{2}(?:[ ]?[A-Za-z0-9]){11,30}\\b")
    private val passwordHint = Regex("(?i)\\b(passwort|kennwort|password|passwd|pwd|pin)\\s*[:=]")

    fun detect(text: String): Set<SensitiveKind> {
        val found = linkedSetOf<SensitiveKind>()
        if (digitRun.findAll(text).any { luhnOk(it.value.filter(Char::isDigit)) }) found += SensitiveKind.CARD_NUMBER
        if (ibanLike.findAll(text).any { ibanOk(it.value.filterNot { c -> c == ' ' }) }) found += SensitiveKind.IBAN
        if (passwordHint.containsMatchIn(text)) found += SensitiveKind.PASSWORD_HINT
        return found
    }

    fun isSafeToStore(text: String): Boolean = detect(text).isEmpty()

    internal fun luhnOk(digits: String): Boolean {
        if (digits.length !in 13..19) return false
        var sum = 0
        digits.reversed().forEachIndexed { i, ch ->
            var d = ch - '0'
            if (i % 2 == 1) { d *= 2; if (d > 9) d -= 9 }
            sum += d
        }
        return sum % 10 == 0
    }

    internal fun ibanOk(raw: String): Boolean {
        val s = raw.uppercase()
        if (s.length !in 15..34) return false
        val rearranged = s.substring(4) + s.substring(0, 4)
        var rem = 0
        for (ch in rearranged) {
            val v = when (ch) {
                in '0'..'9' -> ch - '0'
                in 'A'..'Z' -> ch - 'A' + 10
                else -> return false
            }
            rem = if (v >= 10) (rem * 100 + v) % 97 else (rem * 10 + v) % 97
        }
        return rem == 1
    }
}
