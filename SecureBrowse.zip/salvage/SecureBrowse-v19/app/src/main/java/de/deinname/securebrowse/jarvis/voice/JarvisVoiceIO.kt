package de.deinname.securebrowse.jarvis.voice

import android.content.Context
import android.content.Intent
import java.io.File
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/**
 * Device speech I/O facade: speech recognition is provided by the device recognition service;
 * synthesis is local to the selected installed TTS engine. Availability and privacy depend on
 * the installed engine. No audio is sent by this class to a remote endpoint directly.
 */
class JarvisVoiceIO(context: Context) : TextToSpeech.OnInitListener {
    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var initialized = false
    private var pendingInit: ((Boolean) -> Unit)? = null

    fun initialize(onReady: (Boolean) -> Unit) {
        if (initialized) { onReady(true); return }
        pendingInit = onReady
        tts = TextToSpeech(appContext, this)
    }

    override fun onInit(status: Int) {
        initialized = status == TextToSpeech.SUCCESS
        pendingInit?.invoke(initialized)
        pendingInit = null
    }

    /** Lists installed TTS languages. Availability varies by engine and device. */
    fun availableLanguages(): Set<Locale> =
        tts?.availableLanguages?.filter { it != Locale.ROOT }?.toSet() ?: emptySet()

    /** Voice selection: "female"/"male" is a preference hint, not guaranteed by engine metadata. */
    fun selectVoice(languageTag: String, presentation: String = "neutral"): Boolean {
        val engine = tts ?: return false
        val locale = Locale.forLanguageTag(languageTag)
        if (engine.setLanguage(locale) == TextToSpeech.LANG_MISSING_DATA ||
            engine.setLanguage(locale) == TextToSpeech.LANG_NOT_SUPPORTED) return false
        val voices = engine.voices ?: return true
        val candidates = voices.filter { it.locale.language == locale.language && !it.isNetworkConnectionRequired }
        val selected = when (presentation.lowercase(Locale.ROOT)) {
            "female", "feminine" -> candidates.firstOrNull { it.name.contains("female", true) || it.name.contains("woman", true) }
            "male", "masculine" -> candidates.firstOrNull { it.name.contains("male", true) || it.name.contains("man", true) }
            else -> null
        } ?: candidates.firstOrNull()
        if (selected != null) engine.voice = selected
        return selected != null || candidates.isEmpty()
    }

    fun speak(text: String, onDone: (() -> Unit)? = null): Boolean {
        val engine = tts ?: return false
        if (!initialized || text.isBlank()) return false
        val id = "jarvis-${UUID.randomUUID()}"
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { if (utteranceId == id) onDone?.invoke() }
            override fun onError(utteranceId: String?) = Unit
        })
        return engine.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), id) == TextToSpeech.SUCCESS
    }

    fun createRecognizer(): SpeechRecognizer? {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) return null
        return SpeechRecognizer.createSpeechRecognizer(appContext)
    }

    fun recognitionIntent(languageTag: String = Locale.getDefault().toLanguageTag()): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

    /** Creates a playable audio file from synthesized speech. Completion is signaled via callback. */
    fun synthesizeToFile(text: String, file: File, onComplete: (Boolean) -> Unit): Boolean {
        val engine = tts ?: return false
        if (!initialized || text.isBlank()) return false
        val id = "jarvis-file-${UUID.randomUUID()}"
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { if (utteranceId == id) onComplete(file.exists() && file.length() > 0) }
            override fun onError(utteranceId: String?) { if (utteranceId == id) onComplete(false) }
        })
        return engine.synthesizeToFile(text, Bundle(), file, id) == TextToSpeech.SUCCESS
    }

    fun stopSpeaking() { tts?.stop() }
    fun close() { tts?.stop(); tts?.shutdown(); tts = null; initialized = false }
}
