package de.deinname.securebrowse.vpn

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores WireGuard and OpenVPN profiles encrypted with an AES-256 key held by Android Keystore. */
class EncryptedVpnProfileStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vpn_profiles", Context.MODE_PRIVATE)

    data class Profile(val name: String, val config: String, val type: String = VpnType.WIREGUARD)

    /**
     * Reads profiles without hiding authentication or parse failures.
     *
     * Returning an empty list on AES-GCM authentication failure is dangerous: a later save()
     * would treat the vault as empty and overwrite the still-recoverable ciphertext. Fail closed.
     */
    @Synchronized fun all(): List<Profile> {
        val raw = prefs.getString(KEY_DATA, null) ?: return emptyList()
        val plain = try {
            decrypt(Base64.decode(raw, Base64.NO_WRAP))
        } catch (error: Exception) {
            throw IllegalStateException("VPN-Profil-Tresor konnte nicht authentifiziert werden; Daten wurden nicht verändert.", error)
        }
        val array = try {
            JSONArray(plain)
        } catch (error: Exception) {
            throw IllegalStateException("VPN-Profil-Tresor enthält ungültige Daten; Daten wurden nicht verändert.", error)
        }
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            val profile = Profile(
                item.getString("name"),
                item.getString("config"),
                item.optString("type", VpnType.WIREGUARD)
            )
            VpnProfileValidation.validate(profile).getOrThrow()
            profile
        }
    }

    @Synchronized fun save(name: String, config: String, type: String = VpnType.WIREGUARD) {
        val profile = Profile(name, config, type)
        VpnProfileValidation.validate(profile).getOrThrow()
        val profiles = all().filterNot { it.name == name }.toMutableList()
        profiles.add(profile)
        val json = encodeProfiles(profiles)
        check(prefs.edit().putString(KEY_DATA, Base64.encodeToString(encrypt(json), Base64.NO_WRAP)).commit()) {
            "VPN-Profil konnte nicht dauerhaft gespeichert werden."
        }
    }

    @Synchronized fun delete(name: String) {
        // all() deliberately throws if decryption/authentication fails; never erase an unreadable vault.
        val remaining = all().filterNot { it.name == name }
        if (remaining.isEmpty()) {
            check(prefs.edit().remove(KEY_DATA).commit()) { "VPN-Profil konnte nicht gelöscht werden." }
        } else {
            val encrypted = Base64.encodeToString(encrypt(encodeProfiles(remaining)), Base64.NO_WRAP)
            check(prefs.edit().putString(KEY_DATA, encrypted).commit()) { "VPN-Profil konnte nicht gelöscht werden." }
        }
    }

    private fun encodeProfiles(profiles: List<Profile>): String = JSONArray().apply {
        profiles.forEach { put(JSONObject().put("name", it.name).put("config", it.config).put("type", it.type)) }
    }.toString()

    private fun encrypt(value: String): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return cipher.iv + encrypted
    }

    private fun decrypt(value: ByteArray): String {
        require(value.size > IV_LENGTH) { "Ungültiges VPN-Profil" }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, value.copyOfRange(0, IV_LENGTH)))
        return cipher.doFinal(value.copyOfRange(IV_LENGTH, value.size)).toString(Charsets.UTF_8)
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val KEY_ALIAS = "securebrowse_wireguard_profiles_v1"
        const val KEY_DATA = "encrypted_profiles"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_LENGTH = 12
    }
}


/** Pure validation shared by persistence code and JVM unit tests. */
internal object VpnProfileValidation {
    private const val MAX_NAME_LENGTH = 80
    private const val MAX_CONFIG_LENGTH = 512 * 1024

    fun validate(profile: EncryptedVpnProfileStore.Profile): Result<Unit> = runCatching {
        require(profile.name.isNotBlank() && profile.name.length <= MAX_NAME_LENGTH) {
            "Profilname muss 1 bis 80 Zeichen lang sein."
        }
        require(profile.name.none { it.isISOControl() }) { "Profilname enthält Steuerzeichen." }
        require(profile.config.isNotBlank() && profile.config.length <= MAX_CONFIG_LENGTH) {
            "VPN-Konfiguration ist leer oder überschreitet 512 KiB."
        }
        require(profile.type == VpnType.WIREGUARD || profile.type == VpnType.OPENVPN) {
            "Unbekannter VPN-Profiltyp."
        }
    }
}
