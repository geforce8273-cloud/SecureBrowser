package de.deinname.securebrowse.vpn

/** Gemeinsame Schnittstelle für alle VPN-Protokolle in SecureBrowse. */
interface VpnBackend {
    /** Prüft die Konfiguration, ohne zu verbinden. Fehlertext ist für den Nutzer gedacht. */
    fun validate(raw: String): Result<Unit>
    fun connect(profileName: String, raw: String)
    fun disconnect()
    fun isConnected(): Boolean
}

object VpnType {
    const val WIREGUARD = "wireguard"
    const val OPENVPN = "openvpn"

    /** WireGuard-Dateien haben [Interface]/[Peer]; OpenVPN-Dateien haben "remote"/"client". */
    fun detect(raw: String, fileName: String? = null): String {
        val lower = fileName?.lowercase().orEmpty()
        if (lower.endsWith(".ovpn")) return OPENVPN
        if (lower.endsWith(".conf") && raw.contains("[Interface]")) return WIREGUARD
        if (raw.contains("[Interface]") && raw.contains("[Peer]")) return WIREGUARD
        val hasRemote = raw.lineSequence().any { it.trim().startsWith("remote ") }
        return if (hasRemote) OPENVPN else WIREGUARD
    }
}
