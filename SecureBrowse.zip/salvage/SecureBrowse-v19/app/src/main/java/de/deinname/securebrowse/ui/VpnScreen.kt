package de.deinname.securebrowse.ui

import androidx.compose.ui.graphics.Color
import android.net.VpnService
import android.content.Intent
import android.os.Build
import de.deinname.securebrowse.shield.LocalShieldVpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.deinname.securebrowse.vpn.EncryptedVpnProfileStore
import de.deinname.securebrowse.vpn.OpenVpnController
import de.deinname.securebrowse.vpn.VpnBackend
import de.deinname.securebrowse.vpn.VpnType
import de.deinname.securebrowse.vpn.WireGuardController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun VpnScreen(
    wireGuard: WireGuardController,
    openVpn: OpenVpnController,
    store: EncryptedVpnProfileStore,
    onBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val profiles = remember { mutableStateListOf<EncryptedVpnProfileStore.Profile>() }
    var selectedName by remember { mutableStateOf("") }
    fun backendFor(type: String): VpnBackend = if (type == VpnType.OPENVPN) openVpn else wireGuard
    var connected by remember { mutableStateOf(wireGuard.isConnected() || openVpn.isConnected()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Importiere eine WireGuard- (.conf) oder OpenVPN-Datei (.ovpn), um zu beginnen.") }
    var showDelete by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf("Mein VPN") }
    var localShieldEnabled by remember { mutableStateOf(LocalShieldVpnService.isRunning) }

    val shieldPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == android.app.Activity.RESULT_OK) {
            val serviceIntent = Intent(context, LocalShieldVpnService::class.java).setAction(LocalShieldVpnService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent) else context.startService(serviceIntent)
            localShieldEnabled = true
            message = "Lokaler DNS-Schutz wird gestartet."
        } else message = "VPN-Berechtigung wurde nicht erteilt."
    }

    fun startLocalShield() {
        val intent = VpnService.prepare(context)
        if (intent != null) shieldPermissionLauncher.launch(intent)
        else {
            val serviceIntent = Intent(context, LocalShieldVpnService::class.java).setAction(LocalShieldVpnService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent) else context.startService(serviceIntent)
            localShieldEnabled = true
            message = "Lokaler DNS-Schutz wird gestartet. Deine öffentliche IP wird dadurch nicht geändert."
        }
    }

    fun stopLocalShield() {
        context.startService(Intent(context, LocalShieldVpnService::class.java).setAction(LocalShieldVpnService.ACTION_STOP))
        localShieldEnabled = false
        message = "Lokaler DNS-Schutz ausgeschaltet."
    }

    fun reloadProfiles() {
        profiles.clear()
        profiles.addAll(store.all())
        if (profiles.none { it.name == selectedName }) selectedName = profiles.firstOrNull()?.name.orEmpty()
    }

    LaunchedEffect(Unit) { reloadProfiles() }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                message = "Konfiguration wird geprüft …"
                val raw = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
                }
                if (raw.isNullOrBlank()) {
                    message = "Datei konnte nicht gelesen werden."
                } else {
                    val fileName = context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                    val type = VpnType.detect(raw, fileName)
                    val validation = backendFor(type).validate(raw)
                    if (validation.isSuccess) {
                        val name = profileName.trim().ifBlank { if (type == VpnType.OPENVPN) "OpenVPN-Profil" else "WireGuard-Profil" }.take(40)
                        runCatching { store.save(name, raw, type) }
                            .onSuccess {
                                reloadProfiles()
                                selectedName = name
                                message = "Profil sicher importiert. Der private Schlüssel wird verschlüsselt gespeichert."
                            }
                            .onFailure { message = "Speichern fehlgeschlagen: ${it.message ?: "Unbekannter Fehler"}" }
                    } else {
                        message = "Die Datei ist keine gültige VPN-Konfiguration: ${validation.exceptionOrNull()?.message ?: "Prüfung fehlgeschlagen"}"
                    }
                }
                busy = false
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == android.app.Activity.RESULT_OK) {
            val profile = profiles.firstOrNull { p -> p.name == selectedName }
            if (profile == null) message = "Bitte zuerst ein Profil importieren."
            else scope.launch {
                busy = true
                runCatching { withContext(Dispatchers.IO) { backendFor(profile.type).connect(profile.name, profile.config) } }
                    .onSuccess { connected = true; message = "VPN wird verbunden …" }
                    .onFailure { connected = false; message = "Verbindung fehlgeschlagen: ${it.message ?: "Unbekannter Fehler"}" }
                busy = false
            }
        } else message = "VPN-Berechtigung wurde nicht erteilt."
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.Transparent) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("SecureBrowse VPN", style = MaterialTheme.typography.headlineSmall)
                TextButton(onClick = onBack) { Text("Zurück") }
            }
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (connected) "Verbunden" else "Nicht verbunden", style = MaterialTheme.typography.titleLarge,
                        color = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    Text(if (connected) "Der VPN-Tunnel ist aktiv." else "Dein Internetverkehr wird derzeit nicht durch SecureBrowse VPN geleitet.")
                    if (connected) {
                        Button(onClick = {
                            scope.launch {
                                busy = true
                                runCatching { withContext(Dispatchers.IO) { if (openVpn.isConnected()) openVpn.disconnect() else wireGuard.disconnect() } }
                                    .onSuccess { connected = false; message = "VPN getrennt." }
                                    .onFailure { message = "Trennen fehlgeschlagen: ${it.message}" }
                                busy = false
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("VPN ausschalten") }
                    } else {
                        Button(onClick = {
                            val profile = profiles.firstOrNull { it.name == selectedName }
                            if (profile == null) message = "Bitte zuerst eine Konfiguration importieren."
                            else {
                                val intent = VpnService.prepare(context)
                                if (intent == null) {
                                    scope.launch {
                                        busy = true
                                        runCatching { withContext(Dispatchers.IO) { backendFor(profile.type).connect(profile.name, profile.config) } }
                                            .onSuccess { connected = true; message = "VPN wird verbunden …" }
                                            .onFailure { message = "Verbindung fehlgeschlagen: ${it.message ?: "Unbekannter Fehler"}" }
                                        busy = false
                                    }
                                } else permissionLauncher.launch(intent)
                            }
                        }, enabled = !busy && profiles.isNotEmpty() && !localShieldEnabled, modifier = Modifier.fillMaxWidth()) { Text("VPN verbinden") }
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kostenloser Geräteschutz", style = MaterialTheme.typography.titleLarge)
                    Text("Lokaler DNS-Filter direkt auf deinem Smartphone. Er blockiert eine kleine integrierte Liste bekannter Werbe- und Tracking-Domains. Kein Konto, kein Abo und kein SecureBrowse-VPN-Server nötig.")
                    Text("Wichtig: Das ist kein IP-Wechsel-VPN. Erlaubte DNS-Anfragen werden an den DNS-Resolver deines aktuellen WLANs/Mobilfunknetzes weitergegeben. Apps mit eigenem DNS-over-HTTPS können den Filter umgehen.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(
                        onClick = { if (localShieldEnabled) stopLocalShield() else startLocalShield() },
                        enabled = !busy && !connected,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (localShieldEnabled) "Lokalen Schutz ausschalten" else "Kostenlosen lokalen Schutz aktivieren") }
                    if (connected) Text("Trenne zuerst dein anderes VPN, da Android nur eine aktive VPN-Verbindung gleichzeitig zulässt.", style = MaterialTheme.typography.bodySmall)
                }
            }

            Text("VPN-Profile", style = MaterialTheme.typography.titleMedium)
            if (profiles.isEmpty()) Text("Noch kein Profil vorhanden.")
            profiles.forEach { profile ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    RadioButton(selected = selectedName == profile.name, onClick = { selectedName = profile.name }, enabled = !connected)
                    Text(profile.name + if (profile.type == VpnType.OPENVPN) " (OpenVPN)" else " (WireGuard)", modifier = Modifier.weight(1f))
                    if (selectedName == profile.name) TextButton(onClick = { showDelete = true }, enabled = !connected) { Text("Löschen") }
                }
            }
            OutlinedTextField(value = profileName, onValueChange = { profileName = it }, label = { Text("Profilname für Import") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, enabled = !busy && !connected, modifier = Modifier.fillMaxWidth()) {
                Text("VPN-Konfiguration importieren (.conf / .ovpn)")
            }
            Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Text("Sicherheitshinweise", style = MaterialTheme.typography.titleMedium)
            Text("• OpenVPN-Dateien müssen Zertifikate inline enthalten; Skript-Direktiven (up, down, plugin …) werden aus Sicherheitsgründen abgelehnt.")
            Text("• Profile werden lokal mit AES-GCM verschlüsselt; der Schlüssel liegt im Android Keystore.")
            Text("• WireGuard/OpenVPN mit IP-Wechsel benötigen weiterhin einen VPN-Endpunkt. Der kostenlose lokale DNS-Schutz oben benötigt keinen SecureBrowse-Server, ändert aber nicht deine öffentliche IP.")
            Text("• Android zeigt beim ersten Verbinden eine Systemabfrage für die VPN-Berechtigung.")
            Text("• Für einen systemweiten Kill Switch aktiviere in Android unter Einstellungen → Netzwerk & Internet → VPN → SecureBrowse die Optionen „Immer aktives VPN“ und „Verbindungen ohne VPN blockieren“, sofern dein Gerät sie anbietet.")
            Text("• Ohne aktive Verbindung besteht kein VPN-Schutz. Ein VPN ersetzt weder HTTPS noch sichere Browsing-Gewohnheiten.", style = MaterialTheme.typography.bodySmall)
        }
    }

    if (showDelete) AlertDialog(
        onDismissRequest = { showDelete = false },
        title = { Text("Profil löschen?") },
        text = { Text("Das gespeicherte VPN-Profil wird von diesem Gerät entfernt.") },
        confirmButton = { TextButton(onClick = { store.delete(selectedName); showDelete = false; reloadProfiles(); message = "Profil gelöscht." }) { Text("Löschen") } },
        dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Abbrechen") } }
    )
}
