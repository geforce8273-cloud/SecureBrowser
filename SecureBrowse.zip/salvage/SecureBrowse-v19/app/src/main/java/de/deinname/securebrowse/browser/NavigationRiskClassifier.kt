package de.deinname.securebrowse.browser

import java.net.URI

/** Offline, advisory URL risk hints. This does not replace phishing lists or block navigation. */
object NavigationRiskClassifier {
    enum class Risk { LOW, CAUTION, HIGH }
    data class Assessment(val risk: Risk, val reasons: List<String>)

    fun assess(url: String): Assessment {
        val reasons = mutableListOf<String>()
        val parsed = runCatching { URI(url) }.getOrNull()
        if (parsed == null || parsed.host.isNullOrBlank()) {
            return Assessment(Risk.HIGH, listOf("Adresse konnte nicht sicher analysiert werden"))
        }
        val host = parsed.host.lowercase().trimEnd('.')
        if (parsed.scheme.equals("http", ignoreCase = true)) reasons += "Verbindung ist nicht HTTPS-verschlüsselt"
        if (parsed.rawUserInfo != null) reasons += "Adresse enthält Zugangsdaten vor dem Host"
        if (host.startsWith("xn--") || host.split('.').any { it.startsWith("xn--") }) reasons += "Internationalisierter Hostname (Punycode)"
        if (host == "localhost" || host.endsWith(".localhost") || host == "127.0.0.1" || host == "[::1]") reasons += "Lokales Zielgerät/Loopback-Adresse"
        if (host.count { it == '-' } >= 3 || host.count { it == '.' } >= 5) reasons += "Ungewöhnliche Hostnamenstruktur"
        if (parsed.port !in -1..65535) reasons += "Ungültiger Port"
        val risk = when {
            reasons.any { it.contains("Zugangsdaten") || it.contains("nicht sicher analysiert") } -> Risk.HIGH
            reasons.isNotEmpty() -> Risk.CAUTION
            else -> Risk.LOW
        }
        return Assessment(risk, reasons.distinct())
    }
}
