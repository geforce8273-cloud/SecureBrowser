package de.deinname.securebrowse.vpn

/**
 * Prüft .ovpn-Dateien, bevor sie gespeichert oder an die OpenVPN-Engine gegeben werden.
 *
 * Eine .ovpn-Datei kann beliebige Skripte (up/down, plugin, ...) ausführen lassen. SecureBrowse
 * lehnt solche Direktiven ab, weil eine importierte Datei sonst Code auf dem Gerät auslösen könnte.
 * Zertifikate und Schlüssel müssen inline (<ca>...</ca>) stehen, da externe Dateien nicht erreichbar sind.
 */
object OvpnConfigValidator {
    private val FORBIDDEN = setOf(
        "script-security", "up", "down", "up-restart", "route-up", "route-pre-down", "ipchange",
        "tls-verify", "auth-user-pass-verify", "client-connect", "client-disconnect",
        "learn-address", "plugin", "management", "management-client", "config", "setenv-safe",
        "mark", "bind-dev", "dev-node", "writepid", "log", "log-append", "status", "cd", "chroot",
        "daemon", "user", "group",
        // Starts a program, loads a native library or writes files: never needed in a client profile.
        "iproute", "pkcs11-providers", "tls-export-cert", "tmp-dir"
    )
    private val FILE_DIRECTIVES = setOf(
        "ca", "cert", "key", "pkcs12", "tls-auth", "tls-crypt", "tls-crypt-v2", "dh",
        "extra-certs", "crl-verify", "secret", "auth-user-pass", "askpass", "http-proxy-user-pass"
    )
    private val INLINE_BLOCKS = setOf("ca", "cert", "key", "pkcs12", "tls-auth", "tls-crypt", "tls-crypt-v2", "dh", "extra-certs")
    private const val MAX_BYTES = 256 * 1024

    fun validate(raw: String): Result<Unit> {
        if (raw.isBlank()) return fail("Die Datei ist leer.")
        if (raw.toByteArray(Charsets.UTF_8).size > MAX_BYTES) return fail("Die Datei ist zu groß für eine OpenVPN-Konfiguration.")
        var hasRemote = false
        var openBlock: String? = null
        // OpenVPN skips a leading UTF-8 byte order mark; without this the first line could hide a directive.
        for (line in raw.removePrefix("\uFEFF").lineSequence()) {
            val t = line.trim()
            if (openBlock != null) {
                if (t.equals("</$openBlock>", ignoreCase = true)) {
                    openBlock = null
                } else if (t.startsWith("</") || (t.startsWith("<") && t.endsWith(">"))) {
                    return fail("Ungültige oder verschachtelte Inline-Block-Markierung innerhalb <$openBlock>.")
                }
                continue
            }
            if (t.isEmpty() || t.startsWith("#") || t.startsWith(";")) continue
            if (t.startsWith("<") && t.endsWith(">") && !t.startsWith("</")) {
                val block = t.substring(1, t.length - 1).lowercase()
                if (block !in INLINE_BLOCKS) return fail("Nicht erlaubter Inline-Block <$block>.")
                openBlock = block
                continue
            }
            if (t.startsWith("</")) return fail("Unerwarteter schließender Inline-Block: $t")
            val parts = t.split(Regex("\\s+"))
            val directive = directiveOf(parts[0])
            if (directive in FORBIDDEN) {
                return fail("Nicht erlaubte Direktive \"$directive\" (könnte Skripte oder Programme ausführen).")
            }
            if (directive in FILE_DIRECTIVES && parts.size > 1 && parts[1] != "[inline]") {
                return fail("\"$directive\" verweist auf eine externe Datei. Bitte Inhalt direkt in <$directive>…</$directive> einfügen.")
            }
            if (directive == "remote" && parts.size > 1 && parts[1].isNotBlank()) hasRemote = true
        }
        if (openBlock != null) return fail("Block <$openBlock> wurde nicht geschlossen.")
        if (!hasRemote) return fail("Keine \"remote\"-Zeile gefunden – das ist keine gültige OpenVPN-Client-Konfiguration.")
        return Result.success(Unit)
    }

    /** OpenVPN and ics-openvpn accept quotes and escapes inside a token, so "up", 'up' and u"p" all mean the directive up. */
    private fun directiveOf(token: String): String =
        token.filterNot { it == '"' || it == '\'' || it == '\\' }.lowercase().removePrefix("--")

    private fun fail(message: String): Result<Unit> = Result.failure(IllegalArgumentException(message))
}
