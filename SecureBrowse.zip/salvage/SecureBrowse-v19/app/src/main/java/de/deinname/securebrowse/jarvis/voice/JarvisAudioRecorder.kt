package de.deinname.securebrowse.jarvis.voice

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/** Explicitly started/stopped microphone recording. Caller must obtain runtime permission first. */
class JarvisAudioRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var output: File? = null

    @Suppress("DEPRECATION")
    fun start(): File {
        check(recorder == null) { "Recording already active" }
        val file = File(context.getExternalFilesDir(null) ?: context.filesDir,
            "jarvis-audio-${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioSamplingRate(44100)
        r.setAudioEncodingBitRate(128000)
        r.setOutputFile(file.absolutePath)
        r.prepare()
        r.start()
        recorder = r; output = file
        return file
    }

    fun stop(): File? {
        val r = recorder ?: return null
        try { r.stop() } catch (_: RuntimeException) { output?.delete(); output = null; return null }
        finally { r.release(); recorder = null }
        val file = output; output = null
        return file?.takeIf { it.exists() && it.length() > 0 }
    }

    fun cancel() { recorder?.runCatching { stop() }; recorder?.release(); recorder = null; output?.delete(); output = null }
}
