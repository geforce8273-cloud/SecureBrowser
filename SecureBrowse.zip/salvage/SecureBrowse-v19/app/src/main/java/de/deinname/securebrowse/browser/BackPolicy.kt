package de.deinname.securebrowse.browser

sealed interface BackAction {
    data object CloseFullscreen : BackAction
    data object CloseDialogOrMenu : BackAction
    data object NavigateWebViewBack : BackAction
    data class CloseChildAndSwitch(val childTabId: String, val targetTabId: String) : BackAction
    data class SwitchToTab(val targetTabId: String) : BackAction
    data object PromptDoublePressToExit : BackAction
    data object ExitApp : BackAction
}

data class BackTab(
    val id: String,
    val parentTabId: String? = null,
    val canGoBack: Boolean = false,
    val lastUsedMs: Long = 0L
)

/** Reine Funktion (D1): berechnet aus dem Zustand die Zurueck-Aktion. Die App wird nie geschlossen, solange andere Tabs existieren. */
object BackPolicy {
    const val DOUBLE_BACK_WINDOW_MS = 2_000L

    fun compute(
        isFullscreen: Boolean,
        isDialogOrMenuOpen: Boolean,
        active: BackTab,
        allTabs: List<BackTab>,
        lastBackPressMs: Long,
        nowMs: Long
    ): BackAction {
        if (isFullscreen) return BackAction.CloseFullscreen
        if (isDialogOrMenuOpen) return BackAction.CloseDialogOrMenu
        if (active.canGoBack) return BackAction.NavigateWebViewBack
        val parent = active.parentTabId
        if (parent != null && allTabs.any { it.id == parent }) return BackAction.CloseChildAndSwitch(active.id, parent)
        val recent = allTabs.filter { it.id != active.id }.maxByOrNull { it.lastUsedMs }
        if (recent != null) return BackAction.SwitchToTab(recent.id)
        val delta = nowMs - lastBackPressMs
        return if (lastBackPressMs > 0L && delta in 0..DOUBLE_BACK_WINDOW_MS) BackAction.ExitApp else BackAction.PromptDoublePressToExit
    }
}
