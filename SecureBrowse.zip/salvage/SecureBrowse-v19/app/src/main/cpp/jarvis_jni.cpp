// JNI bridge between Kotlin (LlamaBridge) and llama.cpp.
//
// Design rules:
//  * One model, one context, guarded by g_mutex. Kotlin additionally serializes calls on a
//    single inference thread, so the mutex is only a safety net.
//  * nativeCancel() only touches an atomic flag and never takes g_mutex, so it works while a
//    generation is running. The flag is also polled by llama.cpp (abort callback) during prefill.
//  * Text crosses JNI as UTF-8 byte[] (never NewStringUTF): Java's "modified UTF-8" differs from
//    real UTF-8 for emoji, and token pieces can end in the middle of a character.
//  * Every per-token local reference is deleted, otherwise long answers overflow the JNI table.
//
// Written against the current llama.cpp C API (llama_model_load_from_file, llama_init_from_model,
// llama_memory_clear, llama_vocab_* ...). If llama.cpp renamed something, the first compile points
// at the exact line; see JARVIS_PHASE3.md.

#include <jni.h>
#include <android/log.h>
#include <sys/auxv.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"
#include "utf8_stream.h"

#define LOG_TAG "JarvisLlama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

// Result codes returned by nativeGenerate (>= 0 = finished, < 0 = error). Mirrored in Kotlin.
constexpr jint STOP_EOS = 0;
constexpr jint STOP_MAX_TOKENS = 1;
constexpr jint STOP_CANCELLED = 2;
constexpr jint STOP_TIMEOUT = 3;
constexpr jint ERR_NOT_LOADED = -1;
constexpr jint ERR_PROMPT_TOO_LONG = -2;
constexpr jint ERR_TEMPLATE = -3;
constexpr jint ERR_TOKENIZE = -4;
constexpr jint ERR_DECODE = -5;
constexpr jint ERR_JNI = -6;
// Result codes returned by nativeLoad (>= 0 = actual context size).
constexpr jint ERR_MODEL_LOAD = -10;
constexpr jint ERR_CONTEXT = -11;
constexpr jint ERR_KV_BUDGET = -12;

constexpr int MIN_CTX = 512;

struct Engine {
    llama_model* model = nullptr;
    llama_context* ctx = nullptr;
    const llama_vocab* vocab = nullptr;
    int n_ctx = 0;
    int n_batch = 0;
};

Engine g;
std::mutex g_mutex;
std::atomic<bool> g_cancel{false};
std::atomic<int64_t> g_deadline_ms{0};
std::mutex g_error_mutex;
std::string g_last_error;

int64_t now_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

void set_error(const std::string& message) {
    std::lock_guard<std::mutex> lock(g_error_mutex);
    g_last_error = message;
    LOGE("%s", message.c_str());
}

bool timed_out() {
    const int64_t deadline = g_deadline_ms.load();
    return deadline != 0 && now_ms() > deadline;
}

// Polled by ggml between graph nodes: returning true aborts llama_decode (it then returns 2).
bool abort_callback(void*) {
    return g_cancel.load() || timed_out();
}

void log_callback(ggml_log_level level, const char* text, void*) {
    const int prio = level == GGML_LOG_LEVEL_ERROR ? ANDROID_LOG_ERROR
                   : level == GGML_LOG_LEVEL_WARN  ? ANDROID_LOG_WARN
                                                   : ANDROID_LOG_DEBUG;
    __android_log_write(prio, LOG_TAG, text);
}

void unload_locked() {
    if (g.ctx) llama_free(g.ctx);
    if (g.model) llama_model_free(g.model);
    g = Engine{};
}

struct SamplerDeleter {
    void operator()(llama_sampler* s) const { if (s) llama_sampler_free(s); }
};

bool format_prompt(const char* tmpl, const std::vector<llama_chat_message>& messages, std::string& out) {
    size_t total = 0;
    for (const auto& m : messages) total += std::char_traits<char>::length(m.content) + 32;
    std::vector<char> buffer(std::max<size_t>(4096, total * 2));
    int32_t n = llama_chat_apply_template(tmpl, messages.data(), messages.size(), true, buffer.data(), (int32_t)buffer.size());
    if (n < 0) return false;
    if ((size_t)n > buffer.size()) {
        buffer.resize(n);
        n = llama_chat_apply_template(tmpl, messages.data(), messages.size(), true, buffer.data(), (int32_t)buffer.size());
        if (n < 0 || (size_t)n > buffer.size()) return false;
    }
    out.assign(buffer.data(), (size_t)n);
    return true;
}

bool tokenize(const std::string& text, std::vector<llama_token>& out) {
    // Chat templates already contain their special tokens as text -> parse_special=true,
    // add_special=false, and add BOS ourselves only if the model wants one and it is missing.
    const int32_t needed = -llama_tokenize(g.vocab, text.c_str(), (int32_t)text.size(), nullptr, 0, false, true);
    if (needed <= 0) return false;
    out.resize(needed);
    const int32_t n = llama_tokenize(g.vocab, text.c_str(), (int32_t)text.size(), out.data(), (int32_t)out.size(), false, true);
    if (n < 0) return false;
    out.resize(n);
    if (llama_vocab_get_add_bos(g.vocab)) {
        const llama_token bos = llama_vocab_bos(g.vocab);
        if (bos != LLAMA_TOKEN_NULL && (out.empty() || out[0] != bos)) out.insert(out.begin(), bos);
    }
    return true;
}

jint stop_reason_after_abort() {
    return (timed_out() && !g_cancel.load()) ? STOP_TIMEOUT : STOP_CANCELLED;
}

}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_de_deinname_securebrowse_jarvis_LlamaBridge_nativeCpuSupported(JNIEnv*, jobject) {
#if defined(__aarch64__)
#ifndef HWCAP_ASIMDDP
#define HWCAP_ASIMDDP (1 << 20)
#endif
    // The library is compiled for armv8.2-a+dotprod. On older CPUs that would crash with SIGILL.
    return (getauxval(AT_HWCAP) & HWCAP_ASIMDDP) != 0 ? JNI_TRUE : JNI_FALSE;
#else
    return JNI_FALSE;
#endif
}

JNIEXPORT jint JNICALL
Java_de_deinname_securebrowse_jarvis_LlamaBridge_nativeLoad(JNIEnv* env, jobject, jstring jpath,
                                                            jint n_ctx_cap, jint n_threads, jlong kv_budget_bytes) {
    std::lock_guard<std::mutex> lock(g_mutex);
    unload_locked();

    static std::once_flag backend_once;
    std::call_once(backend_once, [] {
        llama_log_set(log_callback, nullptr);
        llama_backend_init();
    });

    const char* raw_path = env->GetStringUTFChars(jpath, nullptr);
    if (!raw_path) return ERR_JNI;
    const std::string path(raw_path);
    env->ReleaseStringUTFChars(jpath, raw_path);

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;     // CPU only
    mp.use_mmap = true;      // weights are paged in from the file, not copied into anonymous RAM
    mp.use_mlock = false;    // never pin memory: the kernel must be able to reclaim it
    g.model = llama_model_load_from_file(path.c_str(), mp);
    if (!g.model) {
        set_error("model load failed (unsupported architecture/quantization, corrupt file or not enough memory)");
        return ERR_MODEL_LOAD;
    }
    g.vocab = llama_model_get_vocab(g.model);

    // Estimate the f16 KV cache and shrink the context until it fits the budget Kotlin computed.
    const int64_t n_layer = llama_model_n_layer(g.model);
    const int64_t n_head = llama_model_n_head(g.model);
    const int64_t n_head_kv = llama_model_n_head_kv(g.model);
    const int64_t n_embd = llama_model_n_embd(g.model);
    const int64_t n_embd_kv = n_head > 0 ? (n_embd / n_head) * n_head_kv : n_embd;
    const int64_t bytes_per_token = 2 /*K+V*/ * n_layer * n_embd_kv * 2 /*f16*/;

    int n_ctx = std::min<int>(n_ctx_cap, llama_model_n_ctx_train(g.model));
    while (n_ctx > MIN_CTX && bytes_per_token * n_ctx > kv_budget_bytes) n_ctx /= 2;
    if (bytes_per_token * n_ctx > kv_budget_bytes) {
        set_error("KV cache does not fit the memory budget even at the minimum context size");
        unload_locked();
        return ERR_KV_BUDGET;
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = n_ctx;
    cp.n_batch = std::min(512, n_ctx);
    cp.n_ubatch = std::min(256, (int)cp.n_batch);
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    g.ctx = llama_init_from_model(g.model, cp);
    if (!g.ctx) {
        set_error("context creation failed");
        unload_locked();
        return ERR_CONTEXT;
    }
    llama_set_abort_callback(g.ctx, abort_callback, nullptr);
    g.n_ctx = (int)llama_n_ctx(g.ctx);
    g.n_batch = (int)cp.n_batch;
    LOGI("model loaded: n_ctx=%d n_batch=%d threads=%d kv_est=%lld bytes", g.n_ctx, g.n_batch, (int)n_threads,
         (long long)(bytes_per_token * g.n_ctx));
    return g.n_ctx;
}

JNIEXPORT void JNICALL
Java_de_deinname_securebrowse_jarvis_LlamaBridge_nativeUnload(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    unload_locked();
}

JNIEXPORT void JNICALL
Java_de_deinname_securebrowse_jarvis_LlamaBridge_nativeCancel(JNIEnv*, jobject) {
    g_cancel.store(true);  // deliberately lock-free: must work while nativeGenerate holds g_mutex
}

JNIEXPORT jstring JNICALL
Java_de_deinname_securebrowse_jarvis_LlamaBridge_nativeLastError(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> lock(g_error_mutex);
    return env->NewStringUTF(g_last_error.c_str());  // messages in this file are plain ASCII
}

JNIEXPORT jint JNICALL
Java_de_deinname_securebrowse_jarvis_LlamaBridge_nativeGenerate(JNIEnv* env, jobject, jobjectArray jroles,
                                                                jobjectArray jcontents, jint max_new_tokens,
                                                                jlong timeout_ms, jobject callback) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g.ctx || !g.model) {
        set_error("no model loaded");
        return ERR_NOT_LOADED;
    }
    g_cancel.store(false);
    g_deadline_ms.store(timeout_ms > 0 ? now_ms() + timeout_ms : 0);

    // --- read conversation ------------------------------------------------------------------
    const jsize count = env->GetArrayLength(jroles);
    if (count <= 0 || count != env->GetArrayLength(jcontents)) {
        set_error("invalid conversation arrays");
        return ERR_JNI;
    }
    std::vector<std::string> roles(count), contents(count);
    for (jsize i = 0; i < count; ++i) {
        jstring jr = (jstring)env->GetObjectArrayElement(jroles, i);
        const char* r = jr ? env->GetStringUTFChars(jr, nullptr) : nullptr;
        if (!r) { set_error("invalid role"); return ERR_JNI; }
        roles[i] = r;
        env->ReleaseStringUTFChars(jr, r);
        env->DeleteLocalRef(jr);

        jbyteArray jc = (jbyteArray)env->GetObjectArrayElement(jcontents, i);
        if (!jc) { set_error("invalid content"); return ERR_JNI; }
        const jsize len = env->GetArrayLength(jc);
        contents[i].resize(len);
        if (len > 0) env->GetByteArrayRegion(jc, 0, len, reinterpret_cast<jbyte*>(&contents[i][0]));
        env->DeleteLocalRef(jc);
    }

    jclass cb_class = env->FindClass("de/deinname/securebrowse/jarvis/TokenCallback");
    jmethodID cb_method = cb_class ? env->GetMethodID(cb_class, "onToken", "([B)Z") : nullptr;
    if (!cb_method) {
        env->ExceptionClear();
        set_error("TokenCallback.onToken not found (R8/ProGuard rule missing?)");
        return ERR_JNI;
    }
    auto emit = [&](const std::string& piece) -> bool {
        jbyteArray arr = env->NewByteArray((jsize)piece.size());
        if (!arr) { env->ExceptionClear(); return false; }
        env->SetByteArrayRegion(arr, 0, (jsize)piece.size(), reinterpret_cast<const jbyte*>(piece.data()));
        const jboolean keep_going = env->CallBooleanMethod(callback, cb_method, arr);
        env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) { env->ExceptionClear(); return false; }
        return keep_going == JNI_TRUE;
    };

    // --- build the prompt, dropping the oldest turns until it fits ------------------------
    const int max_new = std::clamp<int>(max_new_tokens, 1, g.n_ctx / 2);
    const size_t budget = (size_t)(g.n_ctx - max_new);
    const bool has_system = roles[0] == "system";
    size_t first = has_system ? 1 : 0;  // first conversation message that is still kept

    const char* model_template = llama_model_chat_template(g.model, nullptr);
    std::vector<llama_token> tokens;
    for (;;) {
        std::vector<llama_chat_message> chat;
        if (has_system) chat.push_back({roles[0].c_str(), contents[0].c_str()});
        for (size_t i = first; i < (size_t)count; ++i) chat.push_back({roles[i].c_str(), contents[i].c_str()});

        std::string prompt;
        bool ok = model_template && format_prompt(model_template, chat, prompt);
        if (!ok) {
            if (model_template) LOGW("model chat template not supported by llama_chat_apply_template, using chatml");
            ok = format_prompt("chatml", chat, prompt);
        }
        if (!ok) { set_error("chat template could not be applied"); return ERR_TEMPLATE; }
        if (!tokenize(prompt, tokens)) { set_error("tokenization failed"); return ERR_TOKENIZE; }
        if (tokens.size() <= budget) break;

        if (first + 1 >= (size_t)count) {  // only the newest message is left and it is still too long
            set_error("prompt too long for the context window");
            return ERR_PROMPT_TOO_LONG;
        }
        ++first;
        if (first + 1 < (size_t)count && roles[first] == "assistant") ++first;  // keep user-first order
    }

    // --- prefill (in chunks: llama_decode rejects batches larger than n_batch) --------------
    llama_memory_clear(llama_get_memory(g.ctx), true);
    for (size_t i = 0; i < tokens.size(); i += (size_t)g.n_batch) {
        const int n = (int)std::min<size_t>((size_t)g.n_batch, tokens.size() - i);
        const int rc = llama_decode(g.ctx, llama_batch_get_one(tokens.data() + i, n));
        if (rc != 0) {
            if (g_cancel.load() || timed_out()) return stop_reason_after_abort();
            set_error("decode failed during prompt processing (code " + std::to_string(rc) + ")");
            return ERR_DECODE;
        }
    }

    // --- sample ------------------------------------------------------------------------------
    std::unique_ptr<llama_sampler, SamplerDeleter> sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()));
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    jarvis::Utf8Stream utf8;
    jint result = STOP_MAX_TOKENS;
    for (int generated = 0; generated < max_new;) {
        if (g_cancel.load() || timed_out()) { result = stop_reason_after_abort(); break; }

        llama_token token = llama_sampler_sample(sampler.get(), g.ctx, -1);
        if (llama_vocab_is_eog(g.vocab, token)) { result = STOP_EOS; break; }

        char small[256];
        int n = llama_token_to_piece(g.vocab, token, small, sizeof(small), 0, false);
        std::string piece;
        if (n >= 0) {
            piece.assign(small, (size_t)n);
        } else {
            std::vector<char> big((size_t)-n);
            n = llama_token_to_piece(g.vocab, token, big.data(), (int32_t)big.size(), 0, false);
            if (n > 0) piece.assign(big.data(), (size_t)n);
        }
        ++generated;

        const std::string complete = utf8.push(piece.data(), piece.size());
        if (!complete.empty() && !emit(complete)) { result = STOP_CANCELLED; break; }
        if (generated >= max_new) break;

        const int rc = llama_decode(g.ctx, llama_batch_get_one(&token, 1));
        if (rc != 0) {
            if (g_cancel.load() || timed_out()) { result = stop_reason_after_abort(); break; }
            set_error("decode failed while generating (code " + std::to_string(rc) + ")");
            return ERR_DECODE;
        }
    }
    const std::string tail = utf8.flush();
    if (!tail.empty()) emit(tail);
    return result;
}

}  // extern "C"
