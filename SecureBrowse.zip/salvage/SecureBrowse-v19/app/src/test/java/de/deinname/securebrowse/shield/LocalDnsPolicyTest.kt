package de.deinname.securebrowse.shield

import org.junit.Assert.*
import org.junit.Test

class LocalDnsPolicyTest {
    @Test fun blocksExactAndSubdomainsButNotLookalikes() {
        assertTrue(LocalDnsPolicy.isBlocked("doubleclick.net"))
        assertTrue(LocalDnsPolicy.isBlocked("ads.doubleclick.net"))
        assertTrue(LocalDnsPolicy.isBlocked("ADS.DOUBLECLICK.NET."))
        assertFalse(LocalDnsPolicy.isBlocked("notdoubleclick.net"))
        assertFalse(LocalDnsPolicy.isBlocked("example.org"))
    }

    @Test fun parsesDnsQuestionAndCreatesNxdomain() {
        val query = byteArrayOf(
            0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x03, 0x77, 0x77, 0x77, 0x0b, 0x64, 0x6f, 0x75,
            0x62, 0x6c, 0x65, 0x63, 0x6c, 0x69, 0x63, 0x6b,
            0x03, 0x6e, 0x65, 0x74, 0x00, 0x00, 0x01, 0x00, 0x01
        )
        assertEquals("www.doubleclick.net", LocalDnsPolicy.readQuestionName(query))
        val response = LocalDnsPolicy.makeNxDomain(query)!!
        assertEquals(0x12, response[0].toInt() and 0xff)
        assertEquals(0x83, response[3].toInt() and 0xff)
        assertEquals(query.size, response.size)
    }

    @Test fun rejectsResponsesAndMultipleQuestionQueries() {
        val valid = byteArrayOf(
            0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x03, 0x77, 0x77, 0x77, 0x07, 0x65, 0x78, 0x61,
            0x6d, 0x70, 0x6c, 0x65, 0x00, 0x00, 0x01, 0x00, 0x01
        )
        val response = valid.copyOf().also { it[2] = 0x81.toByte() }
        assertNull(LocalDnsPolicy.readQuestionName(response))
        val twoQuestions = valid.copyOf().also { it[5] = 2 }
        assertNull(LocalDnsPolicy.readQuestionName(twoQuestions))
        val upstream = valid.copyOf().also { it[2] = 0x81.toByte() }
        assertTrue(LocalDnsPolicy.isMatchingResponse(valid, upstream))
        val mismatched = upstream.copyOf().also { it[13] = 0x78 }
        assertFalse(LocalDnsPolicy.isMatchingResponse(valid, mismatched))
    }

    @Test fun malformedAndCompressedQuestionsAreRejected() {
        assertNull(LocalDnsPolicy.readQuestionName(byteArrayOf(1, 2, 3)))
        val compressed = ByteArray(18)
        compressed[2] = 1
        compressed[12] = 0xc0.toByte()
        assertNull(LocalDnsPolicy.readQuestionName(compressed))
        assertNull(LocalDnsPolicy.makeNxDomain(compressed))
    }
}
