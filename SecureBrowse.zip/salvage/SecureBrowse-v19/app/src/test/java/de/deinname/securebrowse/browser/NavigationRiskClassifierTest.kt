package de.deinname.securebrowse.browser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NavigationRiskClassifierTest {
    @Test fun httpsNormalHostIsLowRisk() {
        assertEquals(NavigationRiskClassifier.Risk.LOW, NavigationRiskClassifier.assess("https://example.com").risk)
    }
    @Test fun httpIsCaution() {
        val result = NavigationRiskClassifier.assess("http://example.com")
        assertEquals(NavigationRiskClassifier.Risk.CAUTION, result.risk)
        assertTrue(result.reasons.any { it.contains("HTTPS") })
    }
    @Test fun malformedTargetIsHighRisk() {
        assertEquals(NavigationRiskClassifier.Risk.HIGH, NavigationRiskClassifier.assess("not a url").risk)
    }
}
