package de.deinname.securebrowse.jarvis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class GgufHeaderTest {
    @Test fun validHeaderPasses() = assertNull(GgufHeader.validate(491_000_000L, 3, 290, 26))
    @Test fun tooSmallFileRejected() = assertNotNull(GgufHeader.validate(10, 3, 1, 1))
    @Test fun unsupportedVersionRejected() = assertNotNull(GgufHeader.validate(1_000_000, 1, 10, 10))
    @Test fun zeroTensorsRejected() = assertNotNull(GgufHeader.validate(1_000_000, 3, 0, 10))
    @Test fun absurdCountsRejected() = assertNotNull(GgufHeader.validate(1_000_000, 3, 20_000_000, 10))
    @Test fun truncatedFileRejected() = assertEquals("GGUF-Datei ist abgeschnitten oder beschädigt.", GgufHeader.validate(100, 3, 290, 26))
    @Test fun exactMinimumAccepted() = assertNull(GgufHeader.validate(24L + 13 + 33, 3, 1, 1))
}
