package de.deinname.securebrowse.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OvpnConfigValidatorTest {
    private val ok = "client\ndev tun\nproto udp\nremote vpn.example.org 1194\n<ca>\n-----BEGIN CERTIFICATE-----\nup evil.sh\n-----END CERTIFICATE-----\n</ca>\n"

    private fun assertRejected(config: String) = assertTrue(OvpnConfigValidator.validate(config).isFailure)

    // Text inside an inline block (here "up evil.sh" inside <ca>) is ignored.
    @Test fun acceptsValidInlineConfig() = assertTrue(OvpnConfigValidator.validate(ok).isSuccess)

    @Test fun acceptsDoubleDashAndTabSeparators() =
        assertTrue(OvpnConfigValidator.validate("client\n--remote\tvpn.example.org\t1194\n").isSuccess)

    @Test fun rejectsScriptDirectives() {
        assertRejected("$ok\nup /system/bin/sh")
        assertRejected("$ok\nscript-security 2")
        assertRejected("$ok\nplugin foo.so")
        assertRejected("$ok\niproute /system/bin/sh")
        assertRejected("$ok\npkcs11-providers /data/local/tmp/evil.so")
    }

    @Test fun rejectsDirectivesDisguisedByCaseDashesQuotesOrTabs() {
        assertRejected("$ok\nUP /system/bin/sh")
        assertRejected("$ok\n--up /system/bin/sh")
        assertRejected("$ok\n\"up\" /system/bin/sh")
        assertRejected("$ok\n'plugin' foo.so")
        assertRejected("$ok\nu\"p\" /system/bin/sh")
        assertRejected("$ok\nup\t/system/bin/sh")
    }

    @Test fun rejectsDirectiveBehindByteOrderMark() = assertRejected("\uFEFFup /system/bin/sh\n$ok")

    @Test fun rejectsExternalFiles() {
        assertRejected("client\nremote a 1194\nca ca.crt")
        assertRejected("client\nremote a 1194\nauth-user-pass login.txt")
        assertRejected("client\nremote a 1194\naskpass pass.txt")
    }

    @Test fun rejectsUnknownUnclosedAndUnexpectedBlocks() {
        // <connection> is not supported yet and is rejected on purpose (fail closed).
        assertRejected("client\nremote a 1194\n<connection>\nremote b 1194\n</connection>")
        assertRejected("client\nremote a 1194\n<ca>\nabc")
        assertRejected("client\nremote a 1194\n</ca>")
    }

    @Test fun sizeLimitCountsUtf8Bytes() {
        // About 140,000 characters but 280,000 UTF-8 bytes: over the 256 KiB limit, below 256 K characters.
        assertRejected("client\nremote a 1194\n# " + "\u00e4".repeat(140_000) + "\n")
    }

    @Test fun requiresRemote() = assertRejected("client\ndev tun")

    @Test fun rejectsBlankInput() = assertRejected("  \n")

    @Test fun detectsType() {
        assertEquals(VpnType.OPENVPN, VpnType.detect(ok, "x.ovpn"))
        assertEquals(VpnType.WIREGUARD, VpnType.detect("[Interface]\n[Peer]\n", "wg.conf"))
        assertEquals(VpnType.OPENVPN, VpnType.detect(ok, null))
    }
}
