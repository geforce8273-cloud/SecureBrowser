package de.deinname.securebrowse.tor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TorModeTest {
    @Test fun loopbackAccepted() = assertEquals("socks5://127.0.0.1:9050", ProxyEndpoint.loopbackOrNull("127.0.0.1", 9050)?.socksRule())
    @Test fun localhostBecomesIp() = assertEquals("127.0.0.1", ProxyEndpoint.loopbackOrNull("LocalHost", 9050)?.host)
    @Test fun ipv6Bracketed() = assertEquals("socks5://[::1]:9050", ProxyEndpoint.loopbackOrNull("::1", 9050)?.socksRule())
    @Test fun remoteHostRejected() = assertNull(ProxyEndpoint.loopbackOrNull("evil.example", 9050))
    @Test fun lanHostRejected() = assertNull(ProxyEndpoint.loopbackOrNull("192.168.1.2", 9050))
    @Test fun badPortRejected() = assertNull(ProxyEndpoint.loopbackOrNull("127.0.0.1", 70000))

    @Test fun failClosedUntilConnected() {
        val p = TorModePolicy()
        assertFalse(p.canLoad(TorState.OFF)); assertFalse(p.canLoad(TorState.STARTING)); assertFalse(p.canLoad(TorState.FAILED))
        assertTrue(p.canLoad(TorState.CONNECTED))
    }

    @Test fun defaultsAreStrict() {
        val p = TorModePolicy()
        assertFalse(p.persistentCookies || p.saveHistory || p.saveTabs || p.geolocation || p.cameraAndMic || p.allowHttpFallback)
        assertTrue(p.screenshotsBlocked && p.httpsOnly && p.unifiedUserAgent)
    }

    @Test fun noBackendFailsStart() {
        var failed = false
        NoTorBackend.start { failed = it.isFailure }
        assertTrue(failed)
    }
}
