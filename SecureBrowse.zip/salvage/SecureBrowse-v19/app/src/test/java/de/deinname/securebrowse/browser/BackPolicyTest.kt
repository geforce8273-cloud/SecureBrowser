package de.deinname.securebrowse.browser

import org.junit.Assert.assertEquals
import org.junit.Test

class BackPolicyTest {
    private fun run(active: BackTab, all: List<BackTab> = listOf(active), full: Boolean = false, dialog: Boolean = false, last: Long = 0, now: Long = 10_000) =
        BackPolicy.compute(full, dialog, active, all, last, now)

    @Test fun fullscreenFirst() = assertEquals(BackAction.CloseFullscreen, run(BackTab("a", canGoBack = true), full = true, dialog = true))
    @Test fun dialogBeforeWebBack() = assertEquals(BackAction.CloseDialogOrMenu, run(BackTab("a", canGoBack = true), dialog = true))
    @Test fun webBack() = assertEquals(BackAction.NavigateWebViewBack, run(BackTab("a", canGoBack = true)))

    @Test fun childClosesToParent() {
        val p = BackTab("p"); val c = BackTab("c", parentTabId = "p")
        assertEquals(BackAction.CloseChildAndSwitch("c", "p"), run(c, listOf(p, c)))
    }

    @Test fun switchesToMostRecentOtherTab() {
        val a = BackTab("a"); val b = BackTab("b", lastUsedMs = 5); val c = BackTab("c", lastUsedMs = 9)
        assertEquals(BackAction.SwitchToTab("c"), run(a, listOf(a, b, c)))
    }

    @Test fun neverExitsWithOtherTabs() {
        val a = BackTab("a"); val b = BackTab("b")
        assertEquals(BackAction.SwitchToTab("b"), run(a, listOf(a, b), last = 9_000, now = 9_500))
    }

    @Test fun singleTabFirstPressPrompts() = assertEquals(BackAction.PromptDoublePressToExit, run(BackTab("a")))
    @Test fun singleTabSecondPressExits() = assertEquals(BackAction.ExitApp, run(BackTab("a"), last = 9_000, now = 10_000))
    @Test fun singleTabLatePressPromptsAgain() = assertEquals(BackAction.PromptDoublePressToExit, run(BackTab("a"), last = 1_000, now = 10_000))
}
