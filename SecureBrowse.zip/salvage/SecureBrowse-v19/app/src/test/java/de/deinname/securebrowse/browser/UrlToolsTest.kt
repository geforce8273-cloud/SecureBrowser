package de.deinname.securebrowse.browser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlToolsTest {
    private val template = "https://duckduckgo.com/?q=%s"

    @Test fun httpsUrlIsKept() =
        assertEquals("https://example.org/a?b=c", UrlTools.resolve("https://example.org/a?b=c", template))

    @Test fun httpUrlIsKeptNotUpgraded() =
        assertEquals("http://example.org", UrlTools.resolve("http://example.org", template))

    @Test fun bareHostGetsHttps() =
        assertEquals("https://example.org", UrlTools.resolve("example.org", template))

    @Test fun hostWithPortGetsHttps() =
        assertEquals("https://localhost:8080", UrlTools.resolve("localhost:8080", template))

    @Test fun serverNameWithPortGetsHttps() {
        assertEquals("https://myserver:3000", UrlTools.resolve("myserver:3000", template))
        assertEquals("https://nas:8080/index.html", UrlTools.resolve("nas:8080/index.html", template))
    }

    @Test fun invalidPortBecomesSearch() =
        assertEquals("https://duckduckgo.com/?q=nas%3A99999", UrlTools.resolve("nas:99999", template))

    @Test fun httpServerWithPortIsKept() =
        assertEquals("http://10.0.0.5:8000/x", UrlTools.resolve("http://10.0.0.5:8000/x", template))

    @Test fun bareHostNeverDowngradesToHttp() {
        val r = UrlTools.resolveNavigation("nas:8080/x", template)
        assertEquals("https://nas:8080/x", r?.url)
    }

    @Test fun explicitHttpIsAcceptedOnlyWhenUserTypesIt() {
        assertEquals("http://example.org", UrlTools.resolveNavigation("http://example.org", template)?.url)
        assertEquals("https://example.org", UrlTools.resolveNavigation("example.org", template)?.url)
        assertEquals("https://duckduckgo.com/?q=hello+world", UrlTools.resolveNavigation("hello world", template)?.url)
    }

    @Test fun ipv4GetsHttps() =
        assertEquals("https://192.168.1.1/admin", UrlTools.resolve("192.168.1.1/admin", template))

    @Test fun textBecomesSearch() =
        assertEquals("https://duckduckgo.com/?q=hello+world", UrlTools.resolve("hello world", template))

    @Test fun singleWordBecomesSearch() =
        assertEquals("https://duckduckgo.com/?q=weather", UrlTools.resolve("weather", template))

    @Test fun javascriptIsRejected() = assertNull(UrlTools.resolve("javascript:alert(1)", template))

    @Test fun obfuscatedJavascriptIsRejected() = assertNull(UrlTools.resolve("java\nscript:alert(1)", template))

    @Test fun fileContentDataAreRejected() {
        assertNull(UrlTools.resolve("file:///sdcard/x", template))
        assertNull(UrlTools.resolve("content://media/x", template))
        assertNull(UrlTools.resolve("data:text/html,<b>x</b>", template))
    }

    @Test fun emptyInputIsRejected() {
        assertNull(UrlTools.resolve("", template))
        assertNull(UrlTools.resolve("   ", template))
    }

    @Test fun missingHostIsRejected() = assertNull(UrlTools.resolve("https://", template))

    @Test fun schemeActions() {
        assertEquals(UrlTools.SchemeAction.LOAD, UrlTools.schemeAction("HTTPS"))
        assertEquals(UrlTools.SchemeAction.EXTERNAL, UrlTools.schemeAction("mailto"))
        assertEquals(UrlTools.SchemeAction.EXTERNAL, UrlTools.schemeAction("intent"))
        assertEquals(UrlTools.SchemeAction.BLOCK, UrlTools.schemeAction("javascript"))
        assertEquals(UrlTools.SchemeAction.BLOCK, UrlTools.schemeAction("file"))
        assertEquals(UrlTools.SchemeAction.BLOCK, UrlTools.schemeAction(null))
    }

    @Test fun malformedExplicitUrlsAreRejected() {
        assertNull(UrlTools.resolve("https://example.org:99999/path", template))
        assertNull(UrlTools.resolve("https://exa mple.org", template))
        assertNull(UrlTools.resolve("https:///path", template))
    }

    @Test fun validIpv6ExplicitUrlIsAccepted() =
        assertEquals("https://[::1]:8080/path", UrlTools.resolve("https://[::1]:8080/path", template))

    @Test fun explicitUrlsWithUserInfoAreRejected() {
        assertNull(UrlTools.resolve("https://trusted.example@evil.example/", template))
        assertNull(UrlTools.resolve("http://user:pass@example.org/", template))
    }

    @Test fun invisibleDirectionAndFormattingControlsAreRejected() {
        assertNull(UrlTools.resolve("https://exa\u202Emple.org", template))
        assertNull(UrlTools.resolve("exam\u200Bple.org", template))
        assertNull(UrlTools.resolve("https://example.org/\u2066path", template))
    }

    @Test fun httpsDetection() {
        assertTrue(UrlTools.isHttps("HTTPS://a.b"))
        assertFalse(UrlTools.isHttps("http://a.b"))
        assertTrue(UrlTools.isHttp("http://a.b"))
    }


    @Test fun internationalizedHostsAreAccepted() {
        assertEquals("https://b\u00fccher.de", UrlTools.resolve("b\u00fccher.de", template))
        assertEquals("https://m\u00fcnchen.de:8443/x", UrlTools.resolve("https://m\u00fcnchen.de:8443/x", template))
    }

    @Test fun underscoreHostWithPortIsAccepted() =
        assertEquals("https://my_server:3000", UrlTools.resolve("my_server:3000", template))

    @Test fun relaxedHostsStillRejectTricks() {
        assertNull(UrlTools.resolve("https://bank.de@b\u00fccher.de/", template))
        assertNull(UrlTools.resolve("https://b\u00fccher.de:99999/", template))
        assertNull(UrlTools.resolve("https://b\u00fccher.de:abc/", template))
        assertNull(UrlTools.resolve("https://.b\u00fccher.de/", template))
        assertNull(UrlTools.resolve("https://b%C3%BCcher.de/", template))
    }
}
