# SecureBrowse v14 – technische Bestandsaufnahme und Änderungsbericht

Datum: 22.11.2026
Ausgangsbasis: `SecureBrowse-v13-local-ai-shield.zip`
Projektversion: 0.4.1 (versionCode 5)
Oberfläche: unverändert

## Reproduzierbar festgestellter Projektstand

- Android-Projekt mit Kotlin, Jetpack Compose, Android WebView und C++/JNI-Gerüst.
- 40 Kotlin-Dateien unter `app/src/main`, 11 vorhandene Kotlin-Testdateien im gelieferten Archiv.
- `gradle-wrapper.jar`, `gradlew` und `gradlew.bat` fehlen im Archiv.
- In der Arbeitsumgebung ist kein systemweites Gradle und kein Android SDK konfiguriert. Ein Android-Gradle-Build und die Kotlin-Unit-Tests konnten daher nicht ausgeführt werden.
- `app/src/main/cpp/llama.cpp` ist nicht vorhanden. `LlamaBridge` meldet die fehlende native Bibliothek korrekt; GGUF-Verwaltung ist keine Inferenz.
- `TorMode.kt` enthält `NoTorBackend`; es gibt keine Tor-Engine und keinen echten Tor-Datenverkehr.
- `LocalShieldVpnService` erstellt einen Android-VPN-Tunnel für einen synthetischen IPv4-DNS-Endpunkt. Der Code verarbeitet IPv4/UDP/DNS und schützt Upstream-Sockets mit `VpnService.protect()`. Das ist kein Gateway und ändert nicht die öffentliche IP.
- README und Implementierung weisen auf fehlende IPv6-DNS-Abdeckung, DNS-over-TCP-Fallback, DoH/DoT einzelner Apps und kleine eingebaute Filterliste hin.
- WireGuard ist über die offizielle Android-Tunnelbibliothek als Backend eingebunden; eine nutzbare Verbindung erfordert ein gültiges Benutzerprofil und Gerätetests. OpenVPN ist optional und nur vorhanden, wenn die separate GPLv2-Engine eingebunden wurde.
- Der Passwortmanager und ein allgemeiner verschlüsselter Dateitresor sind in der geprüften Quellstruktur nicht als vollständige Funktionen nachgewiesen.

## In v0.4.1 tatsächlich geändert

### Verschlüsselter VPN-Profil-Tresor

Vorher unterdrückte `all()` alle Entschlüsselungs-/Parsingfehler und gab `emptyList()` zurück. Dadurch konnten `save()` oder `delete()` einen Tresor, dessen AES-GCM-Authentifizierung fehlgeschlagen war, fälschlich als leer behandeln und den gespeicherten Ciphertext überschreiben.

Jetzt:
- fehlender Datensatz bedeutet weiterhin eine leere Liste;
- vorhandener, aber nicht authentifizierbarer/ungültiger Tresor führt zu einem Fehler statt zu einer leeren Liste;
- `save()` und `delete()` brechen in diesem Fall ab und verändern den vorhandenen Ciphertext nicht;
- Profilnamen, Steuerzeichen, leere Konfigurationen, maximale Konfigurationsgröße (512 KiB) und Backend-Typ werden validiert;
- SharedPreferences-Schreibvorgänge prüfen das Ergebnis von `commit()`;
- fünf JVM-Unit-Tests decken die reinen Validierungsregeln ab.

Geänderte Dateien:
- `app/src/main/java/de/deinname/securebrowse/vpn/EncryptedVpnProfileStore.kt`
- `app/src/test/java/de/deinname/securebrowse/vpn/VpnProfileValidationTest.kt` (neu)
- `app/build.gradle.kts` (Version 0.4.1 / versionCode 5)
- `README.md`
- `TECHNISCHE_BESTANDSAUFNAHME_V14.md` (neu)

Keine Layout-, Theme-, Navigations- oder Animationsdatei wurde verändert.

## Test- und Buildstatus

- ZIP-Archiv geöffnet und Dateiinventar geprüft.
- Android-Gradle-Build: NICHT AUSGEFÜHRT (Gradle/Wrapper/Android SDK fehlen).
- Kotlin-Unit-Tests: NICHT AUSGEFÜHRT (kein Gradle).
- Android-Gerätetest: NICHT AUSGEFÜHRT.
- Die neue Validierungslogik wurde statisch auf die Aufrufpfade `all()`, `save()` und `delete()` geprüft; die Android-Keystore-Verschlüsselung selbst ist hier nicht ausführbar.
- Ein erfolgreicher APK-Build wird ausdrücklich nicht behauptet.

## Release-Gates / noch offen

1. Echten Gradle-Wrapper mit `tools/bootstrap-gradle-wrapper.sh` erzeugen und dessen Download-Prüfsumme verifizieren.
2. Dependency-Versionen und Android-Gradle-Plugin auf einem Netz-fähigen Build-Rechner synchronisieren.
3. `:app:testDebugUnitTest`, `:app:verifyNoForbiddenDependencies` und `:app:assembleDebug` ausführen.
4. WireGuard-Profilimport, Android VPN-Zustimmung, IPv4/IPv6/DNS-Leaks, Reconnect und Netzwerkwechsel auf realen Geräten testen.
5. llama.cpp auf einen geprüften Commit pinnen, NDK/CMake-Build für passende ABIs durchführen und echte Token-Inferenz auf Android testen.
6. Tor-Engine samt WebView-Proxy-Integration und DNS-Leak-Tests auswählen und implementieren; bis dahin bleibt Tor nicht verfügbar.
7. Passwortmanager und verschlüsselten Dateitresor separat implementieren und auditieren.

## Funktionsstatus (keine Marketing-Versprechen)

| Funktion | Stand |
|---|---|
| Browser-Grundlage | Implementiert; Gerätetest/Release-Build offen |
| WebView-Härtung | Teilweise implementiert; kein vollständiger Schutz gegen alle Web-Angriffe |
| Lokaler DNS-Schutz | IPv4/UDP-Prototyp; eingeschränkte Filterliste und Abdeckung |
| WireGuard | Backend integriert; Verbindung nur mit gültiger Konfiguration, Gerätetest offen |
| OpenVPN | Optionales Backend; abhängig von nicht zwingend vorhandener Engine |
| JARVIS | Modellimport/-Download und JNI-Schnittstelle; native llama.cpp-Bibliothek fehlt |
| Tor | Nicht implementiert; `NoTorBackend` |
| Passwortmanager | Nicht als fertige Funktion nachgewiesen |
| Dateitresor | Nicht als fertige Funktion nachgewiesen |
