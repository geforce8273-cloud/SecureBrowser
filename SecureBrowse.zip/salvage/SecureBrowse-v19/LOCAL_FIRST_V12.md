# SecureBrowse v12 – Local-first design and honest capability map

## Product promise

SecureBrowse should work without a SecureBrowse account, paid subscription, telemetry backend, cloud AI endpoint, or VPN gateway operated by the project. Network access is still needed for ordinary websites and for downloading an AI model if the user does not already have one.

## What this version adds

### Local Shield VPN

- Uses Android `VpnService` with a local TUN interface.
- Routes only the synthetic DNS destination `10.77.0.2/32` into the interface.
- Intercepts IPv4/UDP DNS requests, applies a small local domain deny-list, and answers blocked names with NXDOMAIN.
- Sends allowed DNS questions using a socket protected from the VPN, to a resolver advertised by the current non-VPN Android network.
- Does not route general web traffic through a remote endpoint, does not encrypt the device's traffic, and does not change the public IP.
- Android's user consent dialog is mandatory. Android supports only one active VPN interface at a time.

### Local JARVIS

- Existing architecture imports a GGUF model into app-private storage and uses a native llama.cpp bridge for on-device inference.
- No prompts need to leave the device in local inference mode.
- No GGUF weights or llama.cpp checkout are included in this archive. A real native build and a model import are still required before JARVIS can answer.
- The project intentionally does not claim a turnkey offline AI until the native library and model have both been verified on a physical device.

## Important technical limits

1. Local Shield is an initial DNS-only implementation, not a full VPN. IPv6 DNS, TCP fallback, per-app DoH/DoT, DNS cache poisoning defenses, DNSSEC validation, and a remotely maintained blocklist are not implemented.
2. Allowed DNS requests use the resolver from the active physical network. SecureBrowse does not host or pay for that resolver. The network provider may log DNS queries according to its own policy.
3. A true IP-masking VPN requires a remote exit gateway. Without a remote gateway, SecureBrowse can filter traffic locally but cannot make the user's public IP appear elsewhere.
4. A local AI model is not cost-free in hardware terms: it consumes storage, RAM, CPU/GPU time, and battery. Model licensing varies. Smaller quantized models are more realistic on phones.
5. No build or physical-device test was run while preparing this archive. The added Android service and Compose integration must be compiled and tested before daily use.

## Required validation before release

- `./gradlew :app:testDebugUnitTest :app:assembleDebug`
- `./gradlew :app:verifyNoForbiddenDependencies`
- Install on Android 8–16 devices; verify VPN consent, foreground notification, stop/revoke, app restart, Wi-Fi/mobile handover, DNS success, blocked NXDOMAIN, and no loss of ordinary connectivity.
- Verify behavior with Android Private DNS enabled and with apps using DoH/DoT; explain bypasses in the UI.
- Run packet captures on a test device to confirm only the DNS destination enters the TUN and that the protected upstream socket does not loop back into the VPN.
- Build llama.cpp from a pinned upstream revision, verify the JNI ABI, load a small properly licensed GGUF model, test cancellation and memory pressure, then verify prompts still work with all network interfaces disabled.

## Official technical references

- Android VPN service lifecycle and packet interface: https://developer.android.com/develop/connectivity/vpn
- Android VpnService API: https://developer.android.com/reference/android/net/VpnService
- Android VpnService.Builder DNS and routing: https://developer.android.com/reference/android/net/VpnService.Builder
- llama.cpp Android guide: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
