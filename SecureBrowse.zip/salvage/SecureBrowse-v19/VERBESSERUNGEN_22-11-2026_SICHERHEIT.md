# SecureBrowse – technischer Sicherheitsdurchgang (22.11.2026)

## Unveränderte Oberfläche
Es wurden keine UI-/Theme-/Layout-Dateien geändert. Farben, Anordnung, Animationen und sichtbare Bedienelemente bleiben wie im gelieferten Projekt.

## Änderung
- Website-Anfragen für Kamera und Mikrofon werden jetzt nur noch bei einer syntaktisch gültigen HTTPS-Origin zur Bestätigung vorgelegt.
- HTTP-, ungültige und mit Benutzerinformationen manipulierte Origins werden direkt abgewiesen.
- Nicht unterstützte WebView-Ressourcen werden weiterhin abgewiesen; doppelte Ressourcen werden entfernt.
- Drei Unit-Tests decken HTTPS-Erlaubnis, unsichere/manipulierte Origins sowie unbekannte und doppelte Ressourcen ab.

## Bewusst nicht als fertig ausgegeben
- Tor ist weiterhin nur ein Backend-Platzhalter (`NoTorBackend`); es ist kein echter Tor-Datenverkehr implementiert.
- Safe Browsing ist aus Datenschutzgründen im gelieferten Projekt deaktiviert. Der lokale Ad-/Tracker-Filter ist keine vollständige EasyList.
- VPN-Verbindungen, JARVIS/llama.cpp und Android-Berechtigungsdialoge benötigen weiterhin Build- und Gerätetests.

## Verifikation
In dieser Arbeitsumgebung sind weder Gradle noch ein Android-SDK verfügbar. Deshalb wurden keine APK gebaut und keine Unit-Tests ausgeführt. Die Änderung ist Quelltext-seitig vorgenommen, aber noch nicht durch einen Android-Build bestätigt.

## SecureBrowse v16 – IPv6 DNS
- Der Local Shield DNS-Endpunkt ist zusätzlich über eine lokale IPv6-ULA-Adresse erreichbar.
- Nur die /128-Route zum virtuellen DNS-Endpunkt wird in den Tunnel aufgenommen; es wird kein IPv6-Standardroute-Tunnel behauptet.
- IPv6 UDP DNS wird mit korrektem UDP-Pseudoheader-Prüfsummenfeld beantwortet.
- IPv6 Extension Header und fragmentierte Pakete werden bewusst nicht verarbeitet.
