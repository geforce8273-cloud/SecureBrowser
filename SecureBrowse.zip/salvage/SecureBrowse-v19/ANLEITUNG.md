# APK ohne Android Studio bauen (GitHub Actions)

1. Auf https://github.com ein kostenloses Konto anlegen, "New repository" (privat ist ok).
2. Den kompletten Inhalt dieses Ordners hochladen (Add file -> Upload files). Wichtig: der versteckte Ordner `.github` muss mit.
3. Reiter "Actions" -> "Build APK" -> laeuft automatisch (oder "Run workflow").
4. Nach ca. 5-10 Minuten: auf den fertigen Lauf klicken -> unten "Artifacts" -> `SecureBrowse-debug-apk` herunterladen, entpacken, `app-debug.apk` aufs Handy und installieren ("Unbekannte Quellen" erlauben).

Die Server von GitHub haben Internet, Java, Android SDK und Gradle. Der Build wurde noch nie ausgefuehrt: bei Fehlern das Log aus "Actions" kopieren und mir schicken.

Ordner `web/`: die Webversion (securebrowse-lokal.html im Handy-Browser oeffnen).

## Lokale KI und kostenloser Geräteschutz

- JARVIS: In der App den lokalen Modell-Download ausdrücklich bestätigen (ca. 491 MB). Das Modell wird nur einmal geladen und bleibt danach auf dem Handy. Die native llama.cpp-Laufzeit muss zusätzlich in den Android-Build eingebunden werden; siehe `JARVIS_PHASE3.md`.
- Lokaler Schutz: In der VPN-Ansicht „Kostenlosen lokalen Schutz aktivieren“ wählen und die Android-Systemberechtigung bestätigen. Das ist ein DNS-Filter ohne SecureBrowse-Server, kein IP-Wechsel-VPN.
- Für einen echten IP-Wechsel muss ein WireGuard-/OpenVPN-Ausgangsserver existieren. SecureBrowse mietet oder betreibt keinen solchen Server.
