# Design-Update (Lila-Revolution)

- Neuer Farbverlauf: oben Weiß -> unten Lila (Hell- und Dunkelmodus), mit langsam wandernden Leuchtflecken (`ui/BrandFx.kt`, `AuroraBackground`). Respektiert "Animationen entfernen".
- Obere Leiste: Adressfeld jetzt 40 dp statt ~72 dp Gesamthöhe (BasicTextField statt OutlinedTextField), Glas-Optik, animierter Rahmen beim Fokus.
- Tab-Leiste erscheint nur noch bei mehr als einem Tab, Chips nur 30 dp hoch.
- Untere Leiste: nur Symbole (44 dp), federnder Aktiv-Effekt, Verlaufs-Linie oben. Tor-Leiste einzeilig (~34 dp).
- Ladebalken: 2 dp mit Farbverlauf und wanderndem Glanz.
- Startseite: pulsierender Schild-Orb mit Farbring, Verlaufs-Überschrift, schwebende Glas-Kacheln (2x2).
- Seitenübergänge: Slide + Fade + Scale zwischen allen Screens.
- Tap-Effekt: violettes Leuchten statt grün.
- Alle Unterseiten (Lesezeichen, Verlauf, Tabs, VPN, JARVIS) sind transparent und zeigen denselben Verlauf.

Hinweis: nicht kompiliert (kein Gradle/Netz in der Umgebung). Bitte einmal `./gradlew assembleDebug` laufen lassen.

## Leisten beim Scrollen ausblenden
- Nach unten scrollen: Adressleiste, Tab-Leiste, Tor-Leiste und untere Leiste fahren weich weg (nur der 2-dp-Ladebalken bleibt).
- Nach oben scrollen, ganz oben sein, neue Seite oder Tabwechsel: Leisten kommen wieder.
- Auf der Startseite (leerer Tab) bleiben die Leisten immer sichtbar.
- Umsetzung: `WebViewRegistry.chromeHidden` (Scroll-Listener mit Schwellwerten + 500 ms Sperre gegen Zittern beim Größenwechsel), `BrowserScreen` nutzt `AnimatedVisibility`.
