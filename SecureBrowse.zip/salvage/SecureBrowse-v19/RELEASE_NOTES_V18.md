# SecureBrowse v18 – Sicherheits-Härtung (Arbeitsstand 22.11.2026)

## Änderungen
- Adressleisten-Navigation weist URLs mit User-Info (`name:passwort@host`) zurück. Das verhindert die besonders irreführende Form `https://vertrauenswuerdig.example@angreifer.example`.
- Unsichtbare Unicode-Format- und Schreibrichtungszeichen werden in Adresseingaben abgelehnt, statt sie in Hostnamen oder Pfade zu übernehmen.
- JARVIS-Webseitentextfilter entfernt dieselben unsichtbaren Steuerzeichen zusätzlich zu ISO-Kontrollzeichen.
- Die maximale Menge an in den JARVIS-Prompt übernommenem Seitentext ist jetzt hart auf 6.000 Zeichen begrenzt. Negative oder übergroße Aufrufer-Limits können die Begrenzung nicht mehr umgehen oder einen Laufzeitfehler auslösen.
- Neue JVM-Regressionstests für URL-Spoofing und Prompt-Grenzfälle.
- GitHub-Actions-Workflow richtet Android-SDK explizit ein und dokumentiert korrekt, dass der Debug-APK-CI-Job JARVIS-Native deaktiviert. Der separate Host-UTF-8-Test bleibt enthalten.

## Tests in dieser Arbeitsumgebung
- 28 gezielte JVM-Tests für `UrlTools` und `PromptSafety`: bestanden.
- Ausgeführt mit `kotlinc` und einem minimalen JUnit-kompatiblen Test-Runner, **nicht** mit Gradle/JUnit.
- Gradle-/Android-Build konnte nicht gestartet werden: Wrapper-Download von `services.gradle.org` scheiterte an DNS (`UnknownHostException`).

## Bewusst nicht als erledigt ausgewiesen
- Keine Android-APK gebaut oder auf einem Gerät getestet.
- Keine ARM64-/NDK-Kompilierung der nativen JARVIS-Bibliothek.
- Keine echte JARVIS-Inferenz, kein GGUF-Modelltest.
- Tor-Modus bleibt ohne Tor-Backend nicht funktionsfähig; IPv6-DNS-Schutz ist kein vollständiger IPv6-Kill-Switch.
- Kein Passwortmanager/Vault und keine vollständige Phishing-Reputationsdatenbank.

## Design
- Keine Dateien in `ui/` oder `res/` geändert. Die bestehende Design-Sperre bleibt eingehalten.
