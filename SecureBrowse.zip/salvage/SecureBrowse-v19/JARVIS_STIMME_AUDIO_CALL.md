# JARVIS Voice (v19 increment)

Added non-UI Android voice primitives under `jarvis/voice`:

- `JarvisVoiceIO`: Android TTS and synthesize-to-file audio export, selectable language tags, local-engine voice preference hints
  (`female`, `male`, `neutral`), speak/cancel, installed-language listing, SpeechRecognizer intent/factory.
- `JarvisAudioRecorder`: explicit microphone recording to app-private external-files storage (M4A/AAC),
  with start/stop/cancel and failure cleanup.

## Important limitations / integration steps
- These are code components, not UI wiring. The design lock on `ui/` and `res/` was respected.
- Microphone runtime permission must be requested by the calling activity before recording/recognition.
- Speech recognition availability, language packs, and offline behavior are device/service-dependent.
  SpeechRecognizer may use a network service; offline use is not guaranteed.
- TTS language and gender presentation are best-effort engine-dependent preferences. Android engine
  voice metadata does not reliably encode gender, and naturalness differs by installed engine.
- Saved audio remains in the app's files area. No audio upload or call recording behavior is added.
- Live duplex voice-call mode (low-latency streaming, interruption handling, echo cancellation and
  server/API transport) is not implemented here; it needs a session transport and UI controls.
- Neither build nor device tests have been run in this environment.

## API usage outline
Initialize `JarvisVoiceIO`, request microphone permission, use `createRecognizer()` and
`recognitionIntent(languageTag)` with a RecognitionListener, call `selectVoice("de-DE", "female")`
or `"male"`, and `speak(text)`. Recording requires `JarvisAudioRecorder.start()` / `stop()`.
