#!/usr/bin/env bash
# Holt ics-openvpn (OpenVPN für Android, GPLv2) nach third_party/ics-openvpn, auf einen festen Tag gepinnt.
# Tags: https://github.com/schwabe/ics-openvpn/tags   Aufruf: tools/add-openvpn.sh <tag>
# ACHTUNG: GPLv2 – wird die App mit dieser Engine verteilt, muss SecureBrowse ebenfalls unter GPLv2 stehen.
set -euo pipefail
TAG="${1:?Tag angeben, z. B. tools/add-openvpn.sh v0.7.xx}"
cd "$(dirname "$0")/.."
rm -rf third_party/ics-openvpn
git clone --branch "$TAG" --depth 1 --recurse-submodules --shallow-submodules \
  https://github.com/schwabe/ics-openvpn.git third_party/ics-openvpn
echo "OK: ics-openvpn $TAG in third_party/ics-openvpn. Danach: ./gradlew :app:assembleDebug"
