#!/usr/bin/env python3
"""Erzeugt res/raw/drop.wav neu: synthetischer Wassertropfen, 22,05 kHz, 16 Bit, mono, 220 ms. Keine fremden Samples."""
import wave, math, struct
sr = 22050
n = int(sr * 0.22)
ph = 0.0
out = []
for i in range(n):
    t = i / sr
    f = 520 + 900 * (1 - math.exp(-t * 38))
    ph += 2 * math.pi * f / sr
    env = math.exp(-t * 20) * min(1.0, t / 0.003)
    s = 0.6 * env * (math.sin(ph) + 0.25 * math.sin(2 * ph)) / 1.25
    out.append(int(max(-1, min(1, s)) * 32767))
w = wave.open("app/src/main/res/raw/drop.wav", "wb")
w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
w.writeframes(b"".join(struct.pack("<h", d) for d in out)); w.close()
