#!/usr/bin/env bash
# Holt llama.cpp in app/src/main/cpp/llama.cpp. Bewusst auf einen festen Tag/Commit gepinnt,
# damit der Build reproduzierbar bleibt. Tag-Liste: https://github.com/ggml-org/llama.cpp/tags
set -euo pipefail
REF="${1:?Aufruf: tools/add-llama-cpp.sh <llama.cpp-tag-oder-commit>   z.B. bNNNN}"
cd "$(dirname "$0")/.."
DEST=app/src/main/cpp/llama.cpp
URL=https://github.com/ggml-org/llama.cpp

if [ -e "$DEST/CMakeLists.txt" ]; then echo "$DEST existiert bereits." >&2; exit 1; fi
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git submodule add "$URL" "$DEST"
  git -C "$DEST" checkout --quiet "$REF"
  git add .gitmodules "$DEST"
  echo "Als Submodul hinzugefügt ($REF). Bitte committen."
else
  git clone --quiet "$URL" "$DEST"
  git -C "$DEST" checkout --quiet "$REF"
  rm -rf "$DEST/.git"
  echo "Als Kopie hinzugefügt ($REF). Kein Git-Repo erkannt, daher ohne Submodul."
fi
