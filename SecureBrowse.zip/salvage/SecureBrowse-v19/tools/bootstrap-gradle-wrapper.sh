#!/usr/bin/env bash
# Erzeugt gradlew, gradlew.bat und gradle/wrapper/gradle-wrapper.jar mit der in
# gradle-wrapper.properties genannten Gradle-Version. Die Distribution wird gegen die von
# Gradle veröffentlichte SHA-256-Prüfsumme verifiziert. Voraussetzung: JDK 17+, curl, unzip.
set -euo pipefail
cd "$(dirname "$0")/.."

VERSION=$(sed -n 's#.*gradle-\([0-9][0-9.]*\)-bin\.zip.*#\1#p' gradle/wrapper/gradle-wrapper.properties | head -n1)
[ -n "$VERSION" ] || { echo "Gradle-Version nicht in gradle-wrapper.properties gefunden" >&2; exit 1; }
command -v java >/dev/null || { echo "Java (JDK 17+) fehlt: sudo pacman -S jdk17-openjdk" >&2; exit 1; }

WORK=$(mktemp -d); trap 'rm -rf "$WORK"' EXIT
BASE="https://services.gradle.org/distributions/gradle-${VERSION}-bin.zip"
echo "Lade Gradle ${VERSION} ..."
curl -fsSL "$BASE" -o "$WORK/gradle.zip"
EXPECTED=$(curl -fsSL "${BASE}.sha256" | tr -d '[:space:]')
ACTUAL=$(sha256sum "$WORK/gradle.zip" | cut -d' ' -f1)
[ "$EXPECTED" = "$ACTUAL" ] || { echo "SHA-256 stimmt nicht (erwartet $EXPECTED, erhalten $ACTUAL)" >&2; exit 1; }
unzip -q "$WORK/gradle.zip" -d "$WORK"

# In einem leeren Verzeichnis erzeugen, damit die Projektkonfiguration (Plugins/Netz) nicht beteiligt ist.
mkdir "$WORK/empty" && cd "$WORK/empty"
"$WORK/gradle-${VERSION}/bin/gradle" wrapper --gradle-version "$VERSION" --distribution-type bin \
  --gradle-distribution-sha256-sum "$ACTUAL" --no-daemon -q
cd - >/dev/null

mkdir -p gradle/wrapper
cp "$WORK/empty/gradlew" "$WORK/empty/gradlew.bat" .
cp "$WORK/empty/gradle/wrapper/gradle-wrapper.jar" "$WORK/empty/gradle/wrapper/gradle-wrapper.properties" gradle/wrapper/
chmod +x gradlew
echo "Fertig. Wrapper-JAR SHA-256: $(sha256sum gradle/wrapper/gradle-wrapper.jar | cut -d' ' -f1)"
echo "Jetzt: ./gradlew :app:assembleDebug   (und gradlew, gradlew.bat, gradle/wrapper/* committen)"
