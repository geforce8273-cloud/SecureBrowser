# SecureBrowse v0.4.2 – HTTPS-Schutz

## Änderung
- Automatischer Rückfall von HTTPS auf HTTP vollständig entfernt.
- Bare Hosts werden ausschließlich als HTTPS aufgelöst.
- Explizit eingegebene `http://`-Adressen bleiben für lokale Geräte/Legacy-Dienste möglich und werden weiterhin als unsicher markiert.
- Zertifikatsfehler werden weiterhin nicht automatisch akzeptiert.
- Tests angepasst: Bare Hosts haben keinen HTTP-Fallback; explizites HTTP bleibt explizit.

## Sicherheitsgrenze
Dies ist Schutz vor stiller Protokoll-Herabstufung, noch kein strikt erzwungener HTTPS-only-Modus. Explizite HTTP-Eingaben sind weiterhin möglich.

## Prüfung
- Quelltext-Suche: keine HTTP-Fallback-Map, kein automatischer `loadUrl(http://...)`-Pfad und keine zugehörigen UI-Meldungen mehr.
- XML- und Quelltextprüfungen folgen im Release-Check.
