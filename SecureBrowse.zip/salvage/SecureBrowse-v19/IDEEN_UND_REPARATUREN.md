# SecureBrowse – zusätzlicher Verbesserungsstand

## In dieser Runde tatsächlich geändert
- Fehlerhafte, wörtliche `\\n`-Zeilenumbrüche in `JarvisScreen.kt` bereinigt, die als Kotlin-Code ungültig waren.
- `PromptSafety.kt` auf korrekt escaped newline/tab-Zeichen und echte newline-Ausgabe überprüft/berichtigt.
- Neue Offline-Hinweisfunktion `NavigationRiskClassifier`: liefert LOW/CAUTION/HIGH und nachvollziehbare Hinweise zu HTTP, ungültigen URLs, Punycode und ungewöhnlichen Hostnamen. Diese Hinweise sind advisory und keine Phishing-Erkennung bzw. Blockliste.
- JVM-Tests für den neuen URL-Hinweisklassifizierer hinzugefügt.
- GitHub Actions um eine 16-KiB-APK-Alignment-Prüfung ergänzt.

## Weitere Ideen (noch nicht umgesetzt)
- Anti-Phishing: regelmäßig aktualisierte, lokale/privatsphärische Bedrohungslisten mit klarer Kennzeichnung der Herkunft und Fehlalarm-Möglichkeit.
- Datenschutzbericht pro Sitzung: Tracker-/Cookie-/HTTPS-Informationen, ohne besuchte URLs zentral zu übertragen.
- DNS/VPN Kill-Switch mit klarer Zustandsanzeige und echten End-to-End-Leaktests; nicht nur DNS-Paketfilter.
- JARVIS: explizite Zustimmung vor Webaktionen, nachvollziehbare Tool-Ausgaben, lokale Gesprächsnotizen mit Lösch-/Exportoption.
- Barrierefreiheit: TalkBack, Tastatur-/Switch-Navigation und dynamische Textgrößen.

## Verifikation
Die Änderungen wurden in dieser Runde nicht mit Android Gradle/SDK oder auf einem Gerät gebaut bzw. getestet. Die CI-Prüfung ist erst nach einem GitHub Actions Lauf bestätigt.
