# Reparatur-/Prüfrunde (27.11.2026)

- `JarvisModelManager.kt`: Modellimport ersetzt ein vorheriges Modell jetzt mit `Files.move(..., REPLACE_EXISTING)` statt erst die vorhandene Datei zu löschen und danach Rename zu versuchen. So wird das vorhandene Modell bei einem Rename-Fehler nicht unnötig verloren.
- Unbenutzte Imports in dieser Datei entfernt.
- `ui/` und `res/` wurden bei dieser Reparatur nicht verändert.
- Build/Test nicht ausgeführt: in der Prüf-Umgebung ist kein Gradle installiert und der ZIP enthält keine `gradle-wrapper.jar`; der Android-Gradle-Build ist damit hier nicht verifiziert.
- GitHub Actions Workflow verwendet eine bereitgestellte Gradle-Installation und ist daher nicht auf die fehlende Wrapper-JAR angewiesen.

