# SecureBrowse v17 – Native JARVIS (versionName 0.5.0, versionCode 8)

## Was neu ist
- llama.cpp **b10000** eingebunden (`app/src/main/cpp/llama.cpp/`, MIT-Lizenz, gekürzt: CMakeLists, cmake, include, src, ggml, licenses). Version und Commit stehen in `VENDORED_VERSION.txt`.
  Neuere Tags wurden nicht verwendet, weil die vorhandene JNI-Datei die b10000-API nutzt.
- Gradle-Wrapper ergänzt (`gradle-wrapper.jar`, `gradlew`, `gradlew.bat`) aus der Gradle-9.6.0-Distribution; deren SHA-256 stimmt mit `distributionSha256Sum` überein. `gradle-wrapper.properties` unverändert.
- Neu: `GgufHeader.kt` prüft GGUF-Header zusätzlich auf abgeschnittene Dateien; `JarvisModelManager.inspect()` nutzt es. Dazu `GgufHeaderTest.kt` (7 Tests).
- Version von 0.4.3 / 7 auf 0.5.0 / 8 erhöht.

## Tatsächlich geprüft
- `jarvis_jni.cpp` kompiliert gegen die echten b10000-Header (Host g++, C++17, JNI-Header aus OpenJDK 21; nur `android/log.h` ist ein Stub).
- llama.cpp b10000 baut auf dem **Host (x86_64, nicht Android)** vollständig (193/193 Ninja-Schritte), CMake-Konfiguration funktioniert.
- JNI-Code linkt gegen die echten statischen Bibliotheken (alle Symbole aufgelöst).
- Nativer UTF-8-Stream-Test: bestanden.
- `GgufHeaderTest`: 7/7 bestanden – mit Kotlin 2.4.10 und einem minimalen JUnit-Ersatz (kein echtes JUnit).

## NICHT geprüft
- Android-Gradle-Build, NDK/ARM-Kompilierung, APK, Test auf Gerät.
- Echte Inferenz (Laden, Streaming, Abbruch) – es gab hier kein GGUF-Modell (huggingface.co gesperrt). Qwen-SHA-256 nicht gegen die offizielle Quelle verifiziert.
- Die geänderte `JarvisModelManager.kt` wurde nicht kompiliert (braucht Android SDK).
- Die vorhandenen v16-Tests wurden in dieser Runde nicht erneut ausgeführt.
- Bestehende Android-Unit-Tests (WebPermissionPolicy, VpnProfileValidation) nicht ausgeführt.

## Noch offen
DNS/IPv6-Verbesserungen, Phishing-Schutz, echter Tor-Modus, Passwortmanager/Tresor – in dieser Runde nicht begonnen.
Design: keine UI-Datei und keine Ressource wurde verändert.
