pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "SecureBrowse"
include(":app")
// Optional: eingebettete OpenVPN-Engine (ics-openvpn). Holen mit tools/add-openvpn.sh <tag>.
val openVpnDir = file("third_party/ics-openvpn/main")
if (openVpnDir.resolve("build.gradle").exists() || openVpnDir.resolve("build.gradle.kts").exists()) {
    include(":openvpn")
    project(":openvpn").projectDir = openVpnDir
}
