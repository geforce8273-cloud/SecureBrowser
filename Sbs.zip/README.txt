SecureBrowse 2.0 – Quellcode-Projekt (Android Studio, Kotlin + Compose)
1) In Android Studio öffnen. 2) Firebase-Projekt anlegen, Android-App "de.deinname.securebrowse" registrieren,
3) Build > Build APK. API-Schlüssel danach im Admin-Bereich eintragen.
