package de.deinname.securebrowse.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.HttpAuthHandler
import android.webkit.MimeTypeMap
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import de.deinname.securebrowse.R

/**
 * Owns one WebView per tab. Owned by the Activity (WebViews hold the Activity context),
 * all UI state flows into [BrowserViewModel]. There is deliberately NO addJavascriptInterface.
 */
class WebViewRegistry(
    private val activity: ComponentActivity,
    private val viewModel: BrowserViewModel
) {
    private val views = HashMap<Long, WebView>()
    private var mixedAllowed = false

    private fun mixedMode() =
        if (mixedAllowed) WebSettings.MIXED_CONTENT_ALWAYS_ALLOW else WebSettings.MIXED_CONTENT_NEVER_ALLOW

    /** Opt-in: lets https pages load http content (needed by some video streams). Off by default. */
    fun setMixedContentAllowed(allowed: Boolean) {
        mixedAllowed = allowed
        views.values.forEach { it.settings.mixedContentMode = mixedMode() }
    }

    /** Per tab: http:// address to try once if the https:// attempt for a typed bare host fails. */
    private val httpFallbacks = HashMap<Long, String>()
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    fun peek(tabId: Long): WebView? = views[tabId]

    fun getOrCreate(tabId: Long, initialUrl: String): WebView =
        views[tabId] ?: create(tabId).also {
            views[tabId] = it
            if (initialUrl.isNotBlank()) it.loadUrl(initialUrl)
        }

    /** Loads [url] in the tab: directly if a WebView exists, otherwise via tab state (WebView created on first composition). */
    fun load(tabId: Long, url: String, httpFallback: String? = null) {
        if (httpFallback != null) httpFallbacks[tabId] = httpFallback else httpFallbacks.remove(tabId)
        val view = views[tabId]
        if (view != null) view.loadUrl(url) else viewModel.setTabUrl(tabId, url)
    }

    fun remove(tabId: Long) {
        httpFallbacks.remove(tabId)
        views.remove(tabId)?.let(::destroyWebView)
    }

    fun exitFullscreen() {
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        viewModel.setCustomView(null)
    }

    fun destroyAll() {
        exitFullscreen()
        views.values.forEach(::destroyWebView)
        views.clear()
    }

    private fun destroyWebView(view: WebView) {
        (view.parent as? ViewGroup)?.removeView(view)
        view.stopLoading()
        view.webChromeClient = null
        view.destroy()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun create(tabId: Long): WebView = WebView(activity).apply {
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        settings.apply {
            javaScriptEnabled = true            // needed by websites; no native bridge is ever exposed
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = mixedMode()
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)     // pop-ups are decided in onCreateWindow
            setGeolocationEnabled(false)
            safeBrowsingEnabled = false          // no Google Safe Browsing: pages are never blocked by Google's list
            mediaPlaybackRequiresUserGesture = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)

        setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            if (url.startsWith("https://") || url.startsWith("http://")) {
                viewModel.requestDownload(url, userAgent.orEmpty(), contentDisposition.orEmpty(), mimeType.orEmpty(), contentLength)
            } else {
                viewModel.showMessage(R.string.downloads_unavailable)
            }
        }

        webViewClient = object : WebViewClient() {
            // Filter ad and tracking network requests. This does not enable Safe Browsing
            // and does not create or activate a user-managed website blocklist.
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): android.webkit.WebResourceResponse? {
                if (request != null && AdBlocker.shouldBlock(request.url)) {
                    return AdBlocker.blockedResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null) return true
                val uri = request.url
                return when (UrlTools.schemeAction(uri.scheme)) {
                    UrlTools.SchemeAction.LOAD -> false
                    UrlTools.SchemeAction.BLOCK -> {
                        viewModel.showMessage(R.string.blocked_scheme)
                        true
                    }
                    UrlTools.SchemeAction.EXTERNAL -> {
                        // External apps are only offered for user-initiated navigations, then confirmed in a dialog.
                        if (request.hasGesture()) {
                            val intent = ExternalIntents.build(uri.toString())
                            if (intent != null) viewModel.requestExternal(uri.toString(), intent)
                            else viewModel.showMessage(R.string.blocked_scheme)
                        }
                        true
                    }
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                viewModel.onPageStarted(tabId, url.orEmpty())
            }

            // HTTPS first for typed bare hosts; if the connection fails, try plain HTTP once (the UI shows the HTTP warning).
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (view == null || request == null || !request.isForMainFrame) return
                val fallback = httpFallbacks[tabId] ?: return
                if (!UrlTools.isHttps(request.url.toString())) return
                if (error?.errorCode !in HTTP_FALLBACK_ERRORS) return
                httpFallbacks.remove(tabId)
                viewModel.showMessage(R.string.https_failed_trying_http)
                view.loadUrl(fallback)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                httpFallbacks.remove(tabId)
                viewModel.onPageFinished(
                    tabId, url.orEmpty(), view?.title.orEmpty(),
                    view?.canGoBack() == true, view?.canGoForward() == true
                )
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                viewModel.onNavigation(tabId, url.orEmpty(), view?.canGoBack() == true, view?.canGoForward() == true)
            }

            // Certificate errors are never accepted automatically: the user decides in a warning dialog
            // (continue / cancel). The decision is valid for this one error only and is not remembered.
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                if (handler == null) return
                viewModel.requestSslDecision(
                    tabId, error?.url.orEmpty(), error?.primaryError ?: SslError.SSL_INVALID, handler
                )
            }

            override fun onReceivedHttpAuthRequest(
                view: WebView?, handler: HttpAuthHandler?, host: String?, realm: String?
            ) {
                if (handler == null) return
                viewModel.requestHttpAuth(host.orEmpty(), realm.orEmpty(), handler)
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                remove(tabId)
                viewModel.onRendererGone(tabId)
                return true // handled: the app must not crash because a tab's renderer died
            }
        }

        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) = viewModel.onProgress(tabId, newProgress)

            override fun onReceivedTitle(view: WebView?, title: String?) = viewModel.onTitle(tabId, title.orEmpty())

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) = viewModel.onFavicon(tabId, icon)

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null) return false
                viewModel.requestFileChooser(
                    FileChooserRequest(
                        acceptTypes = fileChooserParams?.acceptTypes?.toList().orEmpty(),
                        allowMultiple = fileChooserParams?.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE,
                        callback = filePathCallback
                    )
                )
                return true
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                if (view == null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customViewCallback?.onCustomViewHidden()
                customViewCallback = callback
                viewModel.setCustomView(view)
            }

            override fun onHideCustomView() = exitFullscreen()

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                viewModel.requestPermission(request.origin.toString(), request.resources.toList(), request)
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest?) {
                if (request != null) viewModel.onPermissionRequestCanceled(request)
            }

            // Location is not supported in this version: always deny, never remember.
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, false, false)
            }

            // Pop-up control: only user-initiated windows become a new tab, all others are blocked.
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport
                if (!isUserGesture || transport == null) {
                    viewModel.showMessage(R.string.popup_blocked)
                    return false
                }
                val newTabId = viewModel.newTab("about:blank")
                val newView = create(newTabId)
                views[newTabId] = newView
                transport.webView = newView
                resultMsg.sendToTarget()
                return true
            }

            // Page console output is never logged (it may contain personal data).
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean = true
        }
    }

    companion object {
        /** Main-frame errors after which the plain-HTTP fallback is tried (not DNS errors: http would not help). */
        private val HTTP_FALLBACK_ERRORS = setOf(
            WebViewClient.ERROR_FAILED_SSL_HANDSHAKE, WebViewClient.ERROR_CONNECT,
            WebViewClient.ERROR_TIMEOUT, WebViewClient.ERROR_IO, WebViewClient.ERROR_UNKNOWN
        )

        /** Converts accept types of a file input (MIME types or ".ext") to MIME types for the system picker. */
        fun mimeTypesFor(acceptTypes: List<String>): Array<String> {
            val mimes = acceptTypes.flatMap { it.split(',') }.map { it.trim().lowercase() }.mapNotNull { entry ->
                when {
                    entry.isEmpty() -> null
                    entry.contains('/') -> entry
                    entry.startsWith('.') ->
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension(entry.removePrefix("."))
                    else -> null
                }
            }.distinct()
            return if (mimes.isEmpty()) arrayOf("*/*") else mimes.toTypedArray()
        }
    }
}
