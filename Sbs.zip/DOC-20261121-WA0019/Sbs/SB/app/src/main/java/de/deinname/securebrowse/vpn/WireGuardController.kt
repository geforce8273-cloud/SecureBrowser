package de.deinname.securebrowse.vpn

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader

/** Thin controller around the official WireGuard Android tunnel backend. */
class WireGuardController(context: Context) {
    private val backend = GoBackend(context.applicationContext)
    private val tunnel = object : Tunnel {
        override fun getName(): String = TUNNEL_NAME
        override fun onStateChange(newState: Tunnel.State) = Unit
    }

    fun parseConfig(raw: String): Config = Config.parse(BufferedReader(StringReader(raw)))

    fun connect(raw: String) {
        val config = parseConfig(raw)
        backend.setState(tunnel, Tunnel.State.UP, config)
    }

    fun disconnect() {
        backend.setState(tunnel, Tunnel.State.DOWN, null)
    }

    fun isConnected(): Boolean = runCatching { backend.getState(tunnel) == Tunnel.State.UP }.getOrDefault(false)

    fun backendVersion(): String = runCatching { backend.version }.getOrDefault("WireGuard")

    companion object { private const val TUNNEL_NAME = "SecureBrowse" }
}
