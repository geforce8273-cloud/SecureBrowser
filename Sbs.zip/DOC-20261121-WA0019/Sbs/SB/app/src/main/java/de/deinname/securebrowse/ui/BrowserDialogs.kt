package de.deinname.securebrowse.ui

import android.content.ActivityNotFoundException
import android.text.format.Formatter
import de.deinname.securebrowse.browser.Downloads
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import android.net.http.SslError
import android.webkit.PermissionRequest
import androidx.core.content.ContextCompat
import de.deinname.securebrowse.R
import de.deinname.securebrowse.browser.BrowserUiState
import de.deinname.securebrowse.browser.BrowserViewModel
import de.deinname.securebrowse.browser.PendingDialog
import de.deinname.securebrowse.browser.WebViewRegistry

/**
 * Website permissions follow the rule "ask in the app first, Android runtime permission second, default deny":
 * the Android permission dialog is only launched after the user pressed "Allow" in our own dialog.
 */
@Composable
fun BrowserDialogs(state: BrowserUiState, viewModel: BrowserViewModel) {
    val context = LocalContext.current
    var pendingAndroidPermission by remember { mutableStateOf<PendingDialog.Permission?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val dialog = pendingAndroidPermission
        pendingAndroidPermission = null
        if (dialog != null) {
            if (result.isNotEmpty() && result.values.all { it }) {
                viewModel.grantPermission(dialog)
            } else {
                viewModel.denyPermission(dialog)
                viewModel.showMessage(R.string.permission_android_denied)
            }
        }
    }

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        viewModel.completeFileChooser(uris)
    }

    // Storage Access Framework picker for <input type="file">. No storage permission is needed.
    val chooser = state.fileChooser
    LaunchedEffect(chooser) {
        if (chooser != null) fileLauncher.launch(WebViewRegistry.mimeTypesFor(chooser.acceptTypes))
    }

    when (val dialog = state.dialog) {
        null -> Unit

        is PendingDialog.ExternalScheme -> AlertDialog(
            onDismissRequest = { viewModel.dismissDialog() },
            title = { Text(stringResource(R.string.external_title)) },
            text = { Text(stringResource(R.string.external_message, dialog.url.take(200))) },
            confirmButton = {
                TextButton(onClick = {
                    try {
                        context.startActivity(dialog.intent)
                    } catch (_: ActivityNotFoundException) {
                        viewModel.showMessage(R.string.no_app_found)
                    } catch (_: SecurityException) {
                        viewModel.showMessage(R.string.blocked_scheme)
                    }
                    viewModel.clearDialog(dialog)
                }) { Text(stringResource(R.string.open)) }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissDialog() }) { Text(stringResource(R.string.cancel)) }
            }
        )

        is PendingDialog.Download -> {
            val name = Downloads.fileName(dialog)
            val host = android.net.Uri.parse(dialog.url).host.orEmpty()
            val size = if (dialog.contentLength > 0) "\nGröße: " + Formatter.formatFileSize(context, dialog.contentLength) else ""
            AlertDialog(
                onDismissRequest = { viewModel.dismissDialog() },
                title = { Text("Datei herunterladen?") },
                text = { Text("$name\nVon: $host$size\n\nLade nur Dateien aus Quellen, denen du vertraust.") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.clearDialog(dialog)
                        viewModel.showMessage(
                            if (Downloads.enqueue(context, dialog)) R.string.download_started else R.string.download_failed
                        )
                    }) { Text("Herunterladen") }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissDialog() }) { Text(stringResource(R.string.cancel)) }
                }
            )
        }

        is PendingDialog.Permission -> {
            val cameraLabel = stringResource(R.string.permission_camera)
            val microphoneLabel = stringResource(R.string.permission_microphone)
            val labels = dialog.resources.joinToString(", ") {
                if (it == PermissionRequest.RESOURCE_VIDEO_CAPTURE) cameraLabel else microphoneLabel
            }
            AlertDialog(
                onDismissRequest = { viewModel.denyPermission(dialog) },
                title = { Text(stringResource(R.string.permission_title)) },
                text = { Text(stringResource(R.string.permission_message, dialog.origin, labels)) },
                confirmButton = {
                    TextButton(onClick = {
                        val missing = BrowserViewModel.androidPermissionsFor(dialog.resources).filter {
                            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
                        }
                        if (missing.isEmpty()) {
                            viewModel.grantPermission(dialog)
                        } else {
                            pendingAndroidPermission = dialog
                            permissionLauncher.launch(missing.toTypedArray())
                        }
                    }) { Text(stringResource(R.string.allow)) }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.denyPermission(dialog) }) { Text(stringResource(R.string.deny)) }
                }
            )
        }

        is PendingDialog.SslWarning -> {
            val reason = stringResource(
                when (dialog.primaryError) {
                    SslError.SSL_UNTRUSTED -> R.string.ssl_reason_untrusted
                    SslError.SSL_EXPIRED -> R.string.ssl_reason_expired
                    SslError.SSL_IDMISMATCH -> R.string.ssl_reason_mismatch
                    SslError.SSL_NOTYETVALID -> R.string.ssl_reason_not_yet_valid
                    else -> R.string.ssl_reason_other
                }
            )
            AlertDialog(
                onDismissRequest = { viewModel.dismissDialog() },
                title = { Text(stringResource(R.string.ssl_title)) },
                text = { Text(stringResource(R.string.ssl_message, dialog.url.take(200), reason)) },
                confirmButton = {
                    TextButton(onClick = {
                        dialog.handler.proceed()
                        viewModel.clearDialog(dialog)
                    }) { Text(stringResource(R.string.ssl_proceed)) }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissDialog() }) { Text(stringResource(R.string.cancel)) }
                }
            )
        }

        is PendingDialog.HttpAuth -> {
            var user by remember(dialog) { mutableStateOf("") }
            var password by remember(dialog) { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { viewModel.dismissDialog() },
                title = { Text(stringResource(R.string.auth_title)) },
                text = {
                    Column {
                        Text(stringResource(R.string.auth_message, dialog.host, dialog.realm))
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = user, onValueChange = { user = it }, singleLine = true,
                            label = { Text(stringResource(R.string.auth_user)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = password, onValueChange = { password = it }, singleLine = true,
                            label = { Text(stringResource(R.string.auth_password)) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        dialog.handler.proceed(user, password)
                        viewModel.clearDialog(dialog)
                    }) { Text(stringResource(R.string.sign_in)) }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissDialog() }) { Text(stringResource(R.string.cancel)) }
                }
            )
        }
    }
}
