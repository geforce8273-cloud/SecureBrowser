package de.deinname.securebrowse.ui

import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.deinname.securebrowse.vpn.EncryptedVpnProfileStore
import de.deinname.securebrowse.vpn.WireGuardController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun VpnScreen(
    controller: WireGuardController,
    store: EncryptedVpnProfileStore,
    onBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val profiles = remember { mutableStateListOf<EncryptedVpnProfileStore.Profile>() }
    var selectedName by remember { mutableStateOf("") }
    var connected by remember { mutableStateOf(controller.isConnected()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Importiere eine WireGuard-Konfigurationsdatei (.conf), um zu beginnen.") }
    var showDelete by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf("Mein VPN") }

    fun reloadProfiles() {
        profiles.clear()
        profiles.addAll(store.all())
        if (profiles.none { it.name == selectedName }) selectedName = profiles.firstOrNull()?.name.orEmpty()
    }

    LaunchedEffect(Unit) { reloadProfiles() }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                message = "Konfiguration wird geprüft …"
                val raw = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
                }
                if (raw.isNullOrBlank()) {
                    message = "Datei konnte nicht gelesen werden."
                } else {
                    val validation = runCatching { controller.parseConfig(raw) }
                    if (validation.isSuccess) {
                        val name = profileName.trim().ifBlank { "WireGuard-Profil" }.take(40)
                        runCatching { store.save(name, raw) }
                            .onSuccess {
                                reloadProfiles()
                                selectedName = name
                                message = "Profil sicher importiert. Der private Schlüssel wird verschlüsselt gespeichert."
                            }
                            .onFailure { message = "Speichern fehlgeschlagen: ${it.message ?: "Unbekannter Fehler"}" }
                    } else {
                        message = "Die Datei ist keine gültige WireGuard-Konfiguration: ${validation.exceptionOrNull()?.message ?: "Prüfung fehlgeschlagen"}"
                    }
                }
                busy = false
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == android.app.Activity.RESULT_OK) {
            val profile = profiles.firstOrNull { p -> p.name == selectedName }
            if (profile == null) message = "Bitte zuerst ein Profil importieren."
            else scope.launch {
                busy = true
                runCatching { withContext(Dispatchers.IO) { controller.connect(profile.config) } }
                    .onSuccess { connected = true; message = "WireGuard ist verbunden." }
                    .onFailure { connected = false; message = "Verbindung fehlgeschlagen: ${it.message ?: "Unbekannter Fehler"}" }
                busy = false
            }
        } else message = "VPN-Berechtigung wurde nicht erteilt."
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("SecureBrowse VPN", style = MaterialTheme.typography.headlineSmall)
                TextButton(onClick = onBack) { Text("Zurück") }
            }
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (connected) "Verbunden" else "Nicht verbunden", style = MaterialTheme.typography.titleLarge,
                        color = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    Text(if (connected) "Der WireGuard-Tunnel ist aktiv." else "Dein Internetverkehr wird derzeit nicht durch SecureBrowse VPN geleitet.")
                    if (connected) {
                        Button(onClick = {
                            scope.launch {
                                busy = true
                                runCatching { withContext(Dispatchers.IO) { controller.disconnect() } }
                                    .onSuccess { connected = false; message = "VPN getrennt." }
                                    .onFailure { message = "Trennen fehlgeschlagen: ${it.message}" }
                                busy = false
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("VPN ausschalten") }
                    } else {
                        Button(onClick = {
                            val profile = profiles.firstOrNull { it.name == selectedName }
                            if (profile == null) message = "Bitte zuerst eine Konfiguration importieren."
                            else {
                                val intent = VpnService.prepare(context)
                                if (intent == null) {
                                    scope.launch {
                                        busy = true
                                        runCatching { withContext(Dispatchers.IO) { controller.connect(profile.config) } }
                                            .onSuccess { connected = true; message = "WireGuard ist verbunden." }
                                            .onFailure { message = "Verbindung fehlgeschlagen: ${it.message ?: "Unbekannter Fehler"}" }
                                        busy = false
                                    }
                                } else permissionLauncher.launch(intent)
                            }
                        }, enabled = !busy && profiles.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("VPN verbinden") }
                    }
                }
            }

            Text("WireGuard-Profile", style = MaterialTheme.typography.titleMedium)
            if (profiles.isEmpty()) Text("Noch kein Profil vorhanden.")
            profiles.forEach { profile ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    RadioButton(selected = selectedName == profile.name, onClick = { selectedName = profile.name }, enabled = !connected)
                    Text(profile.name, modifier = Modifier.weight(1f))
                    if (selectedName == profile.name) TextButton(onClick = { showDelete = true }, enabled = !connected) { Text("Löschen") }
                }
            }
            OutlinedTextField(value = profileName, onValueChange = { profileName = it }, label = { Text("Profilname für Import") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, enabled = !busy && !connected, modifier = Modifier.fillMaxWidth()) {
                Text("WireGuard-Konfiguration importieren (.conf)")
            }
            Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Text("Sicherheitshinweise", style = MaterialTheme.typography.titleMedium)
            Text("• Profile werden lokal mit AES-GCM verschlüsselt; der Schlüssel liegt im Android Keystore.")
            Text("• SecureBrowse stellt keinen VPN-Server bereit. Du brauchst eine gültige WireGuard-Konfiguration von einem VPN-Anbieter oder deinem eigenen Server.")
            Text("• Android zeigt beim ersten Verbinden eine Systemabfrage für die VPN-Berechtigung.")
            Text("• Für einen systemweiten Kill Switch aktiviere in Android unter Einstellungen → Netzwerk & Internet → VPN → SecureBrowse die Optionen „Immer aktives VPN“ und „Verbindungen ohne VPN blockieren“, sofern dein Gerät sie anbietet.")
            Text("• Ohne aktive Verbindung besteht kein VPN-Schutz. Ein VPN ersetzt weder HTTPS noch sichere Browsing-Gewohnheiten.", style = MaterialTheme.typography.bodySmall)
        }
    }

    if (showDelete) AlertDialog(
        onDismissRequest = { showDelete = false },
        title = { Text("Profil löschen?") },
        text = { Text("Das gespeicherte WireGuard-Profil wird von diesem Gerät entfernt.") },
        confirmButton = { TextButton(onClick = { store.delete(selectedName); showDelete = false; reloadProfiles(); message = "Profil gelöscht." }) { Text("Löschen") } },
        dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Abbrechen") } }
    )
}
