package de.deinname.securebrowse

import android.app.Application
import de.deinname.securebrowse.data.BrowserStore
import de.deinname.securebrowse.vpn.EncryptedVpnProfileStore
import de.deinname.securebrowse.vpn.WireGuardController

/** Manual dependency injection: one container, created lazily, owned by the Application. */
class AppContainer(application: Application) {
    val browserStore: BrowserStore = BrowserStore(application)
    // Keep one backend instance for the whole process so a tunnel remains controllable
    // when the user navigates away from and back to the VPN screen.
    val vpnProfileStore: EncryptedVpnProfileStore = EncryptedVpnProfileStore(application)
    val wireGuardController: WireGuardController = WireGuardController(application)
}

class SecureBrowseApp : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}
