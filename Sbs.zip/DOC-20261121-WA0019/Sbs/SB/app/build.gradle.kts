plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "de.deinname.securebrowse"
    compileSdk {
        version = release(37) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "de.deinname.securebrowse" // placeholder, change before publishing
        minSdk = 26
        targetSdk = 36 // PRUEFEN: raise once API 37 is the official stable target
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures { compose = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.runtime)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.icons.extended)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)
    // Official WireGuard Android tunnel backend (userspace; no root required).
    implementation("com.wireguard.android:tunnel:1.0.20260102")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")

    testImplementation(libs.junit)
}

// ---------------------------------------------------------------------------
// Dependency guard: fails the build if a forbidden group appears in the graph.
// Run: ./gradlew :app:verifyNoForbiddenDependencies
// ---------------------------------------------------------------------------
val forbiddenGroupPrefixes = listOf(
    "com.google.android.gms",
    "com.google.firebase",
    "com.google.android.datatransport",
    "com.google.android.play",
    "com.android.billingclient",
    "io.sentry",
    "com.crashlytics",
    "com.google.android.ads",
    "com.google.mlkit"
)

tasks.register("verifyNoForbiddenDependencies") {
    group = "verification"
    description = "Fails if any forbidden (Google Play Services, Firebase, tracking, ...) module is resolved."
    notCompatibleWithConfigurationCache("Inspects the resolved dependency graph at execution time.")
    doLast {
        val violations = sortedSetOf<String>()
        listOf("debugRuntimeClasspath", "releaseRuntimeClasspath").forEach { name ->
            configurations.getByName(name).incoming.resolutionResult.allComponents.forEach { component ->
                val id = component.id
                if (id is org.gradle.api.artifacts.component.ModuleComponentIdentifier &&
                    forbiddenGroupPrefixes.any { id.group == it || id.group.startsWith("$it.") }
                ) {
                    violations += "$name -> ${id.group}:${id.module}:${id.version}"
                }
            }
        }
        if (violations.isNotEmpty()) {
            throw GradleException("Forbidden dependencies found:\n" + violations.joinToString("\n"))
        }
        println("OK: no forbidden dependency groups in debug/release runtime classpath.")
    }
}
