# Phase 1: no custom keep rules required (no reflection, no JavaScript bridge).
