# APK ohne Android Studio bauen (GitHub Actions)

1. Auf https://github.com ein kostenloses Konto anlegen, "New repository" (privat ist ok).
2. Den kompletten Inhalt dieses Ordners hochladen (Add file -> Upload files). Wichtig: der versteckte Ordner `.github` muss mit.
3. Reiter "Actions" -> "Build APK" -> laeuft automatisch (oder "Run workflow").
4. Nach ca. 5-10 Minuten: auf den fertigen Lauf klicken -> unten "Artifacts" -> `SecureBrowse-debug-apk` herunterladen, entpacken, `app-debug.apk` aufs Handy und installieren ("Unbekannte Quellen" erlauben).

Die Server von GitHub haben Internet, Java, Android SDK und Gradle. Der Build wurde noch nie ausgefuehrt: bei Fehlern das Log aus "Actions" kopieren und mir schicken.

Ordner `web/`: die Webversion (securebrowse-lokal.html im Handy-Browser oeffnen).
