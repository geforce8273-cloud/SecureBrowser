package de.deinname.securebrowse.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import de.deinname.securebrowse.browser.BrowserViewModel
import de.deinname.securebrowse.browser.WebViewRegistry

object Routes {
    const val BROWSER = "browser"
    const val TABS = "tabs"
    const val BOOKMARKS = "bookmarks"
    const val HISTORY = "history"
}

@Composable
fun AppNavigation(viewModel: BrowserViewModel, registry: WebViewRegistry) {
    val nav = rememberNavController()

    fun openUrlInCurrentTab(url: String) {
        val tab = viewModel.state.value.selectedTab ?: return
        registry.load(tab.id, url)
        nav.popBackStack(Routes.BROWSER, inclusive = false)
    }

    NavHost(navController = nav, startDestination = Routes.BROWSER) {
        composable(Routes.BROWSER) {
            BrowserScreen(
                viewModel = viewModel,
                registry = registry,
                onOpenTabs = { nav.navigate(Routes.TABS) },
                onOpenBookmarks = { nav.navigate(Routes.BOOKMARKS) },
                onOpenHistory = { nav.navigate(Routes.HISTORY) }
            )
        }
        composable(Routes.TABS) {
            TabsScreen(viewModel, registry, onBack = { nav.popBackStack() })
        }
        composable(Routes.BOOKMARKS) {
            BookmarksScreen(viewModel, onBack = { nav.popBackStack() }, onOpen = ::openUrlInCurrentTab)
        }
        composable(Routes.HISTORY) {
            HistoryScreen(viewModel, onBack = { nav.popBackStack() }, onOpen = ::openUrlInCurrentTab)
        }
    }
}
