package de.deinname.securebrowse

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import de.deinname.securebrowse.browser.BrowserViewModel
import de.deinname.securebrowse.browser.WebViewRegistry
import de.deinname.securebrowse.ui.AppNavigation
import de.deinname.securebrowse.ui.theme.SecureBrowseTheme

class MainActivity : ComponentActivity() {

    private val viewModel: BrowserViewModel by viewModels {
        BrowserViewModel.Factory((application as SecureBrowseApp).container.browserStore)
    }
    private lateinit var registry: WebViewRegistry

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        registry = WebViewRegistry(this, viewModel)
        if (savedInstanceState == null) handleIntent(intent)
        addOnNewIntentListener { handleIntent(it) }
        setContent {
            SecureBrowseTheme {
                val container = (application as SecureBrowseApp).container
                AppNavigation(viewModel, registry, container.wireGuardController, container.vpnProfileStore)
            }
        }
    }

    override fun onDestroy() {
        registry.destroyAll() // WebViews hold the Activity context
        super.onDestroy()
    }

    /** Incoming intents are untrusted input: only VIEW (links) and SEND (shared text) are read, then validated. */
    private fun handleIntent(intent: Intent?) {
        val raw = runCatching {
            when (intent?.action) {
                Intent.ACTION_VIEW -> intent.dataString
                Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
                else -> null
            }
        }.getOrNull()
        if (!raw.isNullOrBlank()) viewModel.openExternalRequest(raw)
    }
}
