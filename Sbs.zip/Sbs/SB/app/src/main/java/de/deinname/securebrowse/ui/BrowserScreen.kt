package de.deinname.securebrowse.ui

import android.content.Intent
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.deinname.securebrowse.R
import de.deinname.securebrowse.browser.BrowserViewModel
import de.deinname.securebrowse.browser.TabUi
import de.deinname.securebrowse.browser.UrlTools
import de.deinname.securebrowse.browser.WebViewRegistry
import de.deinname.securebrowse.data.SearchEngines

@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    registry: WebViewRegistry,
    onOpenTabs: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenHistory: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var menuOpen by remember { mutableStateOf(false) }
    var searchDialog by remember { mutableStateOf(false) }

    val tab = state.selectedTab

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(context.getString(it))
            viewModel.messageShown()
        }
    }

    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { tab?.let { registry.peek(it.id)?.onPause() } }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tab?.let { registry.peek(it.id)?.onResume() } }

    // Back: leave fullscreen first, then navigate within the page. Otherwise the system handles it.
    BackHandler(enabled = state.customView != null) { registry.exitFullscreen() }
    BackHandler(enabled = state.customView == null && tab?.canGoBack == true) {
        tab?.let { registry.peek(it.id)?.goBack() }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            contentWindowInsets = WindowInsets.safeDrawing
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (!state.loaded || tab == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    AddressBar(
                        tab = tab,
                        tabCount = state.tabs.size,
                        onSubmit = { input ->
                            val resolved = viewModel.resolveInputWithFallback(input)
                            if (resolved == null) viewModel.showMessage(R.string.invalid_address)
                            else registry.load(tab.id, resolved.url, resolved.httpFallback)
                        },
                        onOpenTabs = onOpenTabs
                    )
                    if (tab.isLoading) {
                        LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    } else {
                        Spacer(Modifier.height(4.dp))
                    }
                    if (tab.sslError) {
                        Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                stringResource(R.string.cert_error_banner),
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (tab.url.isBlank()) {
                            StartPage()
                        } else {
                            key(tab.id, tab.generation) {
                                AndroidView(
                                    modifier = Modifier.fillMaxSize(),
                                    factory = {
                                        registry.getOrCreate(tab.id, tab.url).also { view ->
                                            (view.parent as? ViewGroup)?.removeView(view)
                                        }
                                    },
                                    onRelease = { view -> (view.parent as? ViewGroup)?.removeView(view) }
                                )
                            }
                        }
                    }
                    BottomBar(
                        tab = tab,
                        bookmarked = bookmarks.any { it.url == tab.url },
                        onBack = { registry.peek(tab.id)?.goBack() },
                        onForward = { registry.peek(tab.id)?.goForward() },
                        onReloadOrStop = {
                            registry.peek(tab.id)?.let { if (tab.isLoading) it.stopLoading() else it.reload() }
                        },
                        onToggleBookmark = viewModel::toggleBookmark,
                        menu = {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Filled.MoreVert, stringResource(R.string.menu))
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.new_tab)) },
                                    leadingIcon = { Icon(Icons.Filled.Add, null) },
                                    onClick = { menuOpen = false; viewModel.newTab() }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.bookmarks)) },
                                    onClick = { menuOpen = false; onOpenBookmarks() }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.history)) },
                                    onClick = { menuOpen = false; onOpenHistory() }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.share_link)) },
                                    enabled = UrlTools.isWebUrl(tab.url),
                                    onClick = { menuOpen = false; shareLink(context, tab.url) }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.search_engine)) },
                                    onClick = { menuOpen = false; searchDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.clear_history)) },
                                    onClick = { menuOpen = false; viewModel.clearHistory() }
                                )
                            }
                        }
                    )
                }
            }
        }

        state.customView?.let { FullscreenOverlay(it, onExit = registry::exitFullscreen) }
    }

    if (searchDialog) {
        AlertDialog(
            onDismissRequest = { searchDialog = false },
            title = { Text(stringResource(R.string.search_engine)) },
            text = {
                Column {
                    SearchEngines.all.forEach { engine ->
                        Row(
                            Modifier.fillMaxWidth().height(48.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = engine.id == state.searchEngine.id,
                                onClick = { viewModel.setSearchEngine(engine.id); searchDialog = false }
                            )
                            Text(engine.name)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { searchDialog = false }) { Text(stringResource(R.string.close)) } }
        )
    }

    BrowserDialogs(state = state, viewModel = viewModel)
}

@Composable
private fun AddressBar(tab: TabUi, tabCount: Int, onSubmit: (String) -> Unit, onOpenTabs: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.weight(1f)
        ) {
            Row(Modifier.padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                SecurityIcon(tab)
                OutlinedTextField(
                    value = if (focused) text else tab.url,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f).onFocusChanged {
                        if (it.isFocused && !focused) text = tab.url
                        focused = it.isFocused
                    },
                    placeholder = { Text(stringResource(R.string.address_hint)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        focusManager.clearFocus()
                        onSubmit(text)
                    }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    textStyle = MaterialTheme.typography.bodyMedium
                )
            }
        }
        IconButton(onClick = onOpenTabs) {
            BadgedBox(badge = { Badge { Text(tabCount.toString()) } }) {
                Icon(Icons.Filled.Tab, stringResource(R.string.tabs))
            }
        }
    }
}

@Composable
private fun SecurityIcon(tab: TabUi) {
    when {
        tab.sslError -> Icon(
            Icons.Filled.Warning, stringResource(R.string.status_cert_error),
            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp)
        )
        UrlTools.isHttps(tab.url) -> Icon(
            Icons.Filled.Lock, stringResource(R.string.status_https),
            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)
        )
        UrlTools.isHttp(tab.url) -> Icon(
            Icons.Filled.Warning, stringResource(R.string.status_http),
            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp)
        )
        else -> Icon(
            Icons.Filled.Search, stringResource(R.string.status_empty),
            tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun BottomBar(
    tab: TabUi,
    bookmarked: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReloadOrStop: () -> Unit,
    onToggleBookmark: () -> Unit,
    menu: @Composable () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, enabled = tab.canGoBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
            }
            IconButton(onClick = onForward, enabled = tab.canGoForward) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, stringResource(R.string.forward))
            }
            IconButton(onClick = onReloadOrStop, enabled = tab.url.isNotBlank()) {
                if (tab.isLoading) Icon(Icons.Filled.Close, stringResource(R.string.stop))
                else Icon(Icons.Filled.Refresh, stringResource(R.string.reload))
            }
            IconButton(onClick = onToggleBookmark, enabled = UrlTools.isWebUrl(tab.url)) {
                Icon(
                    if (bookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    stringResource(if (bookmarked) R.string.bookmark_remove else R.string.bookmark_add)
                )
            }
            Box { menu() }
        }
    }
}

@Composable
private fun StartPage() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(R.string.start_title), style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(R.string.start_subtitle),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun FullscreenOverlay(view: android.view.View, onExit: () -> Unit) {
    BackHandler(onBack = onExit)
    val activity = LocalActivity.current
    DisposableEffect(activity) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    AndroidView(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        factory = { view.also { (it.parent as? ViewGroup)?.removeView(it) } }
    )
}

private fun shareLink(context: android.content.Context, url: String) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url)
    context.startActivity(Intent.createChooser(send, context.getString(R.string.share_chooser)))
}
