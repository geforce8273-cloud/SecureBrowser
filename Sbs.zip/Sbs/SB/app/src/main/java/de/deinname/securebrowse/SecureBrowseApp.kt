package de.deinname.securebrowse

import android.app.Application
import de.deinname.securebrowse.data.BrowserStore

/** Manual dependency injection: one container, created lazily, owned by the Application. */
class AppContainer(application: Application) {
    val browserStore: BrowserStore = BrowserStore(application)
}

class SecureBrowseApp : Application() {
    val container: AppContainer by lazy { AppContainer(this) }
}
