package de.deinname.securebrowse
import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.firebase.auth.*
import java.util.Locale

val ACC = listOf("Blau" to 0xFF00B4FF, "Pink" to 0xFFFF4FA3, "Grün" to 0xFF2ECC71, "Lila" to 0xFF9B59B6, "Orange" to 0xFFFF9800)
val BG = listOf("Nacht" to (0xFF050A14 to 0xFF0B2545), "Sonnenuntergang" to (0xFF1B1030 to 0xFF5A1E4A), "Wald" to (0xFF06130D to 0xFF0F4D33), "Schwarz" to (0xFF000000 to 0xFF111111))

class MainActivity : ComponentActivity() {
 override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { App(this) } }
}

@Composable fun App(a: ComponentActivity) {
 val p = remember { Prefs(a).also { Guard.av = it.b("av", true); Guard.wd = it.b("wd", true) } }
 val au = runCatching { FirebaseAuth.getInstance() }.getOrNull()
 var scr by remember { mutableStateOf(if (au?.currentUser != null || p.b("guest")) "browser" else "login") }
 var ai by remember { mutableIntStateOf(p.s("acc", "0").toInt()) }
 var bi by remember { mutableIntStateOf(p.s("bg", "0").toInt()) }
 val acc = Color(ACC[ai].second)
 MaterialTheme(darkColorScheme(primary = acc)) {
  Surface(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(BG[bi].second.first), Color(BG[bi].second.second)))), color = Color.Transparent, contentColor = Color.White) {
   Column(Modifier.statusBarsPadding()) {
    Box(Modifier.weight(1f)) {
     when (scr) {
      "login" -> Login(a, p) { scr = "browser" }
      "browser" -> Browser(p)
      "jarvis" -> Jarvis(p, a, acc)
      "settings" -> Settings(p, a, ai, bi, { ai = it; p.put("acc", "$it") }, { bi = it; p.put("bg", "$it") }, { scr = "login" }, { scr = "admin" }, { scr = "browser" })
      "admin" -> Admin(p) { scr = "settings" }
     }
    }
    if (scr != "login") Row(Modifier.fillMaxWidth().navigationBarsPadding(), Arrangement.SpaceEvenly) {
     TextButton({ scr = "browser" }) { Text("Browser") }
     TextButton({ scr = "jarvis" }) { Text("Jarvis") }
     TextButton({ scr = "settings" }) { Text("Einstellungen") }
    }
   }
  }
 }
}

@Composable fun Login(a: ComponentActivity, p: Prefs, done: () -> Unit) {
 var em by remember { mutableStateOf("") }; var pw by remember { mutableStateOf("") }; var err by remember { mutableStateOf("") }
 val au = runCatching { FirebaseAuth.getInstance() }.getOrNull()
 fun res(t: com.google.android.gms.tasks.Task<AuthResult>) { t.addOnSuccessListener { done() }.addOnFailureListener { err = it.message ?: "Fehler" } }
 fun oauth(id: String) { au?.let { res(it.startActivityForSignInWithProvider(a, OAuthProvider.newBuilder(id).build())) } ?: run { err = "Firebase nicht eingerichtet" } }
 Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
  Text("SecureBrowse × JARVIS", style = MaterialTheme.typography.headlineMedium)
  OutlinedTextField(em, { em = it }, label = { Text("E-Mail") }, singleLine = true, modifier = Modifier.fillMaxWidth())
  OutlinedTextField(pw, { pw = it }, label = { Text("Passwort") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
   Button({ au?.let { res(it.signInWithEmailAndPassword(em, pw)) } ?: run { err = "Firebase nicht eingerichtet" } }) { Text("Anmelden") }
   OutlinedButton({ au?.let { res(it.createUserWithEmailAndPassword(em, pw)) } ?: run { err = "Firebase nicht eingerichtet" } }) { Text("Registrieren") }
  }
  Button({ oauth("google.com") }, Modifier.fillMaxWidth()) { Text("Mit Google anmelden") }
  Button({ oauth("apple.com") }, Modifier.fillMaxWidth()) { Text("Mit Apple-ID anmelden") }
  TextButton({ p.putB("guest", true); done() }) { Text("Als Gast fortfahren") }
  if (err.isNotEmpty()) Text(err, color = Color(0xFFFF6B6B))
 }
}

@Composable fun Browser(p: Prefs) {
 var url by remember { mutableStateOf("https://duckduckgo.com") }
 var wv by remember { mutableStateOf<WebView?>(null) }; var msg by remember { mutableStateOf("") }
 fun go() {
  var u = url.trim()
  if (!u.contains(".") || u.contains(" ")) u = "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(u, "UTF-8") else if (!u.startsWith("http")) u = "https://$u"
  if (Guard.url(u)) msg = "Blockiert: unsicher oder verbotener Inhalt" else { msg = ""; wv?.loadUrl(u) }
 }
 Column {
  Row(Modifier.padding(8.dp)) { OutlinedTextField(url, { url = it }, Modifier.weight(1f), singleLine = true); Button({ go() }, Modifier.padding(start = 6.dp)) { Text("Los") } }
  if (msg.isNotEmpty()) Text(msg, Modifier.padding(horizontal = 8.dp), color = Color(0xFFFF6B6B))
  AndroidView({ c ->
   WebView(c).apply {
    settings.javaScriptEnabled = true
    val inc = p.b("inc")
    if (inc) settings.cacheMode = WebSettings.LOAD_NO_CACHE
    CookieManager.getInstance().setAcceptCookie(!inc)
    webViewClient = object : WebViewClient() {
     override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
      if (Guard.url(r.url.toString())) { msg = "Blockiert: unsicher oder verbotener Inhalt"; return true }; return false
     }
    }
    setDownloadListener { u, _, _, _, _ -> msg = if (Guard.download(u)) "Download blockiert (Virenschutz)" else "Downloads sind aus Sicherheitsgründen deaktiviert" }
    loadUrl(url); wv = this
   }
  }, Modifier.fillMaxSize())
 }
}

@Composable fun Orb(c: Color, talking: Boolean) {
 val t = rememberInfiniteTransition(label = "o")
 val r by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "r")
 val s by t.animateFloat(0.9f, 1.1f, infiniteRepeatable(tween(if (talking) 350 else 1800), RepeatMode.Reverse), label = "s")
 Canvas(Modifier.size(220.dp)) {
  val m = center; val R = size.minDimension / 2
  drawCircle(Brush.radialGradient(listOf(c.copy(.9f), c.copy(.15f), Color.Transparent), m, R * .6f * s), R * .6f * s, m)
  for (i in 1..3) rotate(r * (if (i % 2 == 0) -1 else 1) * i / 2f, m) {
   drawCircle(c, R * (.65f + i * .1f), m, style = Stroke(3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(40f * i, 25f))))
  }
 }
}

@Composable fun Cam() {
 val lo = LocalLifecycleOwner.current
 AndroidView({ ctx ->
  PreviewView(ctx).also { pv ->
   val f = ProcessCameraProvider.getInstance(ctx)
   f.addListener({
    val pr = f.get(); val pw = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
    pr.unbindAll(); pr.bindToLifecycle(lo, CameraSelector.DEFAULT_FRONT_CAMERA, pw)
   }, ContextCompat.getMainExecutor(ctx))
  }
 }, Modifier.size(130.dp).clip(CircleShape))
}

@Composable fun Jarvis(p: Prefs, a: ComponentActivity, acc: Color) {
 var log by remember { mutableStateOf("JARVIS online. Wie kann ich helfen?") }
 var inp by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; var cam by remember { mutableStateOf(false) }
 val tts = remember { TextToSpeech(a) {} }
 DisposableEffect(Unit) { onDispose { tts.shutdown() } }
 fun say(x: String) { tts.language = Locale.GERMAN; tts.setPitch(if (p.s("g", "f") == "f") 1.25f else .7f); tts.setSpeechRate(p.s("rate", "1").toFloat()); tts.speak(x, TextToSpeech.QUEUE_FLUSH, null, "j") }
 fun ask(q: String) {
  busy = true
  Thread { val r = try { Ai.ask(p.s("key"), p.s("model", "claude-sonnet-5-5"), q) } catch (e: Exception) { "Netzwerkfehler" }; a.runOnUiThread { log = r; busy = false; say(r) } }.start()
 }
 val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r -> r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { inp = it; ask(it) } }
 val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { cam = it[Manifest.permission.CAMERA] == true }
 Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
  Box(contentAlignment = androidx.compose.ui.Alignment.Center) { Orb(acc, busy); if (cam) Cam() }
  Text(if (busy) "…denke nach" else log, Modifier.weight(1f).verticalScroll(rememberScrollState()))
  OutlinedTextField(inp, { inp = it }, Modifier.fillMaxWidth(), label = { Text("Frag JARVIS") })
  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
   Button({ if (inp.isNotBlank()) ask(inp) }) { Text("Senden") }
   Button({ perm.launch(arrayOf(Manifest.permission.RECORD_AUDIO)); mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")) }) { Text("Sprechen") }
   OutlinedButton({ if (cam) cam = false else perm.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) }) { Text(if (cam) "Kamera aus" else "Kamera an") }
  }
 }
}

@Composable fun Sw(t: String, v: Boolean, f: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, androidx.compose.ui.Alignment.CenterVertically) { Text(t); Switch(v, f) } }

@Composable fun Settings(p: Prefs, a: ComponentActivity, ai: Int, bi: Int, setA: (Int) -> Unit, setB: (Int) -> Unit, logout: () -> Unit, admin: () -> Unit, back: () -> Unit) {
 var inc by remember { mutableStateOf(p.b("inc")) }; var av by remember { mutableStateOf(p.b("av", true)) }; var wd by remember { mutableStateOf(p.b("wd", true)) }
 var g by remember { mutableStateOf(p.s("g", "f")) }; var rate by remember { mutableFloatStateOf(p.s("rate", "1").toFloat()) }
 var taps by remember { mutableIntStateOf(0) }; var swVis by remember { mutableStateOf(p.b("adminSw")) }; var adm by remember { mutableStateOf(p.b("adminOn")) }
 var dlg by remember { mutableStateOf(false) }; var pw by remember { mutableStateOf("") }; var nm by remember { mutableStateOf("") }
 fun toast(t: String) = Toast.makeText(a, t, Toast.LENGTH_SHORT).show()
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
  Text("Einstellungen", style = MaterialTheme.typography.headlineSmall)
  Text("Konto: " + (runCatching { FirebaseAuth.getInstance().currentUser?.email }.getOrNull() ?: "Gast"))
  OutlinedButton({ runCatching { FirebaseAuth.getInstance().signOut() }; p.putB("guest", false); logout() }) { Text("Abmelden") }
  Text("Farbe", style = MaterialTheme.typography.titleMedium)
  Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { ACC.forEachIndexed { i, c -> FilterChip(ai == i, { setA(i) }, { Text(c.first) }) } }
  Text("Hintergrund", style = MaterialTheme.typography.titleMedium)
  Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { BG.forEachIndexed { i, c -> FilterChip(bi == i, { setB(i) }, { Text(c.first) }) } }
  Text("Jarvis-Stimme", style = MaterialTheme.typography.titleMedium)
  Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { FilterChip(g == "f", { g = "f"; p.put("g", "f") }, { Text("Weiblich") }); FilterChip(g == "m", { g = "m"; p.put("g", "m") }, { Text("Männlich") }) }
  Text("Sprechtempo"); Slider(rate, { rate = it; p.put("rate", "$it") }, valueRange = .5f..1.5f)
  Text("Browser", style = MaterialTheme.typography.titleMedium)
  Sw("Inkognito (neu laden nötig)", inc) { inc = it; p.putB("inc", it) }
  Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
   OutlinedButton({ WebView(a).clearCache(true); a.cacheDir.deleteRecursively(); toast("Cache gelöscht") }) { Text("Cache") }
   OutlinedButton({ CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData(); toast("Cookies gelöscht") }) { Text("Cookies") }
   OutlinedButton({ a.filesDir.listFiles()?.forEach { it.deleteRecursively() }; toast("Dateien gelöscht") }) { Text("Dateien") }
  }
  Text("Schutz", style = MaterialTheme.typography.titleMedium)
  Sw("Virenschutz (Downloads/HTTP blockieren)", av) { av = it; Guard.av = it; p.putB("av", it) }
  Sw("Schutz vor illegalen Waffen & Drogen", wd) { wd = it; Guard.wd = it; p.putB("wd", it) }
  Text("Info zur App", style = MaterialTheme.typography.titleMedium)
  Text("SecureBrowse × JARVIS · Version 2.0.0 (tippe 10×)", Modifier.clickable { taps++; if (taps >= 10 && !swVis) { swVis = true; p.putB("adminSw", true); toast("Neuer Schalter freigeschaltet") } })
  if (swVis) Sw("Entwickleroptionen", adm) { adm = it; p.putB("adminOn", it) }
  Button({ if (adm) dlg = true else back() }) { Text("Zurück") }
 }
 if (dlg) AlertDialog({ dlg = false }, confirmButton = { TextButton({ dlg = false; if (nm.trim() == "Admin.net" && sha(pw) == ADMIN_HASH) admin() else { toast("Name oder Passwort falsch"); back() }; pw = ""; nm = "" }) { Text("OK") } },
  title = { Text("Entwickleroptionen") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(nm, { nm = it }, label = { Text("Name") }, singleLine = true); OutlinedTextField(pw, { pw = it }, label = { Text("Passwort") }, singleLine = true, visualTransformation = PasswordVisualTransformation()) } })
}

@Composable fun Admin(p: Prefs, back: () -> Unit) {
 var k by remember { mutableStateOf(p.s("key")) }; var m by remember { mutableStateOf(p.s("model", "claude-sonnet-5-5")) }
 Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
  Text("Entwickleroptionen (Admin)", style = MaterialTheme.typography.headlineSmall)
  OutlinedTextField(k, { k = it }, label = { Text("API-Schlüssel (KI)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
  OutlinedTextField(m, { m = it }, label = { Text("Modell") }, modifier = Modifier.fillMaxWidth())
  Button({ p.put("key", k); p.put("model", m); back() }) { Text("Speichern") }
 }
}
