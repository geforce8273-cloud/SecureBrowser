package de.deinname.securebrowse
import android.content.Context
import org.json.*
import java.net.*
import java.security.MessageDigest

class Prefs(c: Context) {
 private val p = c.getSharedPreferences("sb", 0)
 fun s(k: String, d: String = "") = p.getString(k, d) ?: d
 fun put(k: String, v: String) { p.edit().putString(k, v).apply() }
 fun b(k: String, d: Boolean = false) = p.getBoolean(k, d)
 fun putB(k: String, v: Boolean) { p.edit().putBoolean(k, v).apply() }
}
fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
const val ADMIN_HASH = "a19514b9e55c02bacab1327225e1eb0339dd8ee0f5f6917356980db8ef95ccee"

object Guard {
 var av = true; var wd = true
 private val bad = listOf("illegale waffe", "waffe bauen", "bombe bauen", "ghost gun", "pistole kaufen", "kokain kaufen", "heroin kaufen", "meth herstellen", "drogen kaufen", "darknet markt", "illegal gun", "build a bomb", "buy cocaine", "buy heroin", "make meth")
 private val ext = listOf(".apk", ".exe", ".scr", ".bat", ".msi", ".jar", ".vbs")
 fun text(t: String) = wd && bad.any { t.lowercase().contains(it) }
 fun download(u: String) = av && ext.any { u.substringBefore("?").lowercase().endsWith(it) }
 fun url(u: String) = (av && !u.startsWith("https://")) || text(URLDecoder.decode(u, "UTF-8").replace("+", " "))
}

object Ai {
 fun ask(key: String, model: String, q: String): String {
  if (Guard.text(q)) return "Das kann ich nicht beantworten (Schutz vor illegalen Waffen/Drogen)."
  if (key.isBlank()) return "Kein API-Schlüssel hinterlegt (Admin-Bereich)."
  val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
  c.requestMethod = "POST"; c.doOutput = true
  c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01"); c.setRequestProperty("content-type", "application/json")
  val body = JSONObject().put("model", model).put("max_tokens", 600)
   .put("system", "Du bist JARVIS, ein höflicher, präziser Assistent. Antworte kurz auf Deutsch. Hilf nie bei illegalen Waffen, Drogen oder Malware.")
   .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
  c.outputStream.use { it.write(body.toString().toByteArray()) }
  val r = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
  val out = runCatching { JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text") }.getOrElse { "Fehler: $r" }
  return if (Guard.text(out)) "Antwort blockiert (Sicherheitsfilter)." else out
 }
}
