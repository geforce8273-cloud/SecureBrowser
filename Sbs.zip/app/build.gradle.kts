plugins{id("com.android.application");id("org.jetbrains.kotlin.android");id("org.jetbrains.kotlin.plugin.compose")}
android{namespace="de.deinname.securebrowse";compileSdk=34
 defaultConfig{applicationId="de.deinname.securebrowse";minSdk=26;targetSdk=34;versionCode=2;versionName="2.0.0"}
 buildFeatures{compose=true}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}}
dependencies{
 implementation(platform("androidx.compose:compose-bom:2024.09.00"))
 implementation("androidx.compose.material3:material3");implementation("androidx.compose.ui:ui")
 implementation("androidx.activity:activity-compose:1.9.2")
 implementation("androidx.camera:camera-camera2:1.3.4");implementation("androidx.camera:camera-lifecycle:1.3.4");implementation("androidx.camera:camera-view:1.3.4")
 implementation(platform("com.google.firebase:firebase-bom:33.3.0"));implementation("com.google.firebase:firebase-auth")}

if (file("google-services.json").exists()) apply(plugin = "com.google.gms.google-services")
