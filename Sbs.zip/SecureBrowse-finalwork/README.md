# SecureBrowse – Phase 1 (Browser-Grundlage), Version 2

Early development foundation with a WireGuard VPN integration. **Not built or run in the authoring environment**; verify the first build and device behavior before relying on it. A VPN is only active after importing a valid profile and successfully connecting.

## Build (Android Studio, recommended)

1. Install Android Studio (current stable) and, via SDK Manager, **Android SDK Platform 37** + Build-Tools.
2. *File → Open* → select the folder containing `settings.gradle.kts`.
3. Android Studio reads `gradle/wrapper/gradle-wrapper.properties` and downloads **Gradle 9.6.0** (required by AGP 9.5.0).
4. *Build → Make Project*, then *Run* on a device.

## Command line (CachyOS)

The wrapper JAR/scripts are intentionally **not** shipped (the previous ZIP contained hand-made ones). Generate the real wrapper once with `tools/bootstrap-gradle-wrapper.sh` (verifies the Gradle checksum), or manually:

```bash
sudo pacman -S gradle jdk17-openjdk       # any JDK >= 17
gradle wrapper --gradle-version 9.6.0
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest          # UrlTools unit tests (never executed yet)
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Checks required after the first successful sync

```bash
./gradlew :app:verifyNoForbiddenDependencies                                # fails on Play Services/Firebase/Sentry/...
./gradlew :app:dependencies --configuration releaseRuntimeClasspath > deps.txt
grep -Ei "gms|firebase|datatransport|crashlytics|sentry|billing|admob|mlkit" deps.txt   # must print nothing
./gradlew :app:processDebugMainManifest
# merged manifest: app/build/intermediates/merged_manifests/debug/ (exact path: PRUEFEN)
grep -E "uses-permission|exported|<receiver|<provider|<service" <merged AndroidManifest.xml>
```

Expected in the merged manifest: INTERNET, CAMERA, RECORD_AUDIO, `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION` (androidx),
plus androidx.startup `InitializationProvider` and androidx.profileinstaller `ProfileInstallReceiver` (both come with Compose,
neither is a tracker). Anything else, especially `QUERY_ALL_PACKAGES`, `READ/WRITE_EXTERNAL_STORAGE`, `WAKE_LOCK`, must be investigated.

## What Phase 1 contains

- Compose + Material 3, light/dark, own palette (dynamic color implemented, off by default), adaptive icon incl. monochrome
- MVVM with StateFlow, manual DI, Navigation Compose (browser, tab grid, bookmarks, history)
- **One WebView per tab** (own back/forward history, title, progress), tabs persisted (URLs only) in DataStore
- URL/search detection (HTTPS first for bare hosts; also `name:port` servers without a dot; if the https attempt fails with a connection/handshake error, http:// is tried once automatically and the HTTP warning is shown), DuckDuckGo default, 3 search engines selectable
- HTTPS lock / HTTP warning / certificate-error banner (certificate errors show a warning dialog: cancel, or "continue anyway" for that one error, never remembered)
- Bookmarks, local history (500 max), share link, default-browser registration, receive shared text
- WebView hardening: no JS bridge, file+content access off, mixed content blocked, third-party cookies off, Safe Browsing and
  metrics reporting disabled via manifest, only http/https load directly, `javascript:`/`file:`/`content:`/`data:` blocked,
  `mailto:`/`tel:`/`sms:`/`intent:` only after user gesture + confirmation (intent URIs sanitized: no component, no selector, no flags)
- File upload via Storage Access Framework (no storage permission), fullscreen video, HTTP auth dialog (credentials never saved)
- Website camera/microphone: own dialog first, Android permission only after "Allow", default deny; location always denied
- Pop-ups: only user-initiated windows open (as new tab), everything else is blocked
- Renderer crash handled (tab reloads instead of app crash)
- WireGuard userspace tunnel integration using the official Android tunnel library
- Import and validation of WireGuard `.conf` profiles; multiple named profiles
- VPN connection/disconnection controls and visible connection state
- Profiles encrypted locally with AES-GCM; encryption key stored in Android Keystore

## Known limits

Downloads (a hint is shown), find in page, print, QR-based VPN profile import, incognito (FLAG_SECURE), desktop mode, cookie/cache clearing UI,
full settings screen, tab thumbnails, ad blocker, media player. Tab scroll/form state is lost on process death (URLs are restored).

## VPN notes

- SecureBrowse does not provide VPN servers or free VPN access. The user must import a valid WireGuard configuration supplied by a VPN provider or their own server.
- Android's VPN consent dialog is required. System Always-on VPN and lockdown must be enabled by the user in Android settings; the app cannot silently enable them.
- The connection UI is not proof of internet reachability or anonymity. Test DNS, IPv4/IPv6 routing, reconnect behavior, and network changes on physical devices before release.
- The WireGuard tunnel dependency is `com.wireguard.android:tunnel:1.0.20260102` from Maven Central. See the official embedding guidance: https://github.com/WireGuard/wireguard-android#embedding.

## Decisions you should know about

1. **Cleartext policy.** Requirement 7 says any HTTP address must open, rule 12 forbids `usesCleartextTraffic="true"`.
   WebView obeys the network security config, so `network_security_config.xml` permits cleartext (attribute not used) and HTTP is warned about
   in the UI. All future own HTTP clients must be HTTPS-only. PRUEFEN: `http://neverssl.com` loads on device.
2. **No Room/KSP.** Master prompt prescribes DataStore; removing Room also removes the KSP/Kotlin version coupling.
3. **`androidx.webkit` omitted** until a feature really needs it (Phase 4), per "no unnecessary libraries".
4. `targetSdk 36`, `compileSdk 37`: PRUEFEN whether 37 should be the target by the time you publish.
5. Application ID `de.deinname.securebrowse` is a placeholder. Name check (brand collisions) is still open – do it before Phase 5.

## JARVIS – Phase 1 foundation

The Android app now contains a separate `jarvis` package, a persistent enable/disable setting, a SQLite memory database schema, an inference-engine contract, and an explicit unconfigured engine. The JARVIS entry is visible in the browser bottom navigation. This phase does **not** include a loaded language model, voice, vision, or web-research implementation; the UI reports inference as unavailable until a real runtime is integrated.


## JARVIS – Phase 3

Native llama.cpp runtime (NDK/JNI), streaming, cancel and memory protection: see `JARVIS_PHASE3.md`. Not yet built or run; read the "Ehrlicher Stand" section first.
