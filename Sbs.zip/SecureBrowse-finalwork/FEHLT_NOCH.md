# FEHLT NOCH – SecureBrowse / JARVIS

Stand: 21.11.2026. Diese Liste ist eine ehrliche Checkliste. Nicht angekreuzte Punkte sind nicht als erledigt nachgewiesen.

## Umgebung / Build
- [ ] Netzwerkzugriff zu Gradle, Google Maven, Maven Central und GitHub verfügbar
- [ ] JDK 17+ installiert (hier zuvor JDK 21 erkannt)
- [ ] Android SDK installiert, Plattform/Build Tools passend zum Projekt
- [ ] Android NDK und CMake installiert
- [ ] Gradle Wrapper erzeugt: `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`
- [ ] Wrapper-Distribution SHA-256 gesetzt und überprüft
- [ ] `./gradlew :app:testDebugUnitTest :app:assembleDebug --stacktrace` erfolgreich
- [ ] Dependency-Guard: `./gradlew :app:verifyNoForbiddenDependencies` erfolgreich
- [ ] Alle als PRUEFEN markierten Versionsangaben anhand offizieller Quellen verifiziert

## llama.cpp / Native
- [ ] llama.cpp stabilen Tag/Commit anhand offizieller Release-/Git-Daten verifizieren und pinnen
- [ ] `tools/add-llama-cpp.sh <tag>` erfolgreich ausgeführt
- [ ] JNI-Datei gegen echte gepinnte `llama.h` geprüft und ggf. angepasst
- [ ] CMake-Optionen und Gradle-Argumente gegen gepinnte llama.cpp-Version validiert
- [ ] NDK-Build nur arm64-v8a; `-march=armv8.2-a+dotprod` (kein armv8.7a)
- [ ] ggml Debug-Build weiterhin mit `-O3`
- [ ] Native Kompilierung erfolgreich
- [ ] UTF-8 byte[]-Übertragung bleibt erhalten; Modelltext nicht via `NewStringUTF`
- [ ] JNI-Aufrufe auf einem Thread; Cancel lock-frei
- [ ] Native Tests gegen echte native Bibliothek ausgeführt/erweitert

## APK / Packaging
- [ ] `libjarvis_llama.so` im APK nachgewiesen
- [ ] APK ELF-/Native-Library 16-KB-Alignment geprüft
- [ ] Debug APK installiert und startet
- [ ] Release-Build mit R8/Minify getestet
- [ ] ProGuard-Regeln für LlamaBridge und TokenCallback geprüft

## JARVIS / Gerätetest (ADB)
- [ ] Gerät arm64-v8a erreichbar; ADB-Ausgabe dokumentiert
- [ ] GGUF Modell (ca. 1B Q4) importiert
- [ ] Modell laden, Prompt senden und echte Modellantwort bestätigen
- [ ] Stopp während Generierung testen
- [ ] Entladen testen
- [ ] Zu großes Modell durch MemoryGuard ablehnen
- [ ] Freier RAM / 60%-RAM-Limit / KV-Budget geprüft
- [ ] Low-memory-Prüfung während Antwort getestet
- [ ] `onTrimMemory` / `onLowMemory` Verhalten geprüft
- [ ] Zeit- und Tokenlimit geprüft
- [ ] Hintergrundverhalten / Prozessbeendigung dokumentiert

## CI
- [ ] GitHub Actions Workflow tatsächlich ausgeführt
- [ ] Build- und Unit-Test-Logs gesichert
- [ ] APK-Artifact aus CI heruntergeladen und geprüft

## Bekannte Grenzen
- Ohne Foreground-Service kann Android die App im Hintergrund beenden; Antwort kann beim Verlassen des JARVIS-Screens stoppen.
- KV-Cache-Schätzung basiert auf f16/Standard-Transformer und kann bei SWA/Hybrid/Mamba abweichen.
- Der gesamte Verlauf wird pro Antwort neu ausgewertet; lange Chats können langsam werden.
- Chat-Speicherung, Spracheingabe/-ausgabe, Vision und Web-Recherche sind nicht implementiert/nicht bestätigt.
- Galaxy A53: niedrige Token-Raten erwartet, noch nicht gemessen.
- Native Bibliothek nur arm64-v8a; x86-Emulator meldet fehlende native Bibliothek.

## Bisher belegte Ergebnisse
- Host UTF-8-Test: zuvor als bestanden dokumentiert; nicht als Android-/JNI-Test interpretieren.
- Shell-Syntax und YAML-Syntax: zuvor als geprüft dokumentiert.
- Wrapper und llama.cpp Bootstrap scheiterten in der vorigen Umgebung an DNS/Netzwerkzugriff.
- Kein APK-/Geräte-/Release-/CI-Nachweis vorhanden.
