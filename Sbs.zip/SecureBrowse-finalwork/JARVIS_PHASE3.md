# JARVIS – Phase 3: Build reparieren, llama.cpp (NDK/JNI), Speicherschutz

## Ehrlicher Stand
Nichts davon wurde in der Entstehungsumgebung gebaut oder auf einem Gerät ausgeführt (kein Netz, kein Gradle, kein NDK, kein llama.cpp-Quellcode vorhanden).
Tatsächlich getestet wurde nur: der UTF-8-Helfer (`app/src/main/cpp/tests`, g++ auf dem Host, grün), die Shell-Skripte (`bash -n`), die Workflow-YAML (Syntax) und die JNI-Datei per `-fsyntax-only` gegen **selbstgeschriebene Mock-Header**. Der Kotlin-Code und die Gradle-Änderungen wurden nur gelesen, nicht kompiliert.
**Der erste echte Build kann Kompilierfehler zeigen, vor allem in `jarvis_jni.cpp`, falls sich die llama.cpp-C-API seit meinem Wissensstand geändert hat.** Die Fehlermeldung nennt dann die Zeile; meist ist es ein umbenannter Funktionsname.

## 1. Gradle-Wrapper
`gradle-wrapper.jar` kann ohne Netz nicht erzeugt werden und wurde bewusst nicht von Hand nachgebaut.
```bash
tools/bootstrap-gradle-wrapper.sh     # lädt Gradle 9.6.0, prüft die SHA-256, erzeugt gradlew + gradlew.bat + jar
git add gradlew gradlew.bat gradle/wrapper && git commit -m "Gradle wrapper"
```
Das Skript trägt zusätzlich `distributionSha256Sum` in die Properties ein. `.github/workflows/build-apk.yml` bricht mit klarer Meldung ab, wenn das JAR fehlt.
Alternative wie bisher in der README: `gradle wrapper --gradle-version 9.6.0`.

Unverändert und **nicht verifiziert**: die Versionen in `libs.versions.toml` (AGP 9.5.0, Kotlin 2.4.10, Gradle 9.6.0, `compileSdk release(37){minorApiLevel=1}`) sind im Projekt selbst als „PRUEFEN“ markiert. Schlägt der Sync fehl, zuerst dort suchen.

## 2. llama.cpp einbinden
```bash
tools/add-llama-cpp.sh <tag-oder-commit>   # fester Stand, Tags: https://github.com/ggml-org/llama.cpp/tags
```
- Ohne diesen Schritt baut die App weiterhin (Gradle konfiguriert CMake nur, wenn `app/src/main/cpp/llama.cpp/CMakeLists.txt` existiert). JARVIS zeigt dann „native Bibliothek fehlt“.
- Nur `arm64-v8a` wird nativ gebaut, übersetzt mit `armv8.2-a+dotprod` (Galaxy A53 geeignet). **Nicht** `armv8.7a` verwenden: das stürzt auf der A53 mit SIGILL ab. Beim Laden prüft `nativeCpuSupported()` die dotprod-Fähigkeit und lehnt ältere CPUs sauber ab.
- Debug-Builds werden in `CMakeLists.txt` auf -O3 gezwungen; ein unoptimiertes ggml wäre unbenutzbar langsam.
- `-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON` und `max-page-size=16384` für 16-KB-Seitengröße (Android 15+).
- Der CI-Workflow checkt Submodule mit aus.

## 3. Modell ausführen (Architektur)
- `jarvis_jni.cpp`: ein Modell/Kontext, Chat-Template des Modells (Fallback ChatML), Prefill in `n_batch`-Blöcken, Sampling top-k 40 / top-p 0.9 / temp 0.7, Token-Streaming.
- Text läuft als UTF-8-`byte[]` über JNI (nie `NewStringUTF`); unvollständige Zeichen am Token-Ende (Umlaute, €, Emoji) werden zurückgehalten (`utf8_stream.h`).
- `LlamaInferenceEngine.kt`: alle nativen Aufrufe auf **einem** Thread, `stream()` liefert `JarvisEvent.Token/Done`, `generate()` sammelt zu einem String.
- Jede Antwort wertet die Unterhaltung neu aus (einfach und korrekt, bei langen Chats langsamer). Zu lange Verläufe werden vorn gekürzt, die Systemnachricht bleibt.
- Release-Build: `proguard-rules.pro` hält `LlamaBridge` und `TokenCallback`, sonst findet JNI die Methoden nicht.

## 4. Speicherschutz und Abbruch
| Maßnahme | Wo |
|---|---|
| Modell > 60 % des Gesamt-RAM wird abgelehnt | `MemoryGuard` |
| Abgelehnt, wenn freier RAM (minus Low-Memory-Schwelle) < Modell + 256 MB + 64 MB | `MemoryGuard` |
| KV-Cache-Budget = Rest, höchstens 768 MB; Kontext wird halbiert (4096 → min. 512), bis die f16-Schätzung passt | `MemoryGuard` + `nativeLoad` |
| `mmap` an, `mlock` aus: der Kernel darf Seiten jederzeit zurückholen | `nativeLoad` |
| Stopp-Button / Verlassen des Screens / Abbruch des Collectors → lock-freies Cancel-Flag, wirkt auch während der Prompt-Verarbeitung (Abort-Callback) | `nativeCancel`, `engine.cancel()` |
| Zeitlimit 180 s, max. 512 neue Tokens (einstellbar, max. 2048) | `GenerationOptions` |
| Alle 16 Tokens Low-Memory-Prüfung → Antwort stoppt mit „Arbeitsspeicher wird knapp“ | `stream()` |
| `onTrimMemory ≥ 40` bzw. `onLowMemory` → Abbruch und Modell entladen | `LlamaInferenceEngine` |
| Modell wird vor Import/Entfernen entladen | `JarvisScreen` |

Grenzen: Die KV-Schätzung nimmt f16 und ein Standard-Transformer-Layout an (SWA-/Hybrid-/Mamba-Modelle weichen ab). Ohne Foreground-Service kann Android den Prozess im Hintergrund trotzdem beenden. Eine Antwort läuft nicht weiter, wenn man den Screen verlässt.

## 5. Erster Test auf dem Gerät (Empfehlung)
1. Wrapper erzeugen, ohne llama.cpp bauen → App startet, JARVIS meldet „Bibliothek fehlt“.
2. `add-llama-cpp.sh` mit festem Tag, erneut bauen (erster nativer Build dauert mehrere Minuten).
3. Kleines Modell (ca. 1 B, Q4_K_M) importieren, laden, kurzen Satz senden, Stopp testen.
4. Erst danach größere Modelle; auf der A53 ist die Geschwindigkeit begrenzt (zweistellige Tokens/s sind nicht zu erwarten).
