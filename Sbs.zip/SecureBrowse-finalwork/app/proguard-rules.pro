# JNI: native code (jarvis_jni.cpp) finds these by name. R8 must not rename or remove them.
-keep class de.deinname.securebrowse.jarvis.LlamaBridge { *; }
-keep interface de.deinname.securebrowse.jarvis.TokenCallback { *; }
