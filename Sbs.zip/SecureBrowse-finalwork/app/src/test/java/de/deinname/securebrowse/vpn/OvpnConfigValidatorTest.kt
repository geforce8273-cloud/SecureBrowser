package de.deinname.securebrowse.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OvpnConfigValidatorTest {
    private val ok = "client\ndev tun\nproto udp\nremote vpn.example.org 1194\n<ca>\n-----BEGIN CERTIFICATE-----\nup evil.sh\n-----END CERTIFICATE-----\n</ca>\n"

    @Test fun acceptsValidInlineConfig() = assertTrue(OvpnConfigValidator.validate(ok).isSuccess)

    @Test fun ignoresTextInsideInlineBlocks() = assertTrue(OvpnConfigValidator.validate(ok).isSuccess)

    @Test fun rejectsScriptDirectives() {
        assertTrue(OvpnConfigValidator.validate("$ok\nup /system/bin/sh").isFailure)
        assertTrue(OvpnConfigValidator.validate("$ok\nscript-security 2").isFailure)
        assertTrue(OvpnConfigValidator.validate("$ok\nplugin foo.so").isFailure)
    }

    @Test fun rejectsExternalFiles() {
        assertTrue(OvpnConfigValidator.validate("client\nremote a 1194\nca ca.crt").isFailure)
        assertTrue(OvpnConfigValidator.validate("client\nremote a 1194\nauth-user-pass login.txt").isFailure)
    }

    @Test fun requiresRemote() = assertTrue(OvpnConfigValidator.validate("client\ndev tun").isFailure)

    @Test fun detectsType() {
        assertEquals(VpnType.OPENVPN, VpnType.detect(ok, "x.ovpn"))
        assertEquals(VpnType.WIREGUARD, VpnType.detect("[Interface]\n[Peer]\n", "wg.conf"))
        assertEquals(VpnType.OPENVPN, VpnType.detect(ok, null))
    }
}
