package de.deinname.securebrowse.vpn

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores WireGuard and OpenVPN profiles encrypted with an AES-256 key held by Android Keystore. */
class EncryptedVpnProfileStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vpn_profiles", Context.MODE_PRIVATE)

    data class Profile(val name: String, val config: String, val type: String = VpnType.WIREGUARD)

    @Synchronized fun all(): List<Profile> = runCatching {
        val raw = prefs.getString(KEY_DATA, null) ?: return emptyList()
        val plain = decrypt(Base64.decode(raw, Base64.NO_WRAP))
        val array = JSONArray(plain)
        (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            Profile(item.getString("name"), item.getString("config"), item.optString("type", VpnType.WIREGUARD))
        }
    }.getOrDefault(emptyList())

    @Synchronized fun save(name: String, config: String, type: String = VpnType.WIREGUARD) {
        val profiles = all().filterNot { it.name == name }.toMutableList()
        profiles.add(Profile(name, config, type))
        val json = JSONArray().apply {
            profiles.forEach { put(JSONObject().put("name", it.name).put("config", it.config).put("type", it.type)) }
        }.toString()
        prefs.edit().putString(KEY_DATA, Base64.encodeToString(encrypt(json), Base64.NO_WRAP)).apply()
    }

    @Synchronized fun delete(name: String) {
        val json = JSONArray().apply {
            all().filterNot { it.name == name }.forEach {
                put(JSONObject().put("name", it.name).put("config", it.config).put("type", it.type))
            }
        }.toString()
        if (json == "[]") prefs.edit().remove(KEY_DATA).apply()
        else prefs.edit().putString(KEY_DATA, Base64.encodeToString(encrypt(json), Base64.NO_WRAP)).apply()
    }

    private fun encrypt(value: String): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return cipher.iv + encrypted
    }

    private fun decrypt(value: ByteArray): String {
        require(value.size > IV_LENGTH) { "Ungültiges VPN-Profil" }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, value.copyOfRange(0, IV_LENGTH)))
        return cipher.doFinal(value.copyOfRange(IV_LENGTH, value.size)).toString(Charsets.UTF_8)
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val KEY_ALIAS = "securebrowse_wireguard_profiles_v1"
        const val KEY_DATA = "encrypted_profiles"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_LENGTH = 12
    }
}
