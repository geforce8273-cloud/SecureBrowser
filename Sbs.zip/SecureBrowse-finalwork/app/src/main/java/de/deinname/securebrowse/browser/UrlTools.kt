package de.deinname.securebrowse.browser

import java.net.URLEncoder
import java.net.URI

/** Pure Kotlin so it can be unit-tested on the JVM. Never throws. */
object UrlTools {

    enum class SchemeAction { LOAD, EXTERNAL, BLOCK }

    private val webPrefix = Regex("^https?://", RegexOption.IGNORE_CASE)

    /** Server name with an explicit port and no dot, e.g. "nas:8080" or "myserver:3000" (2-5 digit port). */
    private val hostWithPort = Regex("^[A-Za-z0-9][A-Za-z0-9_-]*:\\d{2,5}$")

    /** Anything starting with these is never searched for and never loaded from the address bar. */
    private val rejectedPrefixes = listOf(
        "javascript:", "vbscript:", "file:", "content:", "data:", "blob:", "about:",
        "view-source:", "intent:", "mailto:", "tel:", "sms:", "ftp:", "market:"
    )

    /**
     * Turns address-bar input into a URL to load.
     * - http(s) URLs with a host are returned unchanged
     * - dangerous / unsupported schemes return null
     * - bare hosts get https:// (HTTPS first)
     * - everything else becomes a search URL
     */
    fun resolve(input: String, searchTemplate: String): String? = resolveWithFallback(input, searchTemplate)?.url

    /** [url] is what is loaded first. [httpFallback] is only set for bare hosts: tried once if the https attempt fails. */
    data class Resolved(val url: String, val httpFallback: String? = null)

    fun resolveWithFallback(input: String, searchTemplate: String): Resolved? {
        val value = input.filterNot { it.isISOControl() }.trim()
        if (value.isEmpty()) return null
        if (webPrefix.containsMatchIn(value)) return value.takeIf { hasHost(it) }?.let { Resolved(it) }
        val lower = value.lowercase()
        if (rejectedPrefixes.any { lower.startsWith(it) }) return null
        if (looksLikeHost(value)) {
            val https = "https://$value"
            return if (hasHost(https)) Resolved(https, "http://$value") else null
        }
        return Resolved(searchUrl(value, searchTemplate))
    }

    fun searchUrl(query: String, template: String): String =
        template.replace("%s", URLEncoder.encode(query, "UTF-8"))

    fun schemeAction(scheme: String?): SchemeAction = when (scheme?.lowercase()) {
        "http", "https" -> SchemeAction.LOAD
        "mailto", "tel", "sms", "intent" -> SchemeAction.EXTERNAL
        else -> SchemeAction.BLOCK // javascript, file, content, data, blob, unknown custom schemes
    }

    fun isHttps(url: String): Boolean = url.startsWith("https://", ignoreCase = true)

    fun isHttp(url: String): Boolean = url.startsWith("http://", ignoreCase = true)

    fun isWebUrl(url: String): Boolean = isHttps(url) || isHttp(url)

    private fun looksLikeHost(value: String): Boolean {
        if (value.any { it.isWhitespace() }) return false
        if (value.startsWith(".") || value.startsWith("?") || value.startsWith("/")) return false
        val hostPart = value.substringBefore('/').substringBefore('?').substringBefore('#')
        if (hostPart.contains('.') || hostPart.startsWith("localhost", ignoreCase = true) || hostPart.startsWith("[")) {
            return true
        }
        val port = hostPart.substringAfter(':', "").toIntOrNull()
        return hostWithPort.matches(hostPart) && port != null && port in 1..65535
    }

    private fun hasHost(url: String): Boolean {
        // Parse instead of manually splitting the authority: malformed ports, spaces,
        // and bracketed IPv6 edge cases must not be accepted as navigable URLs.
        return try {
            val parsed = URI(url)
            val scheme = parsed.scheme?.lowercase()
            val host = parsed.host
            val port = parsed.port
            scheme in setOf("http", "https") &&
                !host.isNullOrBlank() && host.none { it.isWhitespace() } &&
                (port == -1 || port in 1..65535) &&
                parsed.rawAuthority?.isNotBlank() == true
        } catch (_: Exception) {
            false
        }
    }
}
