package de.deinname.securebrowse.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import de.deinname.securebrowse.browser.BrowserViewModel
import de.deinname.securebrowse.browser.WebViewRegistry
import de.deinname.securebrowse.vpn.EncryptedVpnProfileStore
import de.deinname.securebrowse.vpn.OpenVpnController
import de.deinname.securebrowse.vpn.WireGuardController

object Routes {
    const val BROWSER = "browser"
    const val TABS = "tabs"
    const val BOOKMARKS = "bookmarks"
    const val HISTORY = "history"
    const val VPN = "vpn"
    const val JARVIS = "jarvis"
}

@Composable
fun AppNavigation(
    viewModel: BrowserViewModel,
    registry: WebViewRegistry,
    wireGuardController: WireGuardController,
    openVpnController: OpenVpnController,
    vpnProfileStore: EncryptedVpnProfileStore,
    jarvisController: de.deinname.securebrowse.jarvis.JarvisController
) {
    val nav = rememberNavController()

    fun openUrlInCurrentTab(url: String) {
        val tab = viewModel.state.value.selectedTab ?: return
        registry.load(tab.id, url)
        nav.popBackStack(Routes.BROWSER, inclusive = false)
    }

    NavHost(navController = nav, startDestination = Routes.BROWSER) {
        composable(Routes.BROWSER) {
            BrowserScreen(
                viewModel = viewModel,
                registry = registry,
                onOpenTabs = { nav.navigate(Routes.TABS) },
                onOpenBookmarks = { nav.navigate(Routes.BOOKMARKS) },
                onOpenHistory = { nav.navigate(Routes.HISTORY) },
                onOpenVpn = { nav.navigate(Routes.VPN) },
                onOpenJarvis = { nav.navigate(Routes.JARVIS) },
                jarvisController = jarvisController,
                vpnConnected = { wireGuardController.isConnected() || openVpnController.isConnected() }
            )
        }
        composable(Routes.TABS) {
            TabsScreen(viewModel, registry, onBack = { nav.popBackStack() })
        }
        composable(Routes.BOOKMARKS) {
            BookmarksScreen(viewModel, onBack = { nav.popBackStack() }, onOpen = ::openUrlInCurrentTab)
        }
        composable(Routes.HISTORY) {
            HistoryScreen(viewModel, onBack = { nav.popBackStack() }, onOpen = ::openUrlInCurrentTab)
        }
        composable(Routes.JARVIS) { JarvisScreen(jarvisController, jarvisController.modelManager, onBack = { nav.popBackStack() }) }
        composable(Routes.VPN) {
            VpnScreen(
                wireGuard = wireGuardController,
                openVpn = openVpnController,
                store = vpnProfileStore,
                onBack = { nav.popBackStack() }
            )
        }
    }
}
