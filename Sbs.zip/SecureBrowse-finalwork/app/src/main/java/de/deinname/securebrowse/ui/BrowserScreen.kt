package de.deinname.securebrowse.ui

import android.content.Intent
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.vector.ImageVector
import de.deinname.securebrowse.browser.BrowserUiState
import androidx.activity.compose.LocalActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.deinname.securebrowse.R
import de.deinname.securebrowse.browser.BrowserViewModel
import de.deinname.securebrowse.browser.TabUi
import de.deinname.securebrowse.browser.UrlTools
import de.deinname.securebrowse.browser.WebViewRegistry
import de.deinname.securebrowse.data.SearchEngines
import de.deinname.securebrowse.jarvis.JarvisController

@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    registry: WebViewRegistry,
    onOpenTabs: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenVpn: () -> Unit,
    onOpenJarvis: () -> Unit,
    jarvisController: JarvisController,
    vpnConnected: () -> Boolean = { false }
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var menuOpen by remember { mutableStateOf(false) }
    var searchDialog by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var vpnOn by remember { mutableStateOf(false) }
    var jarvisEnabled by remember { mutableStateOf(jarvisController.isEnabled()) }
    LaunchedEffect(Unit) { vpnOn = vpnConnected() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        vpnOn = vpnConnected()
        jarvisEnabled = jarvisController.isEnabled()
    }

    val tab = state.selectedTab

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(context.getString(it))
            viewModel.messageShown()
        }
    }

    LaunchedEffect(state.allowMixedContent) { registry.setMixedContentAllowed(state.allowMixedContent) }

    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { tab?.let { registry.peek(it.id)?.onPause() } }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tab?.let { registry.peek(it.id)?.onResume() } }

    // Back: leave fullscreen first, then navigate within the page. Otherwise the system handles it.
    BackHandler(enabled = state.customView != null) { registry.exitFullscreen() }
    BackHandler(enabled = state.customView == null && tab?.canGoBack == true) {
        tab?.let { registry.peek(it.id)?.goBack() }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            contentWindowInsets = WindowInsets.safeDrawing
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (!state.loaded || tab == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    AddressBar(
                        tab = tab,
                        tabCount = state.tabs.size,
                        onSubmit = { input ->
                            val resolved = viewModel.resolveInputWithFallback(input)
                            if (resolved == null) viewModel.showMessage(R.string.invalid_address)
                            else registry.load(tab.id, resolved.url, resolved.httpFallback)
                        },
                        onOpenTabs = onOpenTabs,
                        vpnOn = vpnOn,
                        onOpenVpn = onOpenVpn
                    )
                    TabStrip(
                        tabs = state.tabs,
                        selectedId = tab.id,
                        onSelect = viewModel::selectTab,
                        onClose = { id -> registry.remove(id); viewModel.closeTab(id) },
                        onNew = { viewModel.newTab() }
                    )
                    if (tab.isLoading) {
                        LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    } else {
                        Spacer(Modifier.height(4.dp))
                    }
                    if (tab.sslError) {
                        Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                stringResource(R.string.cert_error_banner),
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (tab.url.isBlank()) {
                            StartPage(onOpen = { url -> registry.load(tab.id, url) })
                        } else {
                            key(tab.id, tab.generation) {
                                AndroidView(
                                    modifier = Modifier.fillMaxSize(),
                                    factory = {
                                        registry.getOrCreate(tab.id, tab.url).also { view ->
                                            (view.parent as? ViewGroup)?.removeView(view)
                                        }
                                    },
                                    onRelease = { view -> (view.parent as? ViewGroup)?.removeView(view) }
                                )
                            }
                        }
                    }
                    BottomNav(
                        vpnOn = vpnOn,
                        onStart = { if (tab.url.isNotBlank()) viewModel.newTab() },
                        onBookmarks = onOpenBookmarks,
                        onHistory = onOpenHistory,
                        onVpn = onOpenVpn,
                        onJarvis = onOpenJarvis,
                        onSettings = { settingsOpen = true }
                    )
                }
            }
        }

        state.customView?.let { FullscreenOverlay(it, onExit = registry::exitFullscreen) }
    }

    if (searchDialog) {
        AlertDialog(
            onDismissRequest = { searchDialog = false },
            title = { Text(stringResource(R.string.search_engine)) },
            text = {
                Column {
                    SearchEngines.all.forEach { engine ->
                        Row(
                            Modifier.fillMaxWidth().height(48.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = engine.id == state.searchEngine.id,
                                onClick = { viewModel.setSearchEngine(engine.id); searchDialog = false }
                            )
                            Text(engine.name)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { searchDialog = false }) { Text(stringResource(R.string.close)) } }
        )
    }

    if (settingsOpen && tab != null) {
        SettingsSheet(
            state = state,
            tab = tab,
            bookmarked = bookmarks.any { it.url == tab.url },
            onDismiss = { settingsOpen = false },
            onThemeMode = viewModel::setThemeMode,
            onReload = { settingsOpen = false; registry.peek(tab.id)?.reload() },
            onToggleBookmark = { settingsOpen = false; viewModel.toggleBookmark() },
            onShare = { settingsOpen = false; shareLink(context, tab.url) },
            onSearchEngine = { settingsOpen = false; searchDialog = true },
            onToggleMixed = {
                val allowed = !state.allowMixedContent
                registry.setMixedContentAllowed(allowed)
                viewModel.setAllowMixedContent(allowed)
                registry.peek(tab.id)?.reload()
            },
            onClearHistory = { settingsOpen = false; viewModel.clearHistory() },
            jarvisEnabled = jarvisEnabled,
            onJarvisEnabledChange = { enabled ->
                jarvisController.setEnabled(enabled)
                jarvisEnabled = enabled
            }
        )
    }

    BrowserDialogs(state = state, viewModel = viewModel)
}

@Composable
private fun AddressBar(
    tab: TabUi,
    tabCount: Int,
    onSubmit: (String) -> Unit,
    onOpenTabs: () -> Unit,
    vpnOn: Boolean,
    onOpenVpn: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = if (focused) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
            modifier = Modifier.weight(1f)
        ) {
            Row(Modifier.padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                SecurityIcon(tab)
                OutlinedTextField(
                    value = if (focused) text else tab.url,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f).onFocusChanged {
                        if (it.isFocused && !focused) text = tab.url
                        focused = it.isFocused
                    },
                    placeholder = { Text(stringResource(R.string.address_hint)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        focusManager.clearFocus()
                        onSubmit(text)
                    }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    textStyle = MaterialTheme.typography.bodyMedium
                )
            }
        }
        Surface(
            onClick = onOpenVpn,
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh
        ) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                val dot by animateColorAsState(
                    if (vpnOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    animationSpec = tween(300), label = "vpnDot"
                )
                Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
                Spacer(Modifier.width(8.dp))
                Text(if (vpnOn) "VPN an" else "VPN aus", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SecurityIcon(tab: TabUi) {
    when {
        tab.sslError -> Icon(
            Icons.Filled.Warning, stringResource(R.string.status_cert_error),
            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp)
        )
        UrlTools.isHttps(tab.url) -> Icon(
            Icons.Filled.Lock, stringResource(R.string.status_https),
            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)
        )
        UrlTools.isHttp(tab.url) -> Icon(
            Icons.Filled.Warning, stringResource(R.string.status_http),
            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp)
        )
        else -> Icon(
            Icons.Filled.Search, stringResource(R.string.status_empty),
            tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun BottomBar(
    tab: TabUi,
    bookmarked: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReloadOrStop: () -> Unit,
    onToggleBookmark: () -> Unit,
    menu: @Composable () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, enabled = tab.canGoBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
            }
            IconButton(onClick = onForward, enabled = tab.canGoForward) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, stringResource(R.string.forward))
            }
            IconButton(onClick = onReloadOrStop, enabled = tab.url.isNotBlank()) {
                if (tab.isLoading) Icon(Icons.Filled.Close, stringResource(R.string.stop))
                else Icon(Icons.Filled.Refresh, stringResource(R.string.reload))
            }
            IconButton(onClick = onToggleBookmark, enabled = UrlTools.isWebUrl(tab.url)) {
                Icon(
                    if (bookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    stringResource(if (bookmarked) R.string.bookmark_remove else R.string.bookmark_add)
                )
            }
            Box { menu() }
        }
    }
}

@Composable
private fun StartPage(onOpen: (String) -> Unit) {
    val tiles = listOf(
        Triple("DuckDuckGo", "D", "https://duckduckgo.com"),
        Triple("Wikipedia", "W", "https://de.wikipedia.org"),
        Triple("Tagesschau", "T", "https://www.tagesschau.de"),
        Triple("Neverssl", "N", "http://neverssl.com")
    )
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val headAlpha by animateFloatAsState(if (shown) 1f else 0f, tween(450), label = "headAlpha")
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 56.dp)) {
        Column(Modifier.graphicsLayer { alpha = headAlpha; translationY = (1f - headAlpha) * 48f }) {
        Text("Privat surfen,\nohne Umwege.", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text(
            "Gib oben eine Adresse oder einen Suchbegriff ein. Tracker bleiben draußen.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        }
        Spacer(Modifier.height(48.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            tiles.forEachIndexed { index, (name, letter, url) ->
                val tileAlpha by animateFloatAsState(
                    if (shown) 1f else 0f, tween(400, delayMillis = 150 + index * 90), label = "tileAlpha"
                )
                Surface(
                    onClick = { onOpen(url) },
                    shape = RoundedCornerShape(24.dp),
                    color = Color.Transparent,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    modifier = Modifier.weight(1f).graphicsLayer { alpha = tileAlpha; translationY = (1f - tileAlpha) * 36f }
                ) {
                    Column(Modifier.padding(vertical = 16.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(letter, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(name, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Clip)
                    }
                }
            }
        }
    }
}

@Composable
private fun TabStrip(
    tabs: List<TabUi>,
    selectedId: Long,
    onSelect: (Long) -> Unit,
    onClose: (Long) -> Unit,
    onNew: () -> Unit
) {
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        contentPadding = PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(tabs, key = { it.id }) { t ->
            val selected = t.id == selectedId
            val label = t.title.ifBlank {
                t.url.removePrefix("https://").removePrefix("http://").substringBefore('/')
            }.ifBlank { "Neuer Tab" }
            val chipColor by animateColorAsState(
                if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
                animationSpec = tween(250), label = "tabColor"
            )
            Surface(
                onClick = { onSelect(t.id) },
                shape = RoundedCornerShape(16.dp),
                color = chipColor,
                modifier = Modifier.animateItem()
            ) {
                Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp))
                    IconButton(onClick = { onClose(t.id) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Tab schließen", modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
        item {
            Surface(
                onClick = onNew,
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Neuer Tab", modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
            }
        }
    }
}

@Composable
private fun BottomNav(
    vpnOn: Boolean,
    onStart: () -> Unit,
    onBookmarks: () -> Unit,
    onHistory: () -> Unit,
    onVpn: () -> Unit,
    onJarvis: () -> Unit,
    onSettings: () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            NavItem(Icons.Filled.Home, "Start", false, onStart, Modifier.weight(1f))
            NavItem(Icons.Filled.Star, "Lesezeichen", false, onBookmarks, Modifier.weight(1f))
            NavItem(Icons.Filled.History, "Verlauf", false, onHistory, Modifier.weight(1f))
            NavItem(Icons.Filled.Shield, "VPN", vpnOn, onVpn, Modifier.weight(1f))
            NavItem(Icons.Filled.AutoAwesome, "JARVIS", false, onJarvis, Modifier.weight(1f))
            NavItem(Icons.Filled.Settings, "Einstellungen", false, onSettings, Modifier.weight(1f))
        }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Surface(onClick = onClick, color = Color.Transparent, modifier = modifier) {
        Column(Modifier.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val pill by animateColorAsState(
                if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                animationSpec = tween(250), label = "navPill"
            )
            Box(Modifier.clip(RoundedCornerShape(16.dp)).background(pill).padding(horizontal = 18.dp, vertical = 4.dp)) {
                Icon(
                    icon, contentDescription = label,
                    tint = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, textAlign = TextAlign.Center)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsSheet(
    state: BrowserUiState,
    tab: TabUi,
    bookmarked: Boolean,
    onDismiss: () -> Unit,
    onThemeMode: (String) -> Unit,
    onReload: () -> Unit,
    onToggleBookmark: () -> Unit,
    onShare: () -> Unit,
    onSearchEngine: () -> Unit,
    onToggleMixed: () -> Unit,
    onClearHistory: () -> Unit,
    jarvisEnabled: Boolean,
    onJarvisEnabledChange: (Boolean) -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp)) {
            Text("Einstellungen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text("Darstellung", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Auto", "light" to "Hell", "dark" to "Dunkel").forEach { (id, label) ->
                    val sel = state.themeMode == id
                    Surface(
                        onClick = { onThemeMode(id) },
                        shape = RoundedCornerShape(28.dp),
                        color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            label,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Standard-Suchmaschine: ${state.searchEngine.name}. Verlauf und Lesezeichen bleiben nur in diesem Browser gespeichert.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Spacer(Modifier.height(8.dp))
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceContainerLow) {
                Column(Modifier.fillMaxWidth()) {
                    if (tab.url.isNotBlank()) { SheetRow("Seite neu laden", onReload); HorizontalDivider() }
                    if (UrlTools.isWebUrl(tab.url)) {
                        SheetRow(if (bookmarked) "Lesezeichen entfernen" else "Lesezeichen hinzufügen", onToggleBookmark)
                        HorizontalDivider()
                        SheetRow("Link teilen", onShare)
                        HorizontalDivider()
                    }
                    SheetRow("Suchmaschine ändern", onSearchEngine)
                    HorizontalDivider()
                    SheetRow("Unsichere Inhalte auf HTTPS-Seiten erlauben", onToggleMixed) {
                        Switch(checked = state.allowMixedContent, onCheckedChange = null)
                    }
                    HorizontalDivider()
                    SheetRow("Verlauf löschen", onClearHistory)
                    HorizontalDivider()
                    SheetRow(
                        if (jarvisEnabled) "JARVIS ist aktiviert" else "JARVIS ist deaktiviert",
                        onClick = { onJarvisEnabledChange(!jarvisEnabled) }
                    ) {
                        Switch(
                            checked = jarvisEnabled,
                            onCheckedChange = onJarvisEnabledChange
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SheetRow(text: String, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Surface(onClick = onClick, color = Color.Transparent, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, modifier = Modifier.weight(1f))
            trailing()
        }
    }
}

@Composable
private fun FullscreenOverlay(view: android.view.View, onExit: () -> Unit) {
    BackHandler(onBack = onExit)
    val activity = LocalActivity.current
    DisposableEffect(activity) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    AndroidView(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        factory = { view.also { (it.parent as? ViewGroup)?.removeView(it) } }
    )
}

private fun shareLink(context: android.content.Context, url: String) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url)
    context.startActivity(Intent.createChooser(send, context.getString(R.string.share_chooser)))
}
