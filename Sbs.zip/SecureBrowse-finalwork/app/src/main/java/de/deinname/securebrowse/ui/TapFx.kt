package de.deinname.securebrowse.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import de.deinname.securebrowse.R
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Wassertropfen-Klang (wie bei GNOME/CachyOS). Wird aus res/raw/drop.wav geladen; Tonhöhe variiert leicht. */
object SoundFx {
    private var pool: SoundPool? = null
    private var soundId = 0
    private var loaded = false
    private const val PREFS = "sbs_fx"
    private const val KEY = "sound"
    private const val KEY_GLOW = "glow"

    /** Tropfen-Klang an/aus. */
    var enabled: Boolean = true
        private set

    /** Grünes Leuchten mit Sternen an/aus. */
    var glow: Boolean = true
        private set

    fun init(context: Context) {
        if (pool != null) return
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        enabled = prefs.getBoolean(KEY, true)
        glow = prefs.getBoolean(KEY_GLOW, true)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build().also { p ->
            p.setOnLoadCompleteListener { _, _, status -> loaded = status == 0 }
            soundId = p.load(app, R.raw.drop, 1)
        }
    }

    fun setEnabled(context: Context, value: Boolean) {
        enabled = value
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, value).apply()
    }

    fun setGlow(context: Context, value: Boolean) {
        glow = value
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_GLOW, value).apply()
    }

    fun play() {
        if (!enabled || !loaded) return
        val rate = 0.92f + Random.nextFloat() * 0.3f // jeder Tropfen klingt minimal anders
        pool?.play(soundId, 0.8f, 0.8f, 1, 0, rate)
    }
}

private val Glow = Color(0xFF4ADE80)
private val GlowSoft = Color(0xFFB9F6CA)

private fun sparkle(cx: Float, cy: Float, r: Float): Path = Path().apply {
    val inner = r * 0.38f
    for (i in 0 until 8) {
        val a = Math.PI / 4 * i - Math.PI / 2
        val rad = if (i % 2 == 0) r else inner
        val x = cx + (cos(a) * rad).toFloat()
        val y = cy + (sin(a) * rad).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

private fun DrawScope.drawFx(p: Float, seed: Int, corner: Dp) {
    val fade = 1f - p
    val cr = CornerRadius(corner.toPx())
    // grünes Leuchten: Füllung + weicher Rand
    drawRoundRect(Glow.copy(alpha = 0.32f * fade), size = size, cornerRadius = cr)
    drawRoundRect(Glow.copy(alpha = 0.9f * fade), size = size, cornerRadius = cr, style = Stroke(width = 2.5.dp.toPx()))
    drawRoundRect(
        Glow.copy(alpha = 0.25f * fade),
        topLeft = Offset(-4.dp.toPx(), -4.dp.toPx()),
        size = Size(size.width + 8.dp.toPx(), size.height + 8.dp.toPx()),
        cornerRadius = cr, style = Stroke(width = 6.dp.toPx())
    )
    // kleine Sterne, die oben aufsteigen und verblassen
    val rnd = Random(seed)
    val count = 6
    for (i in 0 until count) {
        val x = size.width * (0.08f + 0.84f * ((i + rnd.nextFloat() * 0.6f) / count))
        val rise = (6 + rnd.nextFloat() * 10).dp.toPx() * p + 4.dp.toPx()
        val y = rise.unaryMinus() + 2.dp.toPx()
        val local = ((p * 1.3f) - i * 0.04f).coerceIn(0f, 1f)
        val a = (1f - local) * (if (p < 0.12f) p / 0.12f else 1f)
        val r = (3.5f + rnd.nextFloat() * 3f).dp.toPx() * (0.7f + 0.5f * (1f - local))
        drawPath(sparkle(x, y, r), (if (i % 2 == 0) GlowSoft else Glow).copy(alpha = a.coerceIn(0f, 1f)))
    }
}

/**
 * Tropfen-Klang + grünes Leuchten mit kleinen Sternen beim Antippen.
 * Verbraucht keine Touch-Events (Initial-Pass), der Klick des Elements funktioniert normal weiter.
 * Scrollen/Wischen löst keinen Effekt aus.
 */
fun Modifier.tapFx(corner: Dp = 16.dp): Modifier = composed {
    val context = LocalContext.current
    SoundFx.init(context)
    val progress = remember { Animatable(1f) }
    var seed by remember { mutableIntStateOf(1) }
    val scope = rememberCoroutineScope()

    this
        .pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                var moved = false
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if ((c.position - down.position).getDistance() > viewConfiguration.touchSlop) moved = true
                    if (c.changedToUp()) {
                        if (!moved) {
                            SoundFx.play()
                            if (SoundFx.glow) {
                                seed++
                                scope.launch {
                                    progress.snapTo(0f)
                                    progress.animateTo(1f, tween(750, easing = LinearEasing))
                                }
                            }
                        }
                        break
                    }
                    if (!c.pressed) break
                }
            }
        }
        .drawWithContent {
            drawContent()
            val p = progress.value
            if (p < 1f) drawFx(p, seed, corner)
        }
}
