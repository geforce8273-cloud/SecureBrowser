package de.deinname.securebrowse.browser

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.webkit.HttpAuthHandler
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import de.deinname.securebrowse.R
import de.deinname.securebrowse.data.BrowserStore
import de.deinname.securebrowse.data.Bookmark
import de.deinname.securebrowse.data.HistoryEntry
import de.deinname.securebrowse.data.SavedTab
import de.deinname.securebrowse.data.SavedTabs
import de.deinname.securebrowse.data.SearchEngine
import de.deinname.securebrowse.data.SearchEngines
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Immutable UI snapshot of one tab. WebView objects live in [WebViewRegistry], never here. */
data class TabUi(
    val id: Long,
    val url: String = "",
    val title: String = "",
    val progress: Int = 0,
    val isLoading: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val sslError: Boolean = false,
    val favicon: Bitmap? = null,
    /** Incremented to force a fresh WebView (e.g. after a renderer crash). */
    val generation: Int = 0
)

class FileChooserRequest(
    val acceptTypes: List<String>,
    val allowMultiple: Boolean,
    val callback: ValueCallback<Array<Uri>>
)

/** Dialogs that block on a decision of the user. Each one knows how to cancel itself safely. */
sealed interface PendingDialog {
    fun cancel() {}

    class ExternalScheme(val url: String, val intent: Intent) : PendingDialog

    class Permission(val origin: String, val resources: List<String>, val request: PermissionRequest) : PendingDialog {
        override fun cancel() = request.deny()
    }

    class HttpAuth(val host: String, val realm: String, val handler: HttpAuthHandler) : PendingDialog {
        override fun cancel() = handler.cancel()
    }

    class Download(
        val url: String,
        val userAgent: String,
        val contentDisposition: String,
        val mimeType: String,
        val contentLength: Long
    ) : PendingDialog

    /** Certificate problem: the page only loads if the user explicitly chooses to continue (never remembered). */
    class SslWarning(val url: String, val primaryError: Int, val handler: SslErrorHandler) : PendingDialog {
        override fun cancel() = handler.cancel()
    }
}

data class BrowserUiState(
    val loaded: Boolean = false,
    val tabs: List<TabUi> = emptyList(),
    val selectedTabId: Long = -1L,
    val searchEngine: SearchEngine = SearchEngines.DuckDuckGo,
    val allowMixedContent: Boolean = false,
    val themeMode: String = "auto",
    val dialog: PendingDialog? = null,
    val fileChooser: FileChooserRequest? = null,
    val customView: View? = null,
    @StringRes val message: Int? = null
) {
    val selectedTab: TabUi? get() = tabs.firstOrNull { it.id == selectedTabId }
}

class BrowserViewModel(private val store: BrowserStore) : ViewModel() {

    private val _state = MutableStateFlow(BrowserUiState())
    val state: StateFlow<BrowserUiState> = _state.asStateFlow()

    val bookmarks: StateFlow<List<Bookmark>> =
        store.bookmarks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val history: StateFlow<List<HistoryEntry>> =
        store.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val ready = CompletableDeferred<Unit>()
    private var nextTabId = 1L

    /** Zuletzt benutzte Tabs (ältester zuerst). Die Zurück-Taste springt hierhin, statt die App zu verlassen. */
    private val tabHistory = ArrayDeque<Long>()

    private fun rememberCurrent(s: BrowserUiState) {
        val cur = s.selectedTabId
        if (cur != -1L && s.tabs.any { it.id == cur }) {
            tabHistory.remove(cur)
            tabHistory.addLast(cur)
            while (tabHistory.size > 50) tabHistory.removeFirst()
        }
    }

    init {
        viewModelScope.launch {
            val saved = store.loadTabs()
            val restored = saved?.tabs?.map { TabUi(id = it.id, url = it.url, title = it.title) }.orEmpty()
            val tabs = restored.ifEmpty { listOf(TabUi(id = 1L)) }
            nextTabId = (tabs.maxOf { it.id }) + 1
            val selected = saved?.selectedId?.takeIf { id -> tabs.any { it.id == id } } ?: tabs.first().id
            _state.update { it.copy(loaded = true, tabs = tabs, selectedTabId = selected) }
            ready.complete(Unit)
        }
        viewModelScope.launch {
            store.searchEngineId.collect { id -> _state.update { it.copy(searchEngine = SearchEngines.byId(id)) } }
        }
        viewModelScope.launch {
            store.themeMode.collect { v -> _state.update { it.copy(themeMode = v) } }
        }
        viewModelScope.launch {
            store.allowMixedContent.collect { v -> _state.update { it.copy(allowMixedContent = v) } }
        }
    }

    // ---- Address handling ----------------------------------------------------------------

    fun resolveInput(input: String): String? = UrlTools.resolve(input, _state.value.searchEngine.template)

    fun resolveInputWithFallback(input: String): UrlTools.Resolved? =
        UrlTools.resolveWithFallback(input, _state.value.searchEngine.template)

    /** Called for incoming VIEW/SEND intents. Opens the target in a new tab. */
    fun openExternalRequest(raw: String) {
        viewModelScope.launch {
            ready.await()
            val url = resolveInput(raw)
            if (url == null) showMessage(R.string.invalid_address) else newTab(url)
        }
    }

    // ---- Tabs -------------------------------------------------------------------------------

    fun newTab(url: String = ""): Long {
        val id = nextTabId++
        rememberCurrent(_state.value)
        _state.update { it.copy(tabs = it.tabs + TabUi(id = id, url = url), selectedTabId = id) }
        persistTabs()
        return id
    }

    fun selectTab(id: Long) {
        val s = _state.value
        if (id == s.selectedTabId || s.tabs.none { it.id == id }) return
        rememberCurrent(s)
        tabHistory.remove(id)
        _state.update { it.copy(selectedTabId = id) }
        persistTabs()
    }

    /**
     * Zurück-Taste auf der ersten Seite eines Tabs: schließt den aktuellen Tab und wechselt zum
     * zuvor benutzten Tab. Gibt die ID des geschlossenen Tabs zurück (Aufrufer entfernt die WebView)
     * oder null, wenn nur ein Tab offen ist (dann soll die App normal behandelt werden).
     */
    fun closeCurrentAndGoToPrevious(): Long? {
        val s = _state.value
        if (s.tabs.size <= 1) return null
        val closing = s.selectedTabId
        closeTab(closing)
        return closing
    }

    /** The caller must also remove the WebView from the registry. The last tab is replaced by an empty one. */
    fun closeTab(id: Long) {
        tabHistory.remove(id)
        _state.update { s ->
            val remaining = s.tabs.filterNot { it.id == id }
            val tabs = remaining.ifEmpty { listOf(TabUi(id = nextTabId++)) }
            val selected = if (s.selectedTabId == id || tabs.none { it.id == s.selectedTabId }) {
                // Bevorzugt der Tab, der davor aktiv war
                tabHistory.lastOrNull { h -> tabs.any { it.id == h } } ?: tabs.last().id
            } else {
                s.selectedTabId
            }
            s.copy(tabs = tabs, selectedTabId = selected)
        }
        persistTabs()
    }

    /** Schließt alle Tabs und lässt einen leeren Tab übrig. Aufrufer entfernt die WebViews. */
    fun closeAllTabs(): List<Long> {
        val ids = _state.value.tabs.map { it.id }
        tabHistory.clear()
        val fresh = TabUi(id = nextTabId++)
        _state.update { it.copy(tabs = listOf(fresh), selectedTabId = fresh.id) }
        persistTabs()
        return ids
    }

    fun setTabUrl(id: Long, url: String) = updateTab(id) { it.copy(url = url) }

    fun toggleBookmark() {
        val tab = _state.value.selectedTab ?: return
        if (!UrlTools.isWebUrl(tab.url)) return
        viewModelScope.launch { store.toggleBookmark(tab.url, tab.title.ifBlank { tab.url }) }
    }

    fun deleteBookmark(url: String) {
        viewModelScope.launch { store.deleteBookmark(url) }
    }

    fun clearHistory() {
        viewModelScope.launch {
            store.clearHistory()
            showMessage(R.string.history_cleared)
        }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch { store.setThemeMode(mode) }
    }

    fun setAllowMixedContent(allowed: Boolean) {
        viewModelScope.launch { store.setAllowMixedContent(allowed) }
    }

    fun setSearchEngine(id: String) {
        viewModelScope.launch { store.setSearchEngine(id) }
    }

    // ---- Callbacks from WebViewClient / WebChromeClient (all on the main thread) ----------

    fun onPageStarted(tabId: Long, url: String) = updateTab(tabId) {
        it.copy(url = url, isLoading = true, progress = 0, sslError = false)
    }

    fun onNavigation(tabId: Long, url: String, canGoBack: Boolean, canGoForward: Boolean) = updateTab(tabId) {
        it.copy(url = url, canGoBack = canGoBack, canGoForward = canGoForward)
    }

    fun onPageFinished(tabId: Long, url: String, title: String, canGoBack: Boolean, canGoForward: Boolean) {
        updateTab(tabId) {
            it.copy(
                url = url, title = title, isLoading = false, progress = 100,
                canGoBack = canGoBack, canGoForward = canGoForward
            )
        }
        persistTabs()
        if (UrlTools.isWebUrl(url)) {
            viewModelScope.launch { store.addHistory(url, title.ifBlank { url }) }
        }
    }

    fun onProgress(tabId: Long, progress: Int) = updateTab(tabId) { it.copy(progress = progress, isLoading = progress < 100) }

    fun onTitle(tabId: Long, title: String) = updateTab(tabId) { it.copy(title = title) }

    fun onFavicon(tabId: Long, icon: Bitmap?) = updateTab(tabId) { it.copy(favicon = icon) }

    fun onSslError(tabId: Long) = updateTab(tabId) { it.copy(sslError = true, isLoading = false) }

    fun onRendererGone(tabId: Long) {
        updateTab(tabId) { it.copy(isLoading = false, progress = 0, generation = it.generation + 1) }
        showMessage(R.string.renderer_crashed)
    }

    // ---- Dialogs & choosers -----------------------------------------------------------------

    fun requestDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String, contentLength: Long) =
        showDialog(PendingDialog.Download(url, userAgent, contentDisposition, mimeType, contentLength))

    fun requestExternal(url: String, intent: Intent) = showDialog(PendingDialog.ExternalScheme(url, intent))

    /** Marks the tab and asks the user. The WebView waits for the handler, so nothing loads without a decision. */
    fun requestSslDecision(tabId: Long, url: String, primaryError: Int, handler: SslErrorHandler) {
        onSslError(tabId)
        showDialog(PendingDialog.SslWarning(url, primaryError, handler))
    }

    fun requestHttpAuth(host: String, realm: String, handler: HttpAuthHandler) =
        showDialog(PendingDialog.HttpAuth(host, realm, handler))

    /** Only camera and microphone can ever be granted. Everything else is denied right away. */
    fun requestPermission(origin: String, resources: List<String>, request: PermissionRequest) {
        val supported = resources.filter {
            it == PermissionRequest.RESOURCE_VIDEO_CAPTURE || it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
        }
        if (supported.isEmpty()) request.deny() else showDialog(PendingDialog.Permission(origin, supported, request))
    }

    fun onPermissionRequestCanceled(request: PermissionRequest) {
        val d = _state.value.dialog
        if (d is PendingDialog.Permission && d.request === request) _state.update { it.copy(dialog = null) }
    }

    fun grantPermission(dialog: PendingDialog.Permission) {
        dialog.request.grant(dialog.resources.toTypedArray())
        clearDialog(dialog)
    }

    fun denyPermission(dialog: PendingDialog.Permission) {
        dialog.request.deny()
        clearDialog(dialog)
    }

    fun dismissDialog() {
        _state.value.dialog?.let { clearDialog(it, cancel = true) }
    }

    fun clearDialog(dialog: PendingDialog, cancel: Boolean = false) {
        if (cancel) dialog.cancel()
        _state.update { if (it.dialog === dialog) it.copy(dialog = null) else it }
    }

    fun requestFileChooser(request: FileChooserRequest) {
        _state.value.fileChooser?.callback?.onReceiveValue(null)
        _state.update { it.copy(fileChooser = request) }
    }

    fun completeFileChooser(uris: List<Uri>) {
        val request = _state.value.fileChooser ?: return
        val picked = if (request.allowMultiple) uris else uris.take(1)
        request.callback.onReceiveValue(if (picked.isEmpty()) null else picked.toTypedArray())
        _state.update { it.copy(fileChooser = null) }
    }

    fun setCustomView(view: View?) = _state.update { it.copy(customView = view) }

    fun showMessage(@StringRes message: Int) = _state.update { it.copy(message = message) }

    fun messageShown() = _state.update { it.copy(message = null) }

    // ---- Internals ----------------------------------------------------------------------------

    private fun showDialog(dialog: PendingDialog) {
        _state.value.dialog?.cancel() // never leave a previous request hanging
        _state.update { it.copy(dialog = dialog) }
    }

    private fun updateTab(id: Long, transform: (TabUi) -> TabUi) {
        _state.update { s -> s.copy(tabs = s.tabs.map { if (it.id == id) transform(it) else it }) }
    }

    private fun persistTabs() {
        val s = _state.value
        if (!s.loaded) return
        val snapshot = SavedTabs(s.tabs.map { SavedTab(it.id, it.url, it.title) }, s.selectedTabId)
        viewModelScope.launch { store.saveTabs(snapshot) }
    }

    override fun onCleared() {
        _state.value.dialog?.cancel()
        _state.value.fileChooser?.callback?.onReceiveValue(null)
        super.onCleared()
    }

    class Factory(private val store: BrowserStore) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = BrowserViewModel(store) as T
    }

    companion object {
        /** Maps WebView resources to the Android runtime permissions that must be granted first. */
        fun androidPermissionsFor(resources: List<String>): List<String> = resources.mapNotNull {
            when (it) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
                else -> null
            }
        }
    }
}
