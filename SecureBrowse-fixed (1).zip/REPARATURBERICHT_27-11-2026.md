# Reparatur-/Prüfrunde (27.11.2026)

- `JarvisModelManager.kt`: Modellimport ersetzt ein vorheriges Modell jetzt mit `Files.move(..., REPLACE_EXISTING)` statt erst die vorhandene Datei zu löschen und danach Rename zu versuchen. So wird das vorhandene Modell bei einem Rename-Fehler nicht unnötig verloren.
- Unbenutzte Imports in dieser Datei entfernt.
- `ui/` und `res/` wurden bei dieser Reparatur nicht verändert.
- Build/Test nicht ausgeführt: in der Prüf-Umgebung ist kein Gradle installiert und der ZIP enthält keine `gradle-wrapper.jar`; der Android-Gradle-Build ist damit hier nicht verifiziert.
- GitHub Actions Workflow verwendet eine bereitgestellte Gradle-Installation und ist daher nicht auf die fehlende Wrapper-JAR angewiesen.


## Build-Fix (27.11.2026, Nachtrag)
- `gradle/libs.versions.toml`: `material-icons-extended` hat jetzt eine eigene Version (`composeIconsExtended = "1.7.8"`). Die Bibliothek wird nach 1.7.8 nicht mehr veröffentlicht; mit der Compose-Version 1.9.4 scheiterte die Auflösung ("Could not find ...material-icons-extended:1.9.4").
- `PromptSafety.kt` (`sanitizeChatMessage`): Zeichenliterale wie `'\\u200B'` (doppelter Backslash) sind in Kotlin ungültig und wurden zu `'\u200B'` korrigiert (Compile-Fehler).
- `.github/workflows/android-apk.yml`: Gradle 9.1.0, NDK/CMake-Installation, Fallback ohne native Bibliothek, kompakte Fehlerausgabe, Build-Log als Artefakt.
- NICHT verifiziert: Der Gradle-Build wurde in dieser Umgebung nicht ausgeführt (kein Zugriff auf Google Maven / Android SDK). Erst ein erfolgreicher GitHub-Actions-Lauf bestätigt den Build.
- Weitere Compile-Fehler aus dem GitHub-Lauf behoben: `BrowserStore.encodeHistory` (fehlendes `.toString()`), `LlamaInferenceEngine.DEFAULT_SYSTEM_PROMPT` (`const val` mit `trimIndent()` nicht erlaubt), `JarvisCallScreen` (Launcher vor `startRecognition()` deklariert). Weiterhin ungetestet, bis ein Lauf grün ist. Offen: CMake-Fehler der nativen llama.cpp-Bibliothek (Fallback ohne native Bibliothek im Workflow).
